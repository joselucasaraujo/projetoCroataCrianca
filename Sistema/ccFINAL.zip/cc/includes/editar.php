<?php $chave = trim(strip_tags($_GET['id'])); //remove espaçoes e tags
      $chave = str_replace("\"", "",$chave); //remove aspas
      $chave = str_replace("\'", "",$chave); //remove aspas 
?>
<form action="" method="POST">			
<?php
//Ddos da criança
 include('partials/editar/dadosCriancaEditar.php'); 
 //Dados da mae
 include("partials/editar/dadosMaeEditar.php");
 //dados do pai
 include 'partials/editar/dadosPaiEditar.php';
//Dados vacinas
 include('partials/editar/dadosVacinas.php');
 //Dados teste
 include('partials/editar/testesEditar.php');
 ?>

	
				  </div>
				 </div>
				 <a href="assets/files/dompdf/dompdf/perfil.php?id=<?php echo $idCrinca; ?>" class="btn btn-sm btn-primary btn-block border border-primary" style="margin-bottom: -8px;">Gerar relatório</a>
				<button name="attCriancaEdit" value="<?php echo $idCrinca; ?>" class="btn btn-sm btn-success btn-block border border-success" id="attCriancaIDEdit" type="submit">Atualizar</button>



</form>