  <div class="container-fluid mt-5">
  <div class="container">
     <div class="col-md-12">
            <table class="table tableTarefa table-sm" >
              <thead class="bg-rosa text-white">
                <tr>
                 <td>Nome completo</td>
                 <td>Data de nascimento</td>
                 <td>Localidade</td>
                 <td>Peso/Semana</td> 
                 <td>Editar</td> 
                 <td>Excluir</td> 
                </tr>
              </thead>
              <tbody>
                <?php 
                    $listarUser = listar('tb_crianca');
                    foreach ($listarUser as $key):
                 ?>
                <tr>
                    <td><?php echo $key->nomeCrianca; ?></td>
                    <td><?php echo inverteData($key->dataNascCrianca); ?></td>
                    <td><?php echo $key->localidade; ?></td>
                    <td>
                      <a class="btn btn-rosa btn-block shadow-lg" style="border-bottom-left-radius: 80px; border-top-left-radius: 40px; margin-top: -10px; margin-bottom: -10px;" href="home&p=peso&id=<?php echo $key->idcrypt; ?>&pag=1"><img src="assets/img/peso.png" width="20px"></a> 
                    </td>
                    <td>
                      <a class=" btn-rosa  btn-block" style="height: 38px;margin-top: -10px; margin-left: -20px;" href="home&p=editar&id=<?php echo $key->idcrypt; ?>"><img src="assets/img/child2.png" style="margin-top: 10px; margin-left: 25px;" width="20px"></a>
                    </td>
                    <td>
                       <a class="btn-rosa btn-block" style="width: 130px; height: 38px; margin-top: -10px; margin-left: -40px; margin-right: -100px;" href="home&p=listar&excluirCrianca=true&id=<?php echo $key->id; ?>&pag=1"><img  src="assets/img/del.png" style="margin-top: 10px; margin-left: 25px; " width="20px"></a>
                    </td>
                </tr>
            <?php endforeach; ?>
              </tbody>
            </table>   
       </div>
  </div>
</div> 