<?php 

	    $idChave = trim(strip_tags($_GET['id'])); //remove espaçoes e tags
      $idChave = str_replace("\"", "",$idChave); //remove aspas
      $idChave = str_replace('\'', "",$idChave); //remove aspas 


       $listarDadosCrianca = listarPorChave($idChave, "tb_crianca");
	            foreach ($listarDadosCrianca as $child) : 	
	            $idCrinca = $child->id;
	            $nomeCrianca = $child->nomeCrianca;
	     endforeach;


 ?>

<?php 



  if ($child->sexoCrianca == 'Masculino') {
    echo '<div class="bg-azulbb text-white shadow-lg">
  <form class="form-inline mt-2 mt-md-0 p-2 ml-2" name="enterData" method="POST" action="home&p=peso&id='.$idChave.'&pag=1" enctype="multipart/form-data">
                  <img src="assets/img/child2.png" height="40px"><h5 class="ml-3" style="margin-top: 15px;">'.$nomeCrianca.'</h5>
    </form>
</div>
';
  }elseif ($child->sexoCrianca == 'Feminino') {
        echo '<div class="bg-femi text-white shadow-lg">
  <form class="form-inline mt-2 mt-md-0 p-2 ml-2" name="enterData" method="POST" action="home&p=peso&id='.$idChave.'&pag=1" enctype="multipart/form-data">
                  <img src="assets/img/child2.png" height="40px"><h5 class="ml-3" style="margin-top: 15px;">'.$nomeCrianca.'</h5>

    </form>
</div>
';
  }else{
        echo '<div class="bg-primary text-white shadow-lg">
  <form class="form-inline mt-2 mt-md-0 p-2 ml-2" name="enterData" method="POST" action="home&p=peso&id='.$idChave.'&pag=1" enctype="multipart/form-data">
                  <img src="assets/img/child2.png" height="40px"><h5 class="ml-3" style="margin-top: 15px;">'.$nomeCrianca.'</h5>

    </form>
</div>
';
  }

 ?>
  <div class="container-fluid mt-5">
     <div class="col-md-12">
            <table class="table tableTarefa">
              <thead class="bg-rosa text-white">
                <tr>
                 <td>Semana</td>
                 <td>Peso</td>
                 <td>Data</td>
                 <td><p hidden="">Excluir</p></td> 
                </tr>
              </thead>
              <tbody>
                <?php 
                    $listarUser = listarPorIdCriancaEmOrdem($idCrinca, 'tb_peso_semana');
                    foreach ($listarUser as $key):
                 ?>
                <tr>
                    <td><?php echo $key->semana.'º Semana'; ?></td>
                    <td><?php echo $key->peso.' KG'; ?></td>
                    <td><?php echo inverteData($key->data); ?></td>
                    <td><a class="btn btn-rosa btn-sm btn-block shadow-lg" style="width: 20rem; border-bottom-left-radius: 80px; border-top-left-radius: 40px; margin-top: -10px; margin-left: 440px; margin-right: -10px;" href="home&p=peso&excluirPeso=true&id=<?php echo $key->id; ?>&pag=1&key=<?php echo $idChave ?>"><img src="assets/img/del.png" width="20px"></a></td>
                </tr>
            <?php endforeach; ?>
              </tbody>
            </table>   
       </div>
</div>  
        <?php include 'partials/peso/cadPeso.php'; ?>