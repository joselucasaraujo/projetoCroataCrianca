										//LOCALIDADE
					$(function(){
		    var valorDaDiv = $(".divTipoDePartoID").text();    
		    $("#tipoDePartoIDEdit").val(valorDaDiv);
		});


										//LOCALIDADE
					$(function(){
		    var valorDaDiv = $(".divSexoID").text();    
		    $("#sexoIDEdit").val(valorDaDiv);
		});
														//LOCALIDADE
					$(function(){
		    var valorDaDiv = $(".divLocalidadeID").text();    
		    $("#localidadeIDEdit").val(valorDaDiv);
		});