       
<hr>
<div class="p-3">
						<form method="POST" action="" name="novaSemana">
		<div class="row">
								<div class="form-group form-group col-md-4 col-sm">	
								<label for="semanaID">Semana: </label>
								<input class="form-control form-control-sm shadow-lg" type="number" id="cadSemanaPesoID" placeholder="Digite o número da semana" name="cadSemanaPeso" >
							</div>
							<div class="form-group form-group col-md-4 col-sm">	
								<label for="dataPesoID">Data: </label>
								<input class="form-control form-control-sm shadow-lg" type="date" id="cadDataPesoID" name="cadDataPeso" >
							</div>
							<div class="form-group form-group col-md-4 col-sm">	
								<label for="pesoDataID">Peso: </label>
								<input class="form-control form-control-sm shadow-lg" type="number" step="00.01" id="cadCPesoDataID" placeholder="Digite o peso registrado"  name="cadCPesoData" >
							</div>
		</div>
							<button class="btn btn-rosa shadow-lg" name="cadPesoBB" id="cadPesoBBID" value="<?php echo $idCrinca; ?>" type="submit">+ Adicionar semana</button>
						</form>
</div>