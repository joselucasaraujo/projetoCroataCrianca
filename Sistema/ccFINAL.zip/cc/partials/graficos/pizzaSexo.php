<script type="text/javascript">
	
	    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Sexo', 'Quantidade'],
          ['Feminino',     <?php echo $cont_feminino; ?>],
          ['Masculino',      <?php echo $cont_masculino; ?>],
        ]);

        var options = {
          title: 'Percentual de crianças por sexo'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
</script>