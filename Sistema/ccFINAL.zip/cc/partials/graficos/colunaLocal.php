
    <script type="text/javascript">
      //carrega o pacote dos gráficos    
      google.charts.load('current', {'packages':['corechart']});
      
      //define a função para criar o gráfico
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Crianças', 'Crianças'],
          ['Croatá',     <?php echo $cont_croata; ?>],
          ['Betânia',     <?php echo $cont_betania; ?>],
          ['Barra do sotero',      <?php echo $cont_barra; ?>],
          ['Lagoa da cruz',  <?php echo $cont_lagoa; ?>],
          ['São roque', <?php echo $cont_saoRoque; ?>],
          ['Santa tereza', <?php echo $cont_santaTereza; ?>],
          ['Vista alegre', <?php echo $cont_vistaAlegre; ?>],
          ['Repartição', <?php echo $cont_reparticao; ?>]
        ]);
        // criar a variavel options para definir as opções do gráfico
        var options = {
          title: 'Gráfico de crianças por localidade'
        };
        //aloca o tipo de gráfico na div GraficoColunas
    var chart = new google.visualization.ColumnChart(document.getElementById('GraficoColunas'));

        chart.draw(data, options);
      }
      
      //carrega o grafico na página
      google.charts.setOnLoadCallback(drawChart);
      
    </script>