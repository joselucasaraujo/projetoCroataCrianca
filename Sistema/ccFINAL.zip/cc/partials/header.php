 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/icones/ccico64.ico">
    <!-- Altera ar cor da barra de cima do browser -->
    <meta name="theme-color" content="#b71c3e">
    <meta name="apple-mobile-web-app-status-bar-style" content="#b71c3e">
    <meta name="msapplication-navbutton-color" content="#b71c3e">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/validacao.css">
    <link rel="stylesheet" href="assets/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="node_modules/animate.css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="node_modules/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
    <title>Croatá Criança</title>
