															   
	 <button class="btn-azulbb text-light btn-block  border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseTeste" aria-expanded="false" aria-controls="collapseTeste">
					    Testes
				 </button>



				<div class="collapse" id="collapseTeste">
				  <div class="card card-body bg-cinzaClaro">
<?php $pegaTestes = listarPorIdCrianca($idCrinca, "tb_testes");
	foreach ($pegaTestes as $key):
	
 ?>

				  			<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="dataTestePezinho">Data teste do Pézinho:</label>
									<input class="form-control form-control-sm shadow-lg" value="<?php echo $key->tPData; ?>" type="date" id="dataTestePezinhoID" placeholder="" name="dataTestePezinhoEdit">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTestePezinho">Resultado teste do Pézinho:</label>
									<input class="form-control form-control-sm shadow-lg" type="text" id="resultadoTestePezinhoID" placeholder="" value="<?php echo $key->tPResul; ?>" name="resultadoTestePezinhoEdit">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="dataTesteOrelha">Data teste da Orelha:</label>
									<input class="form-control form-control-sm shadow-lg" type="date" id="dataTesteOrelhaID" value="<?php echo $key->tOrelhaData; ?>" placeholder=""
									name="dataTesteOrelhaEdit">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTesteOrelha">Resultado teste da Orelha:</label>
									<input class="form-control form-control-sm shadow-lg" type="text" id="resultadoTesteOrelhaID" placeholder="" name="resultadoTesteOrelhaEdit" value="<?php echo $key->tOrelhaResul; ?>">
								</div>
							</div>
<hr>
							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="dataTesteLingua">Data teste da Lingua:</label>
									<input class="form-control form-control-sm shadow-lg" type="date" id="dataTesteLinguaID" placeholder="" 
									name="dataTesteLinguaEdit" value="<?php echo $key->tLinguaData; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTesteLingua">Resultado teste da Lingua:</label>
									<input class="form-control form-control-sm shadow-lg" type="text" id="resultadoTesteLinguaID" placeholder="" name="resultadoTesteLinguaEdit" value="<?php echo $key->tLinguaResul; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="perimetroCefalico">Perímetro cefálico:</label>
									<input class="form-control form-control-sm shadow-lg" type="number" step="00.01" id="perimetroCefalicoID" placeholder="" name="perimetroCefalicoEdit" value="<?php echo $key->perCefalicoCrianca; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="perimetroToraxico">Perímetro toraxico:</label>
									<input class="form-control form-control-sm shadow-lg" type="number" step="00.01" name="perimetroToraxicoEdit" id="perimetroToraxico" placeholder="" value="<?php echo $key->perToraxico; ?>">
								</div>
							</div>
<hr>
							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="apgar1">Apgar 1º:</label>
									<input class="form-control form-control-sm shadow-lg" type="number" name="apgar1Edit" id="apgar1ID" placeholder="" value="<?php echo $key->apgar1Crianca; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="apgar5">Apgar 5º:</label>
									<input class="form-control form-control-sm shadow-lg" type="number" name="apgar5Edit" id="apgar5ID" placeholder="" value="<?php echo $key->apgar5Crianca; ?>">
								</div>
							</div>
						<?php endforeach; ?>