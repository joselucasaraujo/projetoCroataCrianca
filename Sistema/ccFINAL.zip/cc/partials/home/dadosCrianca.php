 <button class="btn-azulbb text-light btn-block border border-azulbb shadow-lg " type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
				    Dados da Criança
		 </button>
				<div class="collapse" id="collapseCrianca">
				  <div class="card card-body bg-cinzaClaro">
	
					<div class="row">
						<div class="form-group col-md-6 col-sm-6">
							<label for="nomeRN">Nome do RN: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm shadow-lg " type="text" id="nomeRNID" placeholder="Digite o nome do recém nascido" name="nomeRN" required>
						</div>
						<div class="form-group col-md-6 col-sm-6">
							<label for="acs">ACS: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm shadow-lg " type="text" id="acsID" placSeholder="Digite o nome do Agente Comunitário de Saúde" name="acs" required>
						</div>

					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="dataRN">Data de Nascimento: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm shadow-lg " type="date" id="dataRNID" name="dataRN" required>
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="hora">Hora:</label>
							<input class="form-control form-control-sm shadow-lg " type="text" id="horaID" name="hora">
						</div>
						<div class="form-group col-md-2 col-sm">
							  <label for="sexoID">Sexo: <b class="text-danger">*</b></label>
							    <select class="form-control form-control-sm shadow-lg " id="sexoID" name="sexo" required>
							      <option value="">Selecione </option>
							      <option value="Masculino">Masculino</option>
							      <option value="Feminino">Feminino</option>
							    </select>
						</div>
						<div class="form-group col-md-4 col-sm">
							  <label for="tipoDePartoID">Tipo de parto: <b class="text-danger">*</b></label>
							    <select class="form-control form-control-sm shadow-lg " id="tipoDePartoID" name="tipoDeParto" required>
							    							      <
							      <option value="">Selecione</option>
							      <option value="Normal">Normal</option>
							      <option value="Cesariana">Cesariana</option>
							    </select>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="peso">Peso:</label>
							<input class="form-control form-control-sm shadow-lg " step="00.001" type="number" id="pesoID" name="peso">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="altura">Estatura:</label>
							<input class="form-control form-control-sm shadow-lg " type="number" id="alturaID" name="altura">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="idadeGestacional">Idade gestacional: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm shadow-lg " type="number" id="idadeGestacionalID" name="idadeGestacional" required>
						</div>
						<div class="form-group col-md-3 col-sm">
									
								
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-4 col-sm">
							<label for="endereco">Endereço:</label>
							<input class="form-control form-control-sm shadow-lg " type="text" id="enderecoID" placeholder="Ex: Rua Antonio Saturnino, Caroba" name="endereco">
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="localidadeID">Localidade: <b class="text-danger">*</b></label>
							 <select class="form-control form-control-sm shadow-lg " id="localidadeID" name="localidade" required>
							      <option value="">Selecione</option>
							      <option value="Croatá">Croatá (sede)</option>
							      <option value="Betânia">Betânia</option>
							      <option value="Barra do sotero">Barra do Sotero</option>
							      <option value="Lagoa da cruz">Lagoa da Cruz</option>
							      <option value="São roque">São Roque</option>
							      <option value="Vista alegre">Vista Alegre</option>
							      <option value="Santa tereza">Santa Tereza</option>
							      <option value="Repartição">Repartição</option>
							  </select>
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="cartaoSUS">Cartão do SUS: </label>
							<input class="form-control form-control-sm shadow-lg " type="text" maxlength="15" id="cartaoSUSID" placeholder="" name="cartaoSUS">
						</div>
					</div>
					</div>	

				</div>