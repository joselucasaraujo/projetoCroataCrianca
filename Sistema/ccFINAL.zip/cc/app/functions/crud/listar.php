	<?php 
  function listar($tabela){

  	$pdo = conectar();

    $listar = $pdo->query("SELECT * FROM $tabela");
    $listar->execute();
    return $listar->fetchAll(PDO::FETCH_OBJ);
  }

//Listar por ID
function listarPorId($id, $tabela){

	$pdo = conectar();

	$listar = $pdo->query("SELECT * FROM $tabela WHERE id = $id");
	$listar->execute();
	return $listar->fetchAll(PDO::FETCH_OBJ);
}
function listarPorIdCrianca($id, $tabela){

  $pdo = conectar();

  $listar = $pdo->query("SELECT * FROM $tabela WHERE idCrianca = $id");
  $listar->execute();
  return $listar->fetchAll(PDO::FETCH_OBJ);
}
function listarPorChave($chave, $tabela){

  $pdo = conectar();

  $listar = $pdo->query("SELECT * FROM $tabela WHERE idcrypt = '$chave'");
  $listar->execute();
  return $listar->fetchAll(PDO::FETCH_OBJ);
}

function listarPorIdCriancaTipoVacina($id, $tipo, $tabela){

  $pdo = conectar();

  $listar = $pdo->query("SELECT * FROM $tabela WHERE tipo = '$tipo' AND idCrianca = '$id'");
  $listar->execute();
  return $listar->fetchAll(PDO::FETCH_OBJ);
}

function listarPor($id, $tipo, $tabela){

  $pdo = conectar();

  $listar = $pdo->query("SELECT * FROM $tabela WHERE tipo = '$tipo' AND idCrianca = '$id'");
  $listar->execute();
  return $listar->fetchAll(PDO::FETCH_OBJ);
}

function listarPorIdCriancaEmOrdem($id){

  $pdo = conectar();

  $listar = $pdo->query("SELECT * FROM tb_peso_semana WHERE idCrianca = $id ORDER BY semana ASC");
  $listar->execute();
  return $listar->fetchAll(PDO::FETCH_OBJ);
}




 ?>