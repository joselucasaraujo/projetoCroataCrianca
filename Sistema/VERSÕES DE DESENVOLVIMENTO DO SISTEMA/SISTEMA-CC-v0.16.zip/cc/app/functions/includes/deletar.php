<?php
  if (isset($_GET['excluir']) AND $_GET['excluir'] == true) {
    $id = filter_input(INPUT_GET,'id', FILTER_SANITIZE_NUMBER_INT);
    $registroExcluido = deletar("id",$id,"tb_usuario");

		$mensagem = ($registroExcluido) ? "Excluido com sucesso !" : "Ocorreu um erro ao excluir o cliente";
  }
 ?>
