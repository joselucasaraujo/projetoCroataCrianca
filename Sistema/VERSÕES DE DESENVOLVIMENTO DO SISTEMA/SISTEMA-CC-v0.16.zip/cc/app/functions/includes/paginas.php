<?php

       function alterarPaginaHome(){

    $include = filter_input(INPUT_GET, 'p', FILTER_SANITIZE_STRING);
    $pagina = (!is_null($include)) ? $include : 'home';

    //Includes das paginas
    $includeDaPagina = "includes/".$pagina.".php";
    $error404 = "includes/error404.php";

    require (is_file($includeDaPagina)) ? $includeDaPagina : $error404;

  }

   

      function alterarPaginaLogin(){

    $include = filter_input(INPUT_GET, 'p', FILTER_SANITIZE_STRING);
    $pagina = (!is_null($include)) ? $include : 'login';

    //Includes das paginas
    $includeDaPagina = "includes/".$pagina.".php";
    $error404 = "includes/error404.php";

    require (is_file($includeDaPagina)) ? $includeDaPagina : $error404;

  }

//NOVA DASH NOVA FUNÇÃO
 ?>
 