<?php $chave = trim(strip_tags($_GET['id'])); //remove espaçoes e tags
      $chave = str_replace("\"", "",$chave); //remove aspas
      $chave = str_replace("\'", "",$chave); //remove aspas 
?>
<form action="" method="POST">			
<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
	    Dados da Criança
</button>
	<?php $listarDadosCrianca = listarPorChave($chave, "tb_crianca");
	            foreach ($listarDadosCrianca as $child) : 	
	       ?>
<div class="collapse" id="collapseCrianca">
    <div class="card card-body">

		<div class="row">
			<div class="form-group col-md col-sm">
				<label for="nomeRN">Nome do RN:</label>
				<input class="form-control form-control-sm" type="text" name="nomeRNEdit" id="nomeRNID" placeholder="Digite o nome do recém nascido" value="<?php echo $child->nomeCrianca;?>">
			</div>
		</div>
		<hr>
		<?php $datanasc = $child->dataNascCrianca; 
			 ?>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="dataRN">Data de Nascimento</label>
				<input class="form-control form-control-sm" type="date" name="dataRNEdit" id="dataRNID" value="<?php 	
				echo $datanasc;
				?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="hora">Hora:</label>
				<input class="form-control form-control-sm" type="text" name="horaEdit" id="horaID" value="<?php echo $child->horaNascCrianca;?>">
			</div>
			<div class="form-group col-md-2 col-sm">
				  <label for="sexoID">Sexo:</label>
				    <select class="form-control form-control-sm" name="sexoEdit" id="sexoID" value="<?php echo $child->sexoCrianca;?>">
				      <option value="m">Masculino</option>
				      <option value="f">Feminino</option>
				    </select>
			</div>
			<div class="form-group col-md-4 col-sm">
				  <label for="tipoDePartoID">Tipo de parto:</label>
				    <select class="form-control form-control-sm" name="tipoDePartoEdit" id="tipoDePartoID" value="<?php echo $child->partoCrianca;?>">
				      <option value="Normal">Normal</option>
				      <option value="Cesariana">Cesariana</option>
				    </select>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="peso">Peso:</label>
				<input class="form-control form-control-sm" step="00.01" type="number" name="pesoEdit" id="pesoID" value="<?php echo $child->pesoCrianca;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="altura">Altura:</label>
				<input class="form-control form-control-sm" type="number" name="alturaEdit" id="alturaID" value="<?php echo $child->alturaCrianca;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="idadeGestacional">Idade gestacional:</label>
				<input class="form-control form-control-sm" type="number" name="idadeGestacionalEdit" id="idadeGestacionalID" value="<?php echo $child->idadeGestacional;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-8 col-sm">
				<label for="endereco">Endereço:</label>
				<input class="form-control form-control-sm" type="text" name="enderecoEdit" id="enderecoID" placeholder="Ex: Rua Antonio Saturnino, Caroba" value="<?php echo $child->endereco;?>">
			</div>
			<div class="form-group col-md-4 col-sm">
				<label for="localidade">Localidade:</label>
				<input class="form-control form-control-sm" type="text" name="localidadeEdit" id="localidadeID" placeholder="Ex: Sede" value="<?php echo $child->localidade;?>">
			</div>
		</div>
	</div>	
	<?php 
		$idMae = $child->idMae;
		$idPai = $child->idPai;
		endforeach; 
	?>
</div>

<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseMae" aria-expanded="true" aria-controls="collapseMae">
    Dados da Mãe
</button>
	<?php $listarDadosMae = listarPorId($idMae, "tb_mae");
            foreach ($listarDadosMae as $mother) : 	
    ?>
	<div class="collapse" id="collapseMae">
	    <div class="card card-body">
		    <div class="row">
				<div class="form-group col-md col-sm">	
					<label for="nomeMae">Nome da Mãe:</label>
					<input class="form-control form-control-sm" type="text" name="nomeMaeEdit" id="nomeMaeID" placeholder="Digite o nome da mãe" value="<?php echo $mother->nome_mae;?>">
				</div>
			</div>
	<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="idadeMae">Idade:</label>
					<input class="form-control form-control-sm" type="number" name="idadeMaeEdit" id="idadeMaeID" placeholder="Digite a idade da mãe" value="<?php echo $mother->idade;?>">
				</div>
				<div class="form-group col-md-6 col-sm">
					<label for="profissaoMae">Profissão:</label>
					<input class="form-control form-control-sm" type="text" name="profissaoMaeEdit" id="profissaoMaeID" placeholder="Digite a profissão da mãe" value="<?php echo $mother->profissao;?>">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="consultaPreNatal">Nº de consultas de pré-natal:</label>
					<input class="form-control form-control-sm" type="number" name="consultaPreNatalEdit" id="consultaPreNatalID" value="<?php echo $mother->numConPN;?>">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosVivo">Filhos Nascidos Vivos:</label>
					<input class="form-control form-control-sm" type="number"  name="filhosVivoEdit" id="filhosVivoID" size="5px" value="<?php echo $mother->filhosV;?>">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosMorto">Mortos:</label>
					<input class="form-control form-control-sm" type="number" name="filhosMortoEdit" id="filhosMortoID" value="<?php echo $mother->filhosM;?>">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosAborto">Aborto:</label>
					<input class="form-control form-control-sm" type="number" name="filhosAbortoEdit" id="filhosAborto" value="<?php echo $mother->filhosA;?>">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="form-group col-md col-sm">	
					<label for="municipioPreNatal">Município de realização do pré-natal:</label>
					<input class="form-control form-control-sm" type="text" name="municipioPreNatalEdit" id="municipioPreNatalID" placeholder="Realizou pré-natal em qual município?" value="<?php echo $mother->municipioPN;?>">
				</div> 
			</div>
		</div>
	</div>	
<?php endforeach; ?>
<button class="btn-azulbb text-light  btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePai" aria-expanded="false" aria-controls="collapsePai">
		    Dados do Pai
 </button>
 <?php $listarDadosPai = listarPorId($idPai, "tb_pai");
            foreach ($listarDadosPai as $dad) : 	
    ?>
	<div class="collapse" id="collapsePai">
	  <div class="card card-body">
	  	
	  		<div class="row">
					<div class="form-group form-group col-md col-sm">	
						<label for="nomePai">Nome do Pai:</label>
						<input class="form-control form-control-sm" type="text" name="nomePaiEdit" id="nomePaiID" placeholder="Digite o nome do pai" value="<?php echo $dad->nome_pai;?>">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-3 col-sm">
						<label for="idadePai">Idade:</label>
						<input class="form-control form-control-sm" type="number" name="idadePaiEdit" id="idadePaiID" placeholder="Digite a idade do pai" value="<?php echo $dad->idade;?>">
					</div>
					<div class="form-group col-md-6 col-sm">
						<label for="profissaoPai">Profissão:</label>
						<input class="form-control form-control-sm" type="text" name="profissaoPaiEdit" id="profissaoPaiID" placeholder="Digite a profissão do pai" value="<?php echo $dad->profissao;?>">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-4 col-sm">
						<label for="numeroMembrosFamilia">Nº de membros da família:</label>
						<input class="form-control form-control-sm" type="number" name="numeroMembrosFamiliaEdit" id="numeroMembrosFamiliaID" value="<?php echo $dad->membrosFamilia;?>">
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="rendaFamiliar">Renda Familiar:</label>
						<input class="form-control form-control-sm" step="00.01" type="number" name="rendaFamiliarEdit" id="rendaFamiliarID" value="<?php echo $dad->renda;?>">
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="acs">ACS:</label>
						<input class="form-control form-control-sm" type="text" name="acsEdit" id="acsID" placeholder="Digite o nome do Agente Comunitário de Saúde" value="<?php echo $dad->acs;?>">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md col-sm">
						<label>Observações:</label>
						<div id="divObsID"><?php echo $dad->obs;?></div>
						<textarea class="form-control form-control-sm" id="obsID" name="obsEdit" rows="4" cols="50"></textarea>	
					</div>
				</div>
    <?php endforeach; ?>				
	  </div>
	 </div> 
	 					<button name="cadCriancaEdit" class=" btn-success btn-block border border-success" type="submit">Atualizar</button>
</form>