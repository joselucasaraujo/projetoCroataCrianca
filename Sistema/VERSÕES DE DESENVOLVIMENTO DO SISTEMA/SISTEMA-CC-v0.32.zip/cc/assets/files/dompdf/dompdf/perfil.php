<?php
	
	$id = $_GET['id'];
	//referenciar o DomPDF com namespace

	// include autoloader
	require_once('dompdf_config.inc.php');
	include_once('../../../../config.php');
	//Criando a Instancia
	$dompdf = new DOMPDF();
	$listarDadosCrianca = listarPorId($id, 'tb_crianca');
	foreach ($listarDadosCrianca as $crianco) {
		$idPapy = $crianco->idPai;
		$idMamy = $crianco->idMae;
		$nomeChild = $crianco->nomeCrianca;
		$acs = $crianco->acs;
		$dataNascimento = $crianco->dataNascCrianca;
		$horaNascimento = $crianco->horaNascCrianca;
		$sexoCrianca = $crianco->sexoCrianca;
		$partoCrianca = $crianco->partoCrianca;
		$pesoCrianca = $crianco->pesoCrianca;
		$alturaCrianca = $crianco->alturaCrianca;
		$idadeGestacional = $crianco->idadeGestacional;
		$enderecoCrianca = $crianco->endereco;
		$localidadeCrianca = $crianco->localidade;
		$cartaoSUS = $crianco->cartaoSUS;
	}

	$listarDadosMae = listarPorId($idMamy, 'tb_mae');
	foreach ($listarDadosMae as $mamy) {
		$nomeMae = $mamy->nome_mae;
		$idadeMae = $mamy->idade;
		$profissaoMae = $mamy->profissao;
		$numConsulPN = $mamy->numConPN;
		$filhosVivo = $mamy->filhosV;
		$filhosMorto = $mamy->filhosM;
		$filhosAborto = $mamy->filhosA;
		$municipioPreNatal = $mamy->municipioPN;
	}

	$listarDadosPai = listarPorId($idPapy, 'tb_pai');
	foreach ($listarDadosPai as $papy) {
		$nomePai = $papy->nome_pai;
		$idadePai = $papy->idade;
		$profissaoPai = $papy->profissao;
		$numMembrosFamilia = $papy->membrosFamilia;
		$rendaFamiliar = $papy->renda;
		$observacao = $papy->obs;
	}

	$listarDadosTestes = listarPorIdCrianca($id, 'tb_testes');
	foreach ($listarDadosTestes as $teste) {
		$tPData = $teste->tPData;
		$tPResul = $teste->tPResul;
		$tOrelhaData = $teste->tOrelhaData;
		$tOrelhaResul = $teste->tOrelhaResul;
		$tLinguaData = $teste->tLinguaData;
		$tLinguaResul = $teste->tLinguaResul;
		$pCCrianca = $teste->perCefalicoCrianca;
		$pTCrianca = $teste->perToraxico;
		$apgar1 = $teste->apgar1Crianca;
		$apgar5 = $teste->apgar5Crianca;
	}

	$listarDadosVacinaBCG = listarPorIdCriancaTipoVacina($id, "BCG", "tb_vacinas");
	foreach ($listarDadosVacinaBCG as $vac){
		$tipoBCG = $vac->tipo;
		$apl1BCG = inverteData($vac->apl1);
		$apl2BCG = inverteData($vac->apl2);
	  	$apl3BCG = inverteData($vac->apl3);
	  	$ref1BCG = inverteData($vac->ref1);
	  	$ref2BCG = inverteData($vac->ref2);
	}
	$listarDadosVacinaHepB = listarPorIdCriancaTipoVacina($id, "HepB", "tb_vacinas");
	foreach ($listarDadosVacinaHepB as $vac){
		$tipoHepB = $vac->tipo;
		$apl1HepB = inverteData($vac->apl1);
		$apl2HepB = inverteData($vac->apl2);
	  	$apl3HepB = inverteData($vac->apl3);
	  	$ref1HepB = inverteData($vac->ref1);
	  	$ref2HepB = inverteData($vac->ref2);
	}

	$listarDadosVacinaPena = listarPorIdCriancaTipoVacina($id, "Penta", "tb_vacinas");
	foreach ($listarDadosVacinaPena as $vac){
		$tipoPenta = $vac->tipo;
		$apl1Penta = inverteData($vac->apl1);
		$apl2Penta = inverteData($vac->apl2);
	  	$apl3Penta = inverteData($vac->apl3);
	  	$ref1Penta = inverteData($vac->ref1);
	  	$ref2Penta = inverteData($vac->ref2);
	}

	$listarDadosVacinaPena = listarPorIdCriancaTipoVacina($id, "Pneumo 10", "tb_vacinas");
	foreach ($listarDadosVacinaPena as $vac){
		$tipoPneumo10 = $vac->tipo;
		$apl1Pneumo10 = inverteData($vac->apl1);
		$apl2Pneumo10 = inverteData($vac->apl2);
	  	$apl3Pneumo10 = inverteData($vac->apl3);
	  	$ref1Pneumo10 = inverteData($vac->ref1);
	  	$ref2Pneumo10 = inverteData($vac->ref2);
	}

	/*

  ##Pneumo 10
  $tipoPneumo10 = filter_input(INPUT_POST, 'tipoPneumo10', FILTER_SANITIZE_STRING);
  $apl1Pneumo10 = inverteData($_POST['apl1Pneumo10']);
  $apl2Pneumo10 = inverteData($_POST['apl2Pneumo10']);
  $apl3Pneumo10 = inverteData($_POST['apl3Pneumo10']);
  $ref1Pneumo10 = inverteData($_POST['ref1Pneumo10']);
  $ref2Pneumo10 = inverteData($_POST['ref2Pneumo10']);

  ##VIP
  $tipoVip = filter_input(INPUT_POST, 'TipoVip', FILTER_SANITIZE_STRING);
  $apl1Vip = inverteData($_POST['apl1Vip']);
  $apl2Vip = inverteData($_POST['apl2Vip']);
  $apl3Vip = inverteData($_POST['apl3Vip']);
  $ref1Vip = inverteData($_POST['ref1Vip']);
  $ref2Vip = inverteData($_POST['ref2Vip']);

  ##ROTAVIRUS
  $tipoRotavirus = filter_input(INPUT_POST, 'tipoRotavirus', FILTER_SANITIZE_STRING);
  $apl1Rotavirus = inverteData($_POST['apl1Rotavirus']);
  $apl2Rotavirus = inverteData($_POST['apl2Rotavirus']);
  $apl3Rotavirus = inverteData($_POST['apl3Rotavirus']);
  $ref1Rotavirus = inverteData($_POST['ref1Rotavirus']);
  $ref2Rotavirus = inverteData($_POST['ref2Rotavirus']);

  ##Meningo C
  $tipoMeningoC = filter_input(INPUT_POST, 'tipoMeningoC', FILTER_SANITIZE_STRING);
  $apl1MeningoC = inverteData($_POST['apl1MeningoC']);
  $apl2MeningoC = inverteData($_POST['apl2MeningoC']);
  $apl3MeningoC = inverteData($_POST['apl3MeningoC']);
  $ref1MeningoC = inverteData($_POST['ref1MeningoC']);
  $ref2MeningoC = inverteData($_POST['ref2MeningoC']);

  ##Tríplice viral
  $tipoTripliceViral = filter_input(INPUT_POST, 'tipoTripliceViral', FILTER_SANITIZE_STRING);
  $apl1TripliceViral = inverteData($_POST['apl1TripliceViral']);
  $apl2TripliceViral = inverteData($_POST['apl2TripliceViral']);
  $apl3TripliceViral = inverteData($_POST['apl3TripliceViral']);
  $ref1TripliceViral = inverteData($_POST['ref1TripliceViral']);
  $ref2TripliceViral = inverteData($_POST['ref2TripliceViral']);

  ##Tetra viral
  $tipoTetraViral = filter_input(INPUT_POST, 'tetraViral', FILTER_SANITIZE_STRING);
  $apl1TetraViral = inverteData($_POST['apl1TetraViral']);
  $apl2TetraViral = inverteData($_POST['apl2TetraViral']);
  $apl3TetraViral = inverteData($_POST['apl3TetraViral']);
  $ref1TetraViral = inverteData($_POST['ref1TetraViral']);
  $ref2TetraViral = inverteData($_POST['ref2TetraViral']);

  ##DTP
  $tipoDTP = filter_input(INPUT_POST, 'tipoDTP', FILTER_SANITIZE_STRING);
  $apl1DTP = inverteData($_POST['apl1DTP']);
  $apl2DTP = inverteData($_POST['apl2DTP']);
  $apl3DTP = inverteData($_POST['apl3DTP']);
  $ref1DTP = inverteData($_POST['ref1DTP']);
  $ref2DTP = inverteData($_POST['ref2DTP']);

  ##HepA
  $tipoHepA = filter_input(INPUT_POST, 'tipoHepA', FILTER_SANITIZE_STRING);
  $apl1HepA = inverteData($_POST['apl1HepA']);
  $apl2HepA = inverteData($_POST['apl2HepA']);
  $apl3HepA = inverteData($_POST['apl3HepA']);
  $ref1HepA = inverteData($_POST['ref1HepA']);
  $ref2HepA = inverteData($_POST['ref2HepA']);

  ##VOP
  $tipoVOP = filter_input(INPUT_POST, 'tipoVOP', FILTER_SANITIZE_STRING);
  $apl1VOP = inverteData($_POST['apl1VOP']);
  $apl2VOP = inverteData($_POST['apl2VOP']);
  $apl3VOP = inverteData($_POST['apl3VOP']);
  $ref1VOP = inverteData($_POST['ref1VOP']);
  $ref2VOP = inverteData($_POST['ref2VOP']);

  ##VARICELA
  $tipoVaricela = filter_input(INPUT_POST, 'tipoVaricela', FILTER_SANITIZE_STRING);
  $apl1Varicela = inverteData($_POST['apl1Varicela']);
  $apl2Varicela = inverteData($_POST['apl2Varicela']);
	*/
	  $dataNascimentoInvertida = inverteData($dataNascimento);
	  $tPDataInvertida = inverteData($tPData);
	  $tOrelhaDataInvertida = inverteData($tOrelhaData);
	  $tLinguaDataInvertida = inverteData($tLinguaData);

	
			$cabecalho = '
			<table style="margin-top: -20px; padding: 10px 10px 10px 10px; width: 850px;">
				<tr>
					<td>
						<img width="100px" src="../../../img/cc.png">
					</td>
					<td style="">
						<p style="text-align: center; font-size: 12px;">
							ESTADO DO CEARÁ<br>
							GOVERNO MUNICIPAL DE CROATÁ<br>
							SECRETARIA MUNICIPAL DE SAÚDE<br>
							"CUIDANDO BEM DE VOCÊ"
						</p>						
					</td>
					<td>
						<img style="margin-left: 4rem;" width="170px" src="../../../img/logo.png">
					</td>
				</tr>
			<center><b style="margin-bottom: 20px;">"PROGRAMA CROATÁ CRIANÇA"</b></center>
			</table>
			
			';

			$dadosPais = '
			<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DOS PAIS</center></div>
				<br>
				<table>
					<tr>
						<td>
							<b>Nome da mãe:</b> <u>'.$nomeMae.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Idade:</b> <u>'.$idadeMae.'</u>
						</td>
						<td>
							<b style="margin-left:120px;">Profissão:</b> <u>'.$profissaoMae.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Nº de consultas de pré-natal:</b> <u>'.$numConsulPN.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Filhos nascidos vivos:</b> <u>'.$filhosVivo.'</u>
						</td>
						<td>
							<b style="margin-left:30px;">Mortos:</b> <u>'.$filhosMorto.'</u>
						</td>
						<td>
							<b style="margin-left:30px;">Aborto:</b> <u>'.$filhosAborto.'</u>
						</td>
					</tr>
				</table>
				<hr>
				<table>
					<tr>
						<td>
							<b>Nome da Pai:</b> <u>'.$nomePai.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Idade:</b> <u>'.$idadePai.'</u>
						</td>
						<td>
							<b style="margin-left:120px;">Profissão:</b> <u>'.$profissaoPai.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Renda Familiar:</b> <u>R$ '.$rendaFamiliar.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Nº de membros da familia:</b> <u>'.$numMembrosFamilia.'</u>
						</td>
						<td>
							<b style="margin-left:120px;">ACS:</b> <u>'.$acs.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Realizou pré-natal em qual município:</b> <u>'.$municipioPreNatal.'</u>
						</td>
					</tr>
				</table>
				<hr>
				<table>
					<tr>
						<td>
							<b>Observações:</b> <u>'.$observacao.'</u>
						</td>
					</tr>
				</table>
			';

			$dadosCrianca = '
				<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DO RECÉM-NASCIDO</center></div>
				<br>
				<table>
					<tr>
						<td>
							<b>Nome do RN:</b> <u>'.$nomeChild.'</u>
						</td>
						<td>
							<b>Data de Nascimento:</b> <u>'.$dataNascimentoInvertida.'</u>
						</td>
						<td>
							<b>Hora:</b> <u>'.$horaNascimento.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Idade Gestacional:</b> <u>'.$idadeGestacional.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Sexo:</b> <u>'.$sexoCrianca.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Tipo de Parto:</b> <u>'.$partoCrianca.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Peso:</b> <u>'.$pesoCrianca.' g</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Estatura:</b> <u>'.$alturaCrianca.' cm</u>
						</td>
					</tr>
				</table>

			';

			$dadosTestes = '
				<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DOS TESTES</center></div>
				<br>	
				<table>
					<tr>
						<td>
							<b>Teste do Pezinho:</b> <u>'.$tPDataInvertida.'</u>
						</td>
						<td>
							<b>Resultado:</b> <u>'.$tPResul.'</u>
						</td>
						<td>
							<b>Teste da Orelhinha:</b> <u>'.$tOrelhaDataInvertida.'</u>
						</td>
						<td>
							<b>Resultado:</b> <u>'.$tOrelhaResul.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Teste da Linguinha:</b> <u>'.$tLinguaDataInvertida.'</u>
						</td>
						<td>
							<b>Resultado:</b> <u>'.$tLinguaResul.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>PC:</b> <u>'.$pCCrianca.' cm</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>PC:</b> <u>'.$pCCrianca.' cm</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Apgar 1º:</b> <u>'.$apgar1.'</u>
						</td>
						<td>
							<b>Apgar 5º:</b> <u>'.$apgar5.'</u>
						</td>
					</tr>
				</table>
				';

				$dadosVacinas = '
				<br>
				<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DAS VACINAS</center></div>
				<br>	
				<table border=1 color=black>
					<tr>
						<td>
							<b style="margin-left:20px; margin-right:20px;">Tipo</b>
						</td>
						<td>
							<b style="margin-left:20px; margin-right:20px;">Aplicação 1</b>
						</td>
						<td>
							<b style="margin-left:20px; margin-right:20px;">Aplicação 2</b>
						</td>
						<td>
							<b style="margin-left:20px; margin-right:20px;">Aplicação 3</b>
						</td>
						<td>
							<b style="margin-left:20px; margin-right:20px;">Reforço 1</b>
						</td>
						<td>
							<b style="margin-left:20px; margin-right:20px;">Reforço 2</b>
						</td>
					</tr>
					<tr>
						<td>
							<b style="margin-left:20px; margin-right:20px;">'.$tipoBCG.'</b>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl1BCG.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl2BCG.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl3BCG.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref1BCG.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref2BCG.'</p>
						</td>
					</tr>
					<tr>
						<td>
							<b style="margin-left:20px; margin-right:20px;">'.$tipoHepB.'</b>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl1HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl2HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl3HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref1HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref2HepB.'</p>
						</td>
					</tr>
					<tr>
						<td>
							<b style="margin-left:20px; margin-right:20px;">'.$tipoPenta.'</b>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl1Penta.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl2Penta.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl3Penta.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref1Penta.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref2Penta.'</p>
						</td>
					</tr>
					<tr>
						<td>
							<b style="margin-left:3px;">'.$tipoPneumo10.'</b>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl1Pneumo10.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl2Pneumo10.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl3Pneumo10.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref1Pneumo10.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref2Pneumo10.'</p>
						</td>
					</tr>
					<tr>
						<td>
							<b style="margin-left:20px; margin-right:20px;">'.$tipoHepB.'</b>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl1HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl2HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$apl3HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref1HepB.'</p>
						</td>
						<td>
							<p style="margin-left:20px; margin-right:20px;">'.$ref2HepB.'</p>
						</td>
					</tr>
				</table>
				';

			$dompdf->load_html($cabecalho.$dadosPais.$dadosCrianca.$dadosTestes.$dadosVacinas);


	//Renderizar o html
	$dompdf->render();

	//Exibibir a página
	$dompdf->stream(
		"perfil.pdf", 
		array(
			"Attachment" => false //Para realizar o download somente alterar para true
		)
	);
?>