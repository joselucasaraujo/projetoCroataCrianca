<?php 
	$pegaDados = listar("tb_crianca");

foreach ($pegaDados as $key):
	echo $key->nomeCrianca;
endforeach;
 ?>