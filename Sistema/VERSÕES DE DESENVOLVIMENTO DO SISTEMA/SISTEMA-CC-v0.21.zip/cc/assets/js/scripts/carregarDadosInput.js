					//SEXO CRIANCA
					$(function(){
		    var valorDaDiv = $(".divSexoID").text();    
		    $("#sexoID").val(valorDaDiv);
		});
					//TIPO DE PARTO CRIANCA
					$(function(){
		    var valorDaDiv = $(".divTipoDePartoID").text();    
		    $("#tipoDePartoID").val(valorDaDiv);
		});