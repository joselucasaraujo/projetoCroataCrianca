<?php
				    $conexao = conectar();

				        	 if (isset($_POST['logar'])) {
				        	 	          $usuario = trim(strip_tags($_POST['campoLogin'])); //remove espaçoes e tags
                             	$senha = trim(strip_tags($_POST['campoSenha'])); //remove espaçoes e tags

                             	$select = "SELECT * FROM tb_usuario WHERE login_usuario=:usuario AND senha_usuario=:senha";
                              
                             	try{
                             	  $result = $conexao->prepare($select);
                                  $result->bindParam(':usuario', $usuario, PDO::PARAM_STR);
                                  $result->bindParam(':senha', $senha, PDO::PARAM_STR);
                                  $result->execute();
                                  $contar = $result->rowCount();
                                  if ($contar>0) {
                                    
                                    $_SESSION['login'] = $usuario; 
                                    $_SESSION['senha'] = $senha;
                                   
                                    $_SESSION['msg'] = '<div class="alert alert-success text-center" role="alert">
                                    Bem vindo!
                                  </div>
                                  ';

                                  	header("Location: home");

                                  }else{
                                    $_SESSION['msg'] = '<div class="alert alert-danger text-center" role="alert">
                                    Senha ou Nome de Usuário incorretos!
                                  </div>';
                                  }

                             	}catch(PDOException $e){
                                  echo $e;
                                }
				        	 }
?>