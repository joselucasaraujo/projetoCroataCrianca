<html>
	<head>
		<title>Not Found 404</title>
		<?php 
			include("partials/header.php");
		 ?>
	</head>
	<body class="">
		 <h1 class="p-5">Página não encontrada</h1>
	</body>
</html>