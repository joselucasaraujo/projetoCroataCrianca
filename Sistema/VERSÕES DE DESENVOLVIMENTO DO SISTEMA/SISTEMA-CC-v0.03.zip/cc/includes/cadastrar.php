<form action="" method="POST" class="">

		<div class="row">
			<div class="col-md">
  
  <!-- ############################# DADOS DA MÃE ############################# -->
	<?php include_once 'partials/home/dadosMae.php'; ?>
		
		<!-- ############################# DADOS DO PAI ############################# -->
		
	<?php include_once 'partials/home/dadosPai.php'; ?>
		
		<!-- ############################# DADOS DA CRIANÇA ####################################### -->
	
	<?php include_once 'partials/home/dadosCrianca.php'; ?>
		<!-- ############################# VACINAS ####################################### -->

	<?php include_once 'partials/home/vacinas.php'; ?>


		<!-- ############################# TESTES ####################################### -->

			 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseTeste" aria-expanded="false" aria-controls="collapseTeste">
				    Testes
			 </button>

				<div class="collapse" id="collapseTeste">
				  <div class="card card-body">
				  		asdasd
				  </div>
				 </div>


						<button type="submit" class=" btn-success btn-block border border-success">Cadastrar</button>
						<button type="reset" class=" btn-primary text-light btn-block border border-primary" style="margin-top: 0px;">Limpar</button>
		
</form>
