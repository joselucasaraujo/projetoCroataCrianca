	 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePai" aria-expanded="false" aria-controls="collapsePai">
				    Dados do Pai
		 </button>
				<div class="collapse" id="collapsePai">
				  <div class="card card-body">
				  	
				  		<div class="row">
								<div class="form-group form-group col-md col-sm">	
									<label for="nomemae">Nome do Pai:</label>
									<input class="form-control form-control-sm" type="text" name="nomepai" id="nomepai" placeholder="Digite o nome do pai">
								</div>
							</div>
							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="idadepai">Idade:</label>
									<input class="form-control form-control-sm" type="number" name="idadepai" id="idadepai" placeholder="Digite a idade do pai">
								</div>
								<div class="form-group col-md-6 col-sm">
									<label for="profissaopai">Profissão:</label>
									<input class="form-control form-control-sm" type="text" name="profissaopai" id="profissaopai" placeholder="Digite a profissão do pai">
								</div>
							</div>
							<div class="row">
								<div class="form-group col-md-4 col-sm">
									<label for="nummen">Nº de membros da família:</label>
									<input class="form-control form-control-sm" type="number" name="nummen" id="rendaf">
								</div>
								<div class="form-group col-md-4 col-sm">
									<label for="rendaf">Renda Familiar:</label>
									<input class="form-control form-control-sm" type="number" name="rendaf" id="rendaf">
								</div>
								<div class="form-group col-md-4 col-sm">
									<label for="acs">ACS:</label>
									<input class="form-control form-control-sm" type="text" name="acs" id="acs" placeholder="Digite o nome do Agente Comunitário de Saúde" required>
								</div>
							</div>
							<div class="row">
								<div class="form-group col-md col-sm">
									<label>Observações:</label>
									<textarea class="form-control form-control-sm" name="obs" rows="4" cols="50"></textarea>	
								</div>
							</div>

				  </div>
				 </div> 