
				 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseMae" aria-expanded="true" aria-controls="collapseMae">
				    Dados da Mãe
				  </button>
				<div class="collapse" id="collapseMae">
				  <div class="card card-body">
				    <div class="row">
						<div class="form-group col-md col-sm">	
							<label for="nomemae">Nome da Mãe:</label>
							<input class="form-control form-control-sm" type="text" name="nomemae" id="nomemae" placeholder="Digite o nome da mãe">
						</div>
					</div>

					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="idademae">Idade:</label>
							<input class="form-control form-control-sm" type="number" name="idademae" id="idademae" placeholder="Digite a idade da mãe">
						</div>
						<div class="form-group col-md-6 col-sm">
							<label for="profissaomae">Profissão:</label>
							<input class="form-control form-control-sm" type="text" name="profissaomae" id="profissaomae" placeholder="Digite a profissão da mãe">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="cprenatal">Nº de consultas de pré-natal:</label>
							<input class="form-control form-control-sm" type="number" name="cprenatal" id="cprenatal">
						</div>
						<div class="form-group col-md-3">
							<label for="filhosvivo">Filhos Nascidos Vivos:</label>
							<input class="form-control form-control-sm" type="number"  name="filhosvivo" id="filhosvivo" size="5px">
						</div>
						<div class="form-group col-md-3">
							<label for="filhosmorto">Mortos:</label>
							<input class="form-control form-control-sm" type="number" name="filhosmorto" id="filhosmorto">
						</div>
						<div class="form-group col-md-3">
							<label for="filhosaborto">Aborto:</label>
							<input class="form-control form-control-sm" type="number" name="filhosaborto" id="filhosaborto">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md col-sm">	
							<label for="municipiopn">Município de realização do pré-natal:</label>
							<input class="form-control form-control-sm" type="text" name="municipiopn" id="municipiopn" placeholder="Realizou pré-natal em qual município?">
						</div> 
					</div>
							  </div>
							</div>	
						</div>
					</div>