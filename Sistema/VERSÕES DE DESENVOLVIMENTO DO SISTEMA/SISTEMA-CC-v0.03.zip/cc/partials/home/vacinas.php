
			 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseVac" aria-expanded="false" aria-controls="collapseVac">
				    Vacinas
			 </button>

				<div class="collapse" id="collapseVac">
				  <div class="card card-body">
				  	<!-- VAC01 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="BCG" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

										  	<!-- VAC02 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="HepB" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

										  	<!-- VAC03 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Penta" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

										  	<!-- VAC04 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Pneumo 10" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

										  	<!-- VAC05 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="VIP" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

										  	<!-- VAC06 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Rotavírus" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

																  	<!-- VAC07 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Meningo C" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

																  	<!-- VAC08 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Tríplice viral" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

																  	<!-- VAC09 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Tetra viral" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

																  	<!-- VAC10 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="DTP" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

																  	<!-- VAC011 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="Hep A" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

																  	<!-- VAC012 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="VOP" type="text" name="" id="" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="" id="" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
				  </div>
				 </div> 