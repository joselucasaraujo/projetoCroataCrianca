 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
				    Dados da Criança
		 </button>
				<div class="collapse" id="collapseCrianca">
				  <div class="card card-body">
	
					<div class="row">
						<div class="form-group col-md col-sm">
							<label for="nomern">Nome do RN:</label>
							<input class="form-control form-control-sm" type="text" name="nomern" id="nomern" placeholder="Digite o nome do recém nascido">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="datarn">Data de Nascimento</label>
							<input class="form-control form-control-sm" type="date" name="datarn" id="hora">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="hora">Hora:</label>
							<input class="form-control form-control-sm" type="text" name="hora" id="hora">
						</div>
						<div class="form-group col-md-2 col-sm">
							<label for="sexo">Sexo:</label>
							<input class="form-control form-control-sm" type="text" name="sexo" id="sexo">
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="tipo">Tipo de parto:</label>
							<input class="form-control form-control-sm" type="text" name="tipo" id=tipo">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="peso">Peso:</label>
							<input class="form-control form-control-sm" type="number" name="peso" id="peso">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="altura">Altura:</label>
							<input class="form-control form-control-sm" type="number" name="altura" id="altura">
						</div>
						<div class="form-group col-md-3 col-sm">
							
						</div>
						<div class="form-group col-md-3 col-sm">
							
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-8 col-sm">
							<label for="end">Endereço:</label>
							<input class="form-control form-control-sm" type="text" name="end" id="end" placeholder="Ex: Rua Antonio Saturnino, Caroba">
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="localidade">Localidade:</label>
							<input class="form-control form-control-sm" type="text" name="localidade" id="localidade" placeholder="Ex: Sede">
						</div>
					</div>
					</div>	

				</div>