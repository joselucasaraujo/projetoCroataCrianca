<?php 
	function atualizar( $id, $tabela, $attributes ){

		//conexao

		$pdo = conectar();

		$values = null;


		foreach( $attributes as $key => $value ){

			$values.= $key .'= :'.$key.',';
		}

		$values = (rtrim($values, ','));

		$atualizar = $pdo->prepare("UPDATE $tabela SET $values WHERE id=:id");
		$attributes['id'] = $id;
		return 	$atualizar->execute($attributes);
	}
?>