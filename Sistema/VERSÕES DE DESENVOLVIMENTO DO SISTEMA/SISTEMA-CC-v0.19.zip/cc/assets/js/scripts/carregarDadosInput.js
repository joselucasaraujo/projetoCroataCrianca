//######################DADOS DA CRIANÇA#########################################
					//NOME DO RN
					$(function(){
		    var valorDaDiv = $(".divNomeRNID").text();    
		    $("#nomeRNID").val(valorDaDiv);
		});
					//DATA DE NASCIMENTO DO RN
					$(function(){
		    var valorDaDiv = $(".divDataRNID").text();    
		    $("#dataRNID").val(valorDaDiv);
		});
					//HORA
					$(function(){
		    var valorDaDiv = $(".divHoraID").text();    
		    $("#horaID").val(valorDaDiv);
		});
					//SEXO
					$(function(){
		    var valorDaDiv = $(".divSexoID").text();    
		    $("#sexoID").val(valorDaDiv);
		});
					//TIPO DE PARTO
					$(function(){
		    var valorDaDiv = $(".divTipoDePartoID").text();    
		    $("#tipoDePartoID").val(valorDaDiv);
		});
					//PESO
					$(function(){
		    var valorDaDiv = $(".divPesoID").text();    
		    $("#pesoID").val(valorDaDiv);
		});
					//ALTURA
					$(function(){
		    var valorDaDiv = $(".divAlturaID").text();    
		    $("#alturaID").val(valorDaDiv);
		});
					//IDADE GESTACIONAL
					$(function(){
		    var valorDaDiv = $(".divIdadeGestacionalID").text();    
		    $("#idadeGestacionalID").val(valorDaDiv);
		});
					//ENDERECO
					$(function(){
		    var valorDaDiv = $(".divEnderecoID").text();    
		    $("#enderecoID").val(valorDaDiv);
		});
					//LOCALIDADE
					$(function(){
		    var valorDaDiv = $(".divLocalidadeID").text();    
		    $("#localidadeID").val(valorDaDiv);
		});
//######################DADOS DA MAE#########################################
					//NOME DA MAE
					$(function(){
		    var valorDaDiv = $(".divNomeMaeID").text();    
		    $("#nomeMaeID").val(valorDaDiv);
		});
					//IDADE DA MAE
					$(function(){
		    var valorDaDiv = $(".divIdadeMaeID").text();    
		    $("#idadeMaeID").val(valorDaDiv);
		});
					//PROFISSAO DA MAE
					$(function(){
		    var valorDaDiv = $(".divProfissaoMaeID").text();    
		    $("#profissaoMaeID").val(valorDaDiv);
		});
					//NUMERO DE CONSULTAS NO PRE-NATAL
					$(function(){
		    var valorDaDiv = $(".divConsultaPreNatalID").text();    
		    $("#consultaPreNatalID").val(valorDaDiv);
		});
					//FILHOS VIVOS
					$(function(){
		    var valorDaDiv = $(".divFilhosVivoID").text();    
		    $("#filhosVivoID").val(valorDaDiv);
		});
					//FILHOS MORTOS
					$(function(){
		    var valorDaDiv = $(".divFilhosMortoID").text();    
		    $("#filhosMortoID").val(valorDaDiv);
		});
					//FILHOS ABORTO
					$(function(){
		    var valorDaDiv = $(".divFilhosAbortoID").text();    
		    $("#filhosAbortoID").val(valorDaDiv);
		});
					//MUNICIPIO PRE-NATAL
					$(function(){
		    var valorDaDiv = $(".divMunicipioPreNatalID").text();    
		    $("#municipioPreNatalID").val(valorDaDiv);
		});
//######################DADOS DA MAE#########################################
					//NOME DO PAI
					$(function(){
		    var valorDaDiv = $(".divNomePaiID").text();    
		    $("#nomePaiID").val(valorDaDiv);
		});
					//IDADE DO PAI
					$(function(){
		    var valorDaDiv = $(".divIdadePaiID").text();    
		    $("#idadePaiID").val(valorDaDiv);
		});
					//PROFISSAO DO PAI
					$(function(){
		    var valorDaDiv = $(".divProfissaoPaiID").text();    
		    $("#profissaoPaiID").val(valorDaDiv);
		});
					//NUMERO DE MEMBROS DA FAMILIA
					$(function(){
		    var valorDaDiv = $(".divNumeroMembrosFamiliaID").text();    
		    $("#numeroMembrosFamiliaID").val(valorDaDiv);
		});
					//RENDA FAMILIAR
					$(function(){
		    var valorDaDiv = $(".divRendaFamiliarID").text();    
		    $("#rendaFamiliarID").val(valorDaDiv);
		});
					//ACS
					$(function(){
		    var valorDaDiv = $(".divAcsID").text();    
		    $("#acsID").val(valorDaDiv);
		});
					//OBS
					$(function(){
		    var valorDaDiv = $(".divObsID").text();    
		    $("#obsID").val(valorDaDiv);
		});
//######################DADOS DOS TESTES#########################################					
					//DATA TESTE PEZINHO
					$(function(){
		    var valorDaDiv = $(".divDataTestePezinhoID").text();    
		    $("#dataTestePezinhoID").val(valorDaDiv);
		});
					//RESULTADO DO TESTE DO PEZINHO
					$(function(){
		    var valorDaDiv = $(".divResultadoTestePezinhoID").text();    
		    $("#resultadoTestePezinhoID").val(valorDaDiv);
		});
					//DATA TESTE ORELHA
					$(function(){
		    var valorDaDiv = $(".divDataTesteOrelhaID").text();    
		    $("#dataTesteOrelhaID").val(valorDaDiv);
		});
					//RESULTADO DO TESTE DA ORELHA
					$(function(){
		    var valorDaDiv = $(".divResultadoTesteOrelhaID").text();    
		    $("#resultadoTesteOrelhaID").val(valorDaDiv);
		});
					//DATA TESTE LINGUA
					$(function(){
		    var valorDaDiv = $(".divDataTesteLinguaID").text();    
		    $("#dataTesteLinguaID").val(valorDaDiv);
		});
					//RESULTADO TESTE LINGUA
					$(function(){
		    var valorDaDiv = $(".divResultadoTesteLinguaID").text();    
		    $("#resultadoTesteLinguaID").val(valorDaDiv);
		});
					//PERIMETRO CEFALICO
					$(function(){
		    var valorDaDiv = $(".divPerimetroCefalicoID").text();    
		    $("#perimetroCefalicoID").val(valorDaDiv);
		});
					//PERIMETRO TORAXICO
					$(function(){
		    var valorDaDiv = $(".divPerimetroToraxicoID").text();    
		    $("#perimetroToraxicoID").val(valorDaDiv);
		});
					//APGAR 1
					$(function(){
		    var valorDaDiv = $(".divApgar1ID").text();    
		    $("#apgar1ID").val(valorDaDiv);
		});
					//APGAR 5
					$(function(){
		    var valorDaDiv = $(".divApgar5ID").text();    
		    $("#apgar5ID").val(valorDaDiv);
		});
//######################DADOS DA VACINA BCG#########################################
					//TIPO BCG
					$(function(){
		    var valorDaDiv = $(".divTipoBCGID").text();    
		    $("#tipoBCGID").val(valorDaDiv);
		});
					//APL 1 BCG
					$(function(){
		    var valorDaDiv = $(".divApl1BCGID").text();    
		    $("#apl1BCGID").val(valorDaDiv);
		});
					//APL 2 BCG
					$(function(){
		    var valorDaDiv = $(".divApl2BCGID").text();    
		    $("#apl2BCGID").val(valorDaDiv);
		});	
					//APL 3 BCG
					$(function(){
		    var valorDaDiv = $(".divApl3BCGID").text();    
		    $("#apl3BCGID").val(valorDaDiv);
		});	
					//REF 1 BCG
					$(function(){
		    var valorDaDiv = $(".divRef1BCGID").text();    
		    $("#ref1BCGID").val(valorDaDiv);
		});	
					//REF 2 BCG
					$(function(){
		    var valorDaDiv = $(".divRef2BCGID").text();    
		    $("#ref2BCGID").val(valorDaDiv);
		});	
//######################DADOS DA VACINA HEP B#########################################
					//TIPO HEP B
					$(function(){
		    var valorDaDiv = $(".divTipoHepBID").text();    
		    $("#tipoHepBID").val(valorDaDiv);
		});
					//APL 1 HEP B
					$(function(){
		    var valorDaDiv = $(".divApl1HepBID").text();    
		    $("#apl1HepBID").val(valorDaDiv);
		});
					//APL 2 HEP B
					$(function(){
		    var valorDaDiv = $(".divApl2BCGID").text();    
		    $("#apl2BCGID").val(valorDaDiv);
		});	
					//APL 3 HEP B
					$(function(){
		    var valorDaDiv = $(".divApl3BCGID").text();    
		    $("#apl3BCGID").val(valorDaDiv);
		});	
					//REF 1 HEP B
					$(function(){
		    var valorDaDiv = $(".divRef1BCGID").text();    
		    $("#ref1BCGID").val(valorDaDiv);
		});	
					//REF 2 HEP B
					$(function(){
		    var valorDaDiv = $(".divRef2BCGID").text();    
		    $("#ref2BCGID").val(valorDaDiv);
		});