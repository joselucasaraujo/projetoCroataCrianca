<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseMae" aria-expanded="true" aria-controls="collapseMae">
    Dados da Mãe
</button>
	<?php 
		$listarDadosMae = listarPorId($idMae, "tb_mae");
            foreach ($listarDadosMae as $mother) : 	
    ?>
	<div class="collapse" id="collapseMae">
	    <div class="card card-body">
		    <div class="row">
				<div class="form-group col-md col-sm">	
					<label for="nomeMae">Nome da Mãe:</label>
					<div class="divNomeMaeID" hidden><?php echo $mother->nome_mae;?></div>
					<input class="form-control form-control-sm" type="text" name="nomeMaeEdit" id="nomeMaeID" placeholder="Digite o nome da mãe">
				</div>
			</div>
	<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="idadeMae">Idade:</label>
					<div class="divIdadeMaeID" hidden><?php echo $mother->idade;?></div>
					<input class="form-control form-control-sm" type="number" name="idadeMaeEdit" id="idadeMaeID" placeholder="Digite a idade da mãe">
				</div>
				<div class="form-group col-md-6 col-sm">
					<label for="profissaoMae">Profissão:</label>
					<div class="divProfissaoMaeID" hidden><?php echo $mother->profissao;?></div>
					<input class="form-control form-control-sm" type="text" name="profissaoMaeEdit" id="profissaoMaeID" placeholder="Digite a profissão da mãe">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="consultaPreNatal">Nº de consultas de pré-natal:</label>
					<div class="divConsultaPreNatalID" hidden><?php echo $mother->numConPN;?></div>
					<input class="form-control form-control-sm" type="number" name="consultaPreNatalEdit" id="consultaPreNatalID">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosVivo">Filhos Nascidos Vivos:</label>
					<div class="divFilhosVivoID" hidden><?php echo $mother->filhosV;?></div>
					<input class="form-control form-control-sm" type="number"  name="filhosVivoEdit" id="filhosVivoID" size="5px">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosMorto">Mortos:</label>
					<div class="divFilhosMortoID" hidden><?php echo $mother->filhosM;?></div>
					<input class="form-control form-control-sm" type="number" name="filhosMortoEdit" id="filhosMortoID">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosAborto">Aborto:</label>
					<div class="divFilhosAbortoID" hidden><?php echo $mother->filhosA;?></div>
					<input class="form-control form-control-sm" type="number" name="filhosAbortoEdit" id="filhosAbortoID">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="form-group col-md col-sm">	
					<label for="municipioPreNatal">Município de realização do pré-natal:</label>
					<div class="divMunicipioPreNatalID" hidden><?php echo $mother->municipioPN;?></div>
					<input class="form-control form-control-sm" type="text" name="municipioPreNatalEdit" id="municipioPreNatalID" placeholder="Realizou pré-natal em qual município?">
				</div> 
			</div>
		</div>
	</div>	
<?php endforeach; ?>