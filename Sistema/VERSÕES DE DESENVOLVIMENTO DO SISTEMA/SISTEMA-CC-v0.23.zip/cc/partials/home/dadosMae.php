
				 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseMae" aria-expanded="true" aria-controls="collapseMae">
				    Dados da Mãe
				  </button>
				<div class="collapse" id="collapseMae">
				  <div class="card card-body">
				    <div class="row">
						<div class="form-group col-md col-sm">	
							<label for="nomeMae">Nome da Mãe: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="text" id="nomeMaeID" placeholder="Digite o nome da mãe" name="nomeMae" required>
						</div>
					</div>
<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="idadeMae">Idade: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="number" id="idadeMaeID" placeholder="Digite a idade da mãe" name="idadeMae" required>
						</div>
						<div class="form-group col-md-6 col-sm">
							<label for="profissaoMae">Profissão: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="text" id="profissaoMaeID" placeholder="Ex: Carteiro" name="profissaoMae" required>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="consultaPreNatal">Nº de consultas de pré-natal: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="number" id="consultaPreNatalID" name="consultaPreNatal" required>
						</div>
						<div class="form-group col-md-3">
							<label for="filhosVivo">Filhos Nascidos Vivos: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="number" id="filhosVivoID" size="5px" name="filhosVivo" required>
						</div>
						<div class="form-group col-md-3">
							<label for="filhosMorto">Mortos: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="number" id="filhosMortoID" name="filhosMorto" required>
						</div>
						<div class="form-group col-md-3">
							<label for="filhosAborto">Aborto: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="number" id="filhosAbortoID" name="filhosAborto" required>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md col-sm">	
							<label for="municipioPreNatal">Município de realização do pré-natal: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="text" id="municipioPreNatalID" placeholder="Realizou pré-natal em qual município?" name="municipioPreNatal" required>
						</div> 
					</div>
				</div>
		</div>	
	</div>
</div>