<button class="btn-azulbb text-light  btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePai" aria-expanded="false" aria-controls="collapsePai">
		    Dados do Pai
 </button>
 <?php $listarDadosPai = listarPorId($idPai, "tb_pai");
            foreach ($listarDadosPai as $dad) : 	
    ?>
	<div class="collapse" id="collapsePai">
	  <div class="card card-body">
	  	
	  		<div class="row">
					<div class="form-group form-group col-md col-sm">	
						<label for="nomePai">Nome do Pai:</label>
						<div class="divNomePaiID" hidden><?php echo $dad->nome_pai;?></div>
						<input class="form-control form-control-sm" type="text" name="nomePaiEdit" id="nomePaiID" placeholder="Digite o nome do pai">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-3 col-sm">
						<label for="idadePai">Idade:</label>
						<div class="divIdadePaiID" hidden><?php echo $dad->idade;?></div>
						<input class="form-control form-control-sm" type="number" name="idadePaiEdit" id="idadePaiID" placeholder="Digite a idade do pai">
					</div>
					<div class="form-group col-md-6 col-sm">
						<label for="profissaoPai">Profissão:</label>
						<div class="divProfissaoPaiID" hidden><?php echo $dad->profissao;?></div>
						<input class="form-control form-control-sm" type="text" name="profissaoPaiEdit" id="profissaoPaiID" placeholder="Digite a profissão do pai">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-4 col-sm">
						<label for="numeroMembrosFamilia">Nº de membros da família:</label>
						<div class="divNumeroMembrosFamiliaID" hidden><?php echo $dad->membrosFamilia;?></div>
						<input class="form-control form-control-sm" type="number" name="numeroMembrosFamiliaEdit" id="numeroMembrosFamiliaID">
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="rendaFamiliar">Renda Familiar:</label>
						<div class="divRendaFamiliarID" hidden><?php echo $dad->renda;?></div>
						<input class="form-control form-control-sm" step="00.01" type="number" name="rendaFamiliarEdit" id="rendaFamiliarID">
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="acs">ACS:</label>
						<div class="divAcsID" hidden><?php echo $dad->acs;?></div>
						<input class="form-control form-control-sm" type="text" name="acsEdit" id="acsID" placeholder="Digite o nome do Agente Comunitário de Saúde">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md col-sm">
						<label>Observações:</label>
						<div class="divObsID" hidden><?php echo $dad->obs;?></div>
						<textarea class="form-control form-control-sm" id="obsID" name="obsEdit" rows="4" cols="50"></textarea>	
					</div>
				</div>
    <?php endforeach; ?>				
	  </div>
	 </div> 