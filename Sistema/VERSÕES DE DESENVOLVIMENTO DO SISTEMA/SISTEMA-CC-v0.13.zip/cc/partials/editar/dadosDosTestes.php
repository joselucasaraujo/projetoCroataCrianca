 <button class="btn-azulbb text-light btn-block  border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseTeste" aria-expanded="false" aria-controls="collapseTeste">
				    Testes
</button>
<?php 
$listarDadosTestes = listarPorIdCrianca($idChild, "tb_testes");
	foreach ($listarDadosTestes as $teste) : 	
?>
<div class="collapse" id="collapseTeste">
  <div class="card card-body">
  	<?php $dataTP = $teste->tPData;
			  $dataTestePezinhoTratada = date('Y-m-d', strtotime($dataTP)); ?>
  			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="dataTestePezinho">Data teste do Pézinho:</label>
					<div class="divDataTestePezinhoID" hidden><?php echo $dataTestePezinhoTratada; ?></div>
					<input class="form-control form-control-sm" type="date" name="dataTestePezinhoEdit" id="dataTestePezinhoID" placeholder="">
				</div>

				<div class="form-group col-md-3 col-sm">
					<label for="resultadoTestePezinho">Resultado teste do Pézinho:</label>
					<div class="divResultadoTestePezinhoID" hidden><?php echo $teste->tPResul;?></div>
					<input class="form-control form-control-sm" type="text" name="resultadoTestePezinhoEdit" id="resultadoTestePezinhoID" placeholder="">
				</div>
				<?php $dataTO = $teste->tOrelhaData;
			  		$dataTesteOrelhaTratada = date('Y-m-d', strtotime($dataTO)); ?>
				<div class="form-group col-md-3 col-sm">
					<label for="dataTesteOrelha">Data teste da Orelha:</label>
					<div class="divDataTesteOrelhaID" hidden><?php echo $dataTesteOrelhaTratada; ?></div>
					<input class="form-control form-control-sm" type="date" name="dataTesteOrelhaEdit" id="dataTesteOrelhaID" placeholder="">
				</div>

				<div class="form-group col-md-3 col-sm">
					<label for="resultadoTesteOrelha">Resultado teste da Orelha:</label>
					<div class="divResultadoTesteOrelhaID" hidden><?php echo $teste->tOrelhaResul;?></div>
					<input class="form-control form-control-sm" type="text" name="resultadoTesteOrelhaEdit" id="resultadoTesteOrelhaID" placeholder="">
				</div>
			</div>
<hr>		<?php $dataTL = $teste->tLinguaData;
			  		$dataTesteLinguaTratada = date('Y-m-d', strtotime($dataTL)); ?>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="dataTesteLingua">Data teste da Lingua:</label>
					<div class="divDataTesteLinguaID" hidden><?php echo $dataTesteLinguaTratada; ?></div>
					<input class="form-control form-control-sm" type="date" name="dataTesteLinguaEdit" id="dataTesteLinguaID" placeholder="">
				</div>

				<div class="form-group col-md-3 col-sm">
					<label for="resultadoTesteLingua">Resultado teste da Lingua:</label>
					<div class="divResultadoTesteLinguaID" hidden><?php echo $teste->tLinguaResul;?></div>
					<input class="form-control form-control-sm" type="text" name="resultadoTesteLinguaEdit" id="resultadoTesteLinguaID" placeholder="">
				</div>

				<div class="form-group col-md-3 col-sm">
					<label for="perimetroCefalico">Perímetro cefálico:</label>
					<div class="divPerimetroCefalicoID" hidden><?php echo $teste->perCefalicoCrianca;?></div>
					<input class="form-control form-control-sm" type="number" step="00.01" name="perimetroCefalicoEdit" id="perimetroCefalicoID" placeholder="">
				</div>

				<div class="form-group col-md-3 col-sm">
					<label for="perimetroToraxico">Perímetro toraxico:</label>
					<div class="divPerimetroToraxicoID" hidden><?php echo $teste->perToraxico;?></div>
					<input class="form-control form-control-sm" type="number" step="00.01" name="perimetroToraxicoEdit" id="perimetroToraxicoID" placeholder="">
				</div>
			</div>
<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="apgar1">Apgar 1º:</label>
					<div class="divApgar1ID" hidden><?php echo $teste->apgar1Crianca;?></div>
					<input class="form-control form-control-sm" type="number" name="apgar1Edit" id="apgar1ID" placeholder="">
				</div>

				<div class="form-group col-md-3 col-sm">
					<label for="apgar5">Apgar 5º:</label>
					<div class="divApgar5ID" hidden><?php echo $teste->apgar5Crianca;?></div>
					<input class="form-control form-control-sm" type="number" name="apgar5Edit" id="apgar5ID" placeholder="">
				</div>
			</div>
		<?php endforeach; ?>
  </div>
 </div>