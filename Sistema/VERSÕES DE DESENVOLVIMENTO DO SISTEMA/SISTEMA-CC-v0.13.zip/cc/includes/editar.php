<?php $chave = trim(strip_tags($_GET['id'])); //remove espaçoes e tags
      $chave = str_replace("\"", "",$chave); //remove aspas
      $chave = str_replace("\'", "",$chave); //remove aspas 
?>
<form action="" method="POST">			

<!-- ############################# DADOS DA CRIANÇA ###################################### -->
	<?php include'partials/editar/dadosCriancaEditar.php'; ?>	

<!-- ############################# DADOS DA MAE ###################################### -->
	<?php include'partials/editar/dadosMaeEditar.php'; ?>	

<!-- ############################# DADOS DO PAI ###################################### -->
	<?php include'partials/editar/dadosPaiEditar.php'; ?>	

<!-- ############################# DADOS DOS TESTES ###################################### -->
	<?php include'partials/editar/dadosDosTestes.php'; ?>	

<!-- ############################# DADOS DAS VACINAS ###################################### -->
	<?php include'partials/editar/dadosDasVacinas.php'; ?>	

	<button name="attCriancaEdit" value="<?php echo $idChild ?>" class="btn-success btn-block border border-success" type="submit">Atualizar</button>
</form>