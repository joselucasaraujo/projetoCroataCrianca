 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
				    Dados da Criança
		 </button>
				<div class="collapse" id="collapseCrianca">
				  <div class="card card-body">
	
					<div class="row">
						<div class="form-group col-md-6 col-sm-6">
							<label for="nomeRN">Nome do RN: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="text" id="nomeRNID" placeholder="Digite o nome do recém nascido" name="nomeRN" required>
						</div>
						<div class="form-group col-md-6 col-sm-6">
							<label for="acs">ACS: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="text" id="acsID" placSeholder="Digite o nome do Agente Comunitário de Saúde" name="acs" required>
						</div>

					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="dataRN">Data de Nascimento: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="date" id="dataRNID" name="dataRN" required>
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="hora">Hora:</label>
							<input class="form-control form-control-sm" type="text" id="horaID" name="hora">
						</div>
						<div class="form-group col-md-2 col-sm">
							  <label for="sexoID">Sexo: <b class="text-danger">*</b></label>
							    <select class="form-control form-control-sm" id="sexoID" name="sexo" required>
							      <option value="">Selecione </option>
							      <option value="masculino">Masculino</option>
							      <option value="feminino">Feminino</option>
							    </select>
						</div>
						<div class="form-group col-md-4 col-sm">
							  <label for="tipoDePartoID">Tipo de parto: <b class="text-danger">*</b></label>
							    <select class="form-control form-control-sm" id="tipoDePartoID" name="tipoDeParto" required>
							    							      <
							      <option value="">Selecione</option>
							      <option value="Normal">Normal</option>
							      <option value="Cesariana">Cesariana</option>
							    </select>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="peso">Peso:</label>
							<input class="form-control form-control-sm" step="00.01" type="number" id="pesoID" name="peso">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="altura">Altura:</label>
							<input class="form-control form-control-sm" type="number" id="alturaID" name="altura">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="idadeGestacional">Idade gestacional: <b class="text-danger">*</b></label>
							<input class="form-control form-control-sm" type="number" id="idadeGestacionalID" name="idadeGestacional" required>
						</div>
						<div class="form-group col-md-3 col-sm">
									
								
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-4 col-sm">
							<label for="endereco">Endereço:</label>
							<input class="form-control form-control-sm" type="text" id="enderecoID" placeholder="Ex: Rua Antonio Saturnino, Caroba" name="endereco">
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="localidadeID">Localidade: <b class="text-danger">*</b></label>
							 <select class="form-control form-control-sm" id="localidadeID" name="localidade" required>
							      <option value="">Selecione</option>
							      <option value="Croatá">Croatá (sede)</option>
							      <option value="Betânia">Betânia</option>
							      <option value="Barra do sotero">Barra do sotero</option>
							      <option value="Lagoa da cruz">Lagoa da cruz</option>
							      <option value="São roque">São roque</option>
							      <option value="Vista alegre">Vista alegre</option>
							      <option value="Santa tereza">Santa tereza</option>
							      <option value="Repartição">Repartição</option>
							  </select>
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="cartaoSUS">Cartão do SUS: </label>
							<input class="form-control form-control-sm" type="text" maxlength="15" id="cartaoSUSID" placeholder="" name="cartaoSUS">
						</div>
					</div>
					</div>	

				</div>