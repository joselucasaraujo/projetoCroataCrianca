<?php
	
	$id = $_GET['id'];
	//referenciar o DomPDF com namespace

	// include autoloader
	require_once('dompdf_config.inc.php');

	//Criando a Instancia
	$dompdf = new DOMPDF();

			$cabecalho = '
			<table style="margin-top: -20px; padding: 10px 10px 10px 10px; width: 850px;">
				<tr>
					<td>
						<img width="100px" src="../../../img/cc.png">
					</td>
					<td style="">
						<p style="text-align: center; font-size: 12px;">
							ESTADO DO CEARÁ<br>
							GOVERNO MUNICIPAL DE CROATÁ<br>
							SECRETARIA MUNICIPAL DE SAÚDE<br>
							"CUIDANDO BEM DE VOCÊ"
						</p>						
					</td>
					<td>
						<img style="margin-left: 4rem;" width="170px" src="../../../img/logo.png">
					</td>
				</tr>
			<center><b style="margin-bottom: 20px;">"PROGRAMA CROATÁ CRIANÇA"</b></center>
			</table>
			
			';

			$dadosPais = '
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DOS PAIS</center></div>
			';

			$dompdf->load_html($cabecalho.$dadosPais);


	//Renderizar o html
	$dompdf->render();

	//Exibibir a página
	$dompdf->stream(
		"perfil", 
		array(
			"Attachment" => false //Para realizar o download somente alterar para true
		)
	);
?>