 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseTeste" aria-expanded="false" aria-controls="collapseTeste">
				    Testes
			 </button>

				<div class="collapse" id="collapseTeste">
				  <div class="card card-body">
				  			<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="dataTestePezinho">Data teste do Pézinho:</label>
									<input class="form-control form-control-sm" type="date" name="dataTestePezinho" id="dataTestePezinhoID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTestePezinho">Resultado teste do Pézinho:</label>
									<input class="form-control form-control-sm" type="text" name="resultadoTestePezinho" id="resultadoTestePezinhoID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="dataTesteOrelha">Data teste da Orelha:</label>
									<input class="form-control form-control-sm" type="date" name="dataTesteOrelha" id="dataTesteOrelhaID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTesteOrelha">Resultado teste da Orelha:</label>
									<input class="form-control form-control-sm" type="text" name="resultadoTesteOrelha" id="resultadoTesteOrelhaID" placeholder="">
								</div>
							</div>

							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="dataTesteLingua">Data teste da Lingua:</label>
									<input class="form-control form-control-sm" type="date" name="dataTesteLingua" id="dataTesteLinguaID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTesteLingua">Resultado teste da Lingua:</label>
									<input class="form-control form-control-sm" type="text" name="resultadoTesteLingua" id="resultadoTesteLinguaID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="perimetroCefalico">Perímetro cefálico:</label>
									<input class="form-control form-control-sm" type="number" step="00.01" name="perimetroCefalico" id="perimetroCefalicoID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="perimetroToraxico">Perímetro toraxico:</label>
									<input class="form-control form-control-sm" type="number" step="00.01" name="perimetroToraxico" id="perimetroToraxico" placeholder="">
								</div>
							</div>

							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="apgar1">Apgar 1º:</label>
									<input class="form-control form-control-sm" type="number" name="apgar1" id="apgar1ID" placeholder="">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="apgar5">Apgar 5º:</label>
									<input class="form-control form-control-sm" type="number" name="apgar5" id="apgar5ID" placeholder="">
								</div>
							</div>
				  </div>
				 </div>