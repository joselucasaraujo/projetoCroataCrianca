<?php
  if (isset($_GET['excluirCrianca']) AND $_GET['excluirCrianca'] == true) {
    $id = filter_input(INPUT_GET,'id', FILTER_SANITIZE_NUMBER_INT);

  
    $registroExcluidoPesos = deletar("idCrianca",$id,"tb_peso_semana");
##################################################################################
    $registroExcluidoVacina = deletar("idCrianca",$id,"tb_vacinas");
##################################################################################

    $registroExcluidoTestes = deletar("idCrianca",$id,"tb_testes");
##################################################################################

##################################################################################
    $listarPorIdCriancaPai = listarPorId($id, "tb_crianca");
    foreach ($listarPorIdCriancaPai as $pai) {
    	$idPai = $pai->idPai; 
    }
    $listarPorIdCriancaMae = listarPorId($id, "tb_crianca");
    foreach ($listarPorIdCriancaMae as $mae) {
    	$idMae = $mae->idMae; 
    }
    $registroExcluidoCrianca = deletar("id",$id,"tb_crianca");
##################################################################################
    $registroExcluidoPai = deletar("id",$idPai,"tb_pai");
##################################################################################      
    $registroExcluidoMae = deletar("id",$idMae,"tb_mae");
##################################################################################   


		if($registroExcluidoCrianca
			&& $registroExcluidoPai
			&& $registroExcluidoMae
			&& $registroExcluidoVacina
			&& $registroExcluidoTestes
			&& $registroExcluidoPesos){
			header("Location:home&p=listar&pag=1");
		}else{
			echo "Ocorreu um erro ao excluir o cliente";
		}  
  }

   if (isset($_GET['excluirPeso']) AND $_GET['excluirPeso'] == true) {
    $id = filter_input(INPUT_GET,'id', FILTER_SANITIZE_NUMBER_INT);
    $keyID = $_GET['key'];
##################################################################################
    $registroExcluidoPesos = deletar("id",$id,"tb_peso_semana");
##################################################################################



        if($registroExcluidoPesos){
            header("Location:home&p=peso&id=".$keyID."&pag=1");
        }else{
            echo "Ocorreu um erro ao excluir o cliente";
        }  
  }
 ?>