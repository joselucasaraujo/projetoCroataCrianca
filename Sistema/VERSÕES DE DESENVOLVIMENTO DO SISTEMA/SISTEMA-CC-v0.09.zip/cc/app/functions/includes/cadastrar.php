<?php 
 $conexao = conectar();
 

if (isset($_POST['cadCrianca'])) {

##DADOS DA MAE##############################################################################################################################

   $nomeMae = filter_input(INPUT_POST, 'nomeMae', FILTER_SANITIZE_STRING); //texto
   $idadeMae = filter_input(INPUT_POST, 'idadeMae', FILTER_SANITIZE_NUMBER_INT); //numero inteiro
   $profissaoMae = filter_input(INPUT_POST, 'profissaoMae' , FILTER_SANITIZE_STRING);
   $consultaPreNatal = filter_input(INPUT_POST, 'consultaPreNatal', FILTER_SANITIZE_NUMBER_INT);
   $filhosVivo = filter_input(INPUT_POST, 'filhosVivo', FILTER_SANITIZE_NUMBER_INT);
   $filhosMorto = filter_input(INPUT_POST, 'filhosMorto', FILTER_SANITIZE_NUMBER_INT);
   $filhosAborto = filter_input(INPUT_POST, 'filhosAborto', FILTER_SANITIZE_NUMBER_INT);
   $municipioPreNatal = filter_input(INPUT_POST, 'municipioPreNatal', FILTER_SANITIZE_STRING);

##DADOS DO PAI##############################################################################################################################

   $nomePai = filter_input(INPUT_POST, 'nomePai', FILTER_SANITIZE_STRING);
   $idadePai = filter_input(INPUT_POST, 'idadePai', FILTER_SANITIZE_NUMBER_INT);
   $profissaoPai = filter_input(INPUT_POST, 'profissaoPai', FILTER_SANITIZE_STRING);
   $numeroMembrosFamilia = filter_input(INPUT_POST, 'numeroMembrosFamilia', FILTER_SANITIZE_NUMBER_INT);
   $rendaFamiliar = $_POST['rendaFamiliar']; //DOUBLE TEM Q SER NORMAL PRA PEGAR DOUBLE
   $acs = filter_input(INPUT_POST, 'acs', FILTER_SANITIZE_STRING);
   $obs = filter_input(INPUT_POST, 'obs', FILTER_SANITIZE_STRING);


##DADOS DA CRIANÇA##############################################################################################################################

   $nomeRN = filter_input(INPUT_POST, 'nomeRN', FILTER_SANITIZE_STRING);
   $dataRN = inverteData($_POST['dataRN']); //data 
   $hora = $_POST['hora'];
   $sexo = $_POST['sexo'];
   $tipoDeParto = filter_input(INPUT_POST, 'tipoDeParto', FILTER_SANITIZE_STRING);
   $peso = $_POST['peso'];
   $altura = $_POST['altura'];
   $idadeGestacional = filter_input(INPUT_POST, 'idadeGestacional', FILTER_SANITIZE_NUMBER_INT);
   $endereco = filter_input(INPUT_POST, 'endereco', FILTER_SANITIZE_STRING);
   $localidade = filter_input(INPUT_POST, 'localidade', FILTER_SANITIZE_STRING);

##VACINAS ################################################################################################################################


  ##BCG
  $tipoBCG = filter_input(INPUT_POST, 'tipoBCG', FILTER_SANITIZE_STRING);
  $apl1BCG = inverteData($_POST['apl1BCG']);
  $apl2BCG = inverteData($_POST['apl2BCG']);
  $apl3BCG = inverteData($_POST['apl3BCG']);
  $ref1BCG = inverteData($_POST['ref1BCG']);
  $ref2BCG = inverteData($_POST['ref2BCG']);

  ##HepB
  $tipoHepB = filter_input(INPUT_POST, 'tipoHepB', FILTER_SANITIZE_STRING);
  $apl1HepB = inverteData($_POST['apl1HepB']);
  $apl2HepB = inverteData($_POST['apl2HepB']);
  $apl3HepB = inverteData($_POST['apl3HepB']);
  $ref1HepB = inverteData($_POST['ref1HepB']);
  $ref2HepB = inverteData($_POST['ref2HepB']);

  ##Penta
  $tipoPenta = filter_input(INPUT_POST, 'tipoPenta', FILTER_SANITIZE_STRING);
  $apl1Penta = inverteData($_POST['apl1Penta']);
  $apl2Penta = inverteData($_POST['apl2Penta']);
  $apl3Penta = inverteData($_POST['apl3Penta']);
  $ref1Penta = inverteData($_POST['ref1Penta']);
  $ref2Penta = inverteData($_POST['ref2Penta']);

  ##Pneumo 10
  $tipoPneumo10 = filter_input(INPUT_POST, 'tipoPneumo10', FILTER_SANITIZE_STRING);
  $apl1Pneumo10 = inverteData($_POST['apl1Pneumo10']);
  $apl2Pneumo10 = inverteData($_POST['apl2Pneumo10']);
  $apl3Pneumo10 = inverteData($_POST['apl3Pneumo10']);
  $ref1Pneumo10 = inverteData($_POST['ref1Pneumo10']);
  $ref2Pneumo10 = inverteData($_POST['ref2Pneumo10']);

  ##VIP
  $TipoVip = filter_input(INPUT_POST, 'TipoVip', FILTER_SANITIZE_STRING);
  $apl1Vip = inverteData($_POST['apl1Vip']);
  $apl2Vip = inverteData($_POST['apl2Vip']);
  $apl3Vip = inverteData($_POST['apl3Vip']);
  $ref1Vip = inverteData($_POST['ref1Vip']);
  $ref2Vip = inverteData($_POST['ref2Vip']);

  ##ROTAVIRUS
  $tipoRotavirus = filter_input(INPUT_POST, 'tipoRotavirus', FILTER_SANITIZE_STRING);
  $apl1Rotavirus = inverteData($_POST['apl1Rotavirus']);
  $apl2Rotavirus = inverteData($_POST['apl2Rotavirus']);
  $apl3Rotavirus = inverteData($_POST['apl3Rotavirus']);
  $ref1Rotavirus = inverteData($_POST['ref1Rotavirus']);
  $ref2Rotavirus = inverteData($_POST['ref2Rotavirus']);

  ##Meningo C
  $tipoMeningoC = filter_input(INPUT_POST, 'tipoMeningoC', FILTER_SANITIZE_STRING);
  $apl1MeningoC = inverteData($_POST['apl1MeningoC']);
  $apl2MeningoC = inverteData($_POST['apl2MeningoC']);
  $apl3MeningoC = inverteData($_POST['apl3MeningoC']);
  $ref1MeningoC = inverteData($_POST['ref1MeningoC']);
  $ref2MeningoC = inverteData($_POST['ref2MeningoC']);

  ##Tríplice viral
  $tipoTripliceViral = filter_input(INPUT_POST, 'tipoTripliceViral', FILTER_SANITIZE_STRING);
  $apl1TripliceViral = inverteData($_POST['apl1TripliceViral']);
  $apl2TripliceViral = inverteData($_POST['apl2TripliceViral']);
  $apl3TripliceViral = inverteData($_POST['apl3TripliceViral']);
  $ref1TripliceViral = inverteData($_POST['ref1TripliceViral']);
  $ref2TripliceViral = inverteData($_POST['ref2TripliceViral']);

  ##Tetra viral
  $tetraViral = filter_input(INPUT_POST, 'tetraViral', FILTER_SANITIZE_STRING);
  $apl1TetraViral = inverteData($_POST['apl1TetraViral']);
  $apl2TetraViral = inverteData($_POST['apl2TetraViral']);
  $apl3TetraViral = inverteData($_POST['apl3TetraViral']);
  $ref1TetraViral = inverteData($_POST['ref1TetraViral']);
  $ref2TetraViral = inverteData($_POST['ref2TetraViral']);

  ##DTP
  $tipoDTP = filter_input(INPUT_POST, 'tipoDTP', FILTER_SANITIZE_STRING);
  $apl1DTP = inverteData($_POST['apl1DTP']);
  $apl2DTP = inverteData($_POST['apl2DTP']);
  $apl3DTP = inverteData($_POST['apl3DTP']);
  $ref1DTP = inverteData($_POST['ref1DTP']);
  $ref2DTP = inverteData($_POST['ref2DTP']);

  ##HEP A
  $tipoDTP = filter_input(INPUT_POST, 'tipoHepA', FILTER_SANITIZE_STRING);
  $apl1DTP = inverteData($_POST['apl1HepA']);
  $apl2DTP = inverteData($_POST['apl2HepA']);
  $apl3DTP = inverteData($_POST['apl3HepA']);
  $ref1DTP = inverteData($_POST['ref1HepA']);
  $ref2DTP = inverteData($_POST['ref2HepA']);

    ##VOP
  $tipoVOP = filter_input(INPUT_POST, 'tipoVOP', FILTER_SANITIZE_STRING);
  $apl1VOP = inverteData($_POST['apl1VOP']);
  $apl2VOP = inverteData($_POST['apl2VOP']);
  $apl3VOP = inverteData($_POST['apl3VOP']);
  $ref1VOPID = inverteData($_POST['ref1VOPID']);
  $ref2VOPID = inverteData($_POST['ref2VOPID']);

    ##VARICELA
  $tipoVaricela = filter_input(INPUT_POST, 'tipoVaricela', FILTER_SANITIZE_STRING);
  $apl1Varicela = inverteData($_POST['apl1Varicela']);
  $apl2Varicela = inverteData($_POST['apl2Varicela']);

    ##outros
  $outros = filter_input(INPUT_POST, 'outros', FILTER_SANITIZE_STRING);
  $apl1Outros = inverteData($_POST['apl1Outros']);
  $apl2Outros = inverteData($_POST['apl2Outros']);
  $apl3Outros = inverteData($_POST['apl3Outros']);
  $ref1Outros = inverteData($_POST['ref1Outros']);
  $ref2Outros = inverteData($_POST['ref2Outros']);

##TESTES##############################################################################################################################

  $dataTestePezinho = inverteData($_POST['dataTestePezinho']);
  $resultadoTestePezinho = filter_input(INPUT_POST, 'resultadoTestePezinho', FILTER_SANITIZE_STRING);
  $dataTesteOrelha = inverteData($_POST['dataTesteOrelha']);
  $resultadoTesteOrelha = filter_input(INPUT_POST, 'resultadoTesteOrelha', FILTER_SANITIZE_STRING);
  $dataTesteLingua = inverteData($_POST['dataTesteLingua']);
  $resultadoTesteLingua = filter_input(INPUT_POST, 'resultadoTesteLingua', FILTER_SANITIZE_STRING);
  $perimetroCefalico = $_POST['perimetroCefalico'];
  $perimetroToraxico = $_POST['perimetroToraxico'];
  $apgar1 = $_POST['apgar1'];
  $apgar5 = $_POST['apgar5'];

##PESO##############################################################################################################################
 
  $semanaPeso = filter_input(INPUT_POST, 'semanaPeso', FILTER_SANITIZE_NUMBER_INT);
  $dataPeso = inverteData($_POST['dataPeso']);
  $pesoData = $_POST['pesoData'];

  if (empty(array_filter($_POST))) {
      $mensagem = "Todos os campos são obrigatorios";
    }else {

##KEY##############################################################################################################################

    include 'assets/files/strRandown.php'; //Script de gerar string aleatoria

    $string = randString(20); // chama a função q gera a string aleatoria

    $codificada = md5($string);// Transforma em hash
      
##PAI##############################################################################################################################        
      $attributes_pai = [
        "nome_pai" => $nomePai,
        "idade" => $idadePai,
        "membrosFamilia" => $numeroMembrosFamilia,
        "renda" => $rendaFamiliar,
        "profissao" => $profissaoPai
      ];

      $paiCadastrado = cadastrar("tb_pai", $attributes_pai);
      $mensagem = ($paiCadastrado) ? "Pai cadastrado com sucesso!!" : "Ocorreu um erro ao cadastrar";
      $idPai = $paiCadastrado;
##DADOS DA MAE##############################################################################################################################
      $attributes_mae = [
        "nome_mae" => $nomeMae,
        "idade" => $idadeMae,
        "profissao" => $profissaoMae,
        "numConPN" => $consultaPreNatal,
        "filhosV" => $filhosVivo,
        "filhosM" => $filhosMorto,
        "filhosA" => $filhosAborto,
        "municipioPN" => $municipioPreNatal
      ];

      $maeCadastrado = cadastrar("tb_mae", $attributes_mae);
      $mensagem = ($maeCadastrado) ? "Mae cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
      $idMae = $maeCadastrado;
##DADOS DA CRIANÇA##############################################################################################################################
      $attributes_baby = [
        "nomeCrianca" => $nomeRN,
        "partoCrianca" => $tipoDeParto,
        "horaNascCrianca" => $hora,
        "dataNascCrianca" => $dataRN,
        "pesoCrianca" => $peso,
        "alturaCrianca" => $altura,
        "sexoCrianca" => $sexo,
        "endereco" => $endereco,
        "localidade" => $localidade,
        "idPai" => $idPai,
        "idMae" => $idMae,
        "idadeGestacional" => $idadeGestacional,
        "idcrypt" => $codificada
      ];

      $babyCadastrado = cadastrar("tb_crianca", $attributes_baby);
      $mensagem = ($babyCadastrado) ? "Criança cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
    }
}
?>