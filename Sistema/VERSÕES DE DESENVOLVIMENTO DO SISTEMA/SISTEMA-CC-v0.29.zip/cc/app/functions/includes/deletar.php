<?php
  if (isset($_GET['excluirCrianca']) AND $_GET['excluirCrianca'] == true) {
    $id = filter_input(INPUT_GET,'id', FILTER_SANITIZE_NUMBER_INT);

  
    $registroExcluidoPesos = deletar("idCrianca",$id,"tb_peso_semana");
##################################################################################
    $registroExcluidoVacina = deletar("idCrianca",$id,"tb_vacinas");
##################################################################################

    $registroExcluidoTestes = deletar("idCrianca",$id,"tb_testes");
##################################################################################

##################################################################################
    $listarPorIdCriancaPai = listarPorId($id, "tb_crianca");
    foreach ($listarPorIdCriancaPai as $pai) {
    	$idPai = $pai->idPai; 
    }
    $listarPorIdCriancaMae = listarPorId($id, "tb_crianca");
    foreach ($listarPorIdCriancaMae as $mae) {
    	$idMae = $mae->idMae; 
    }
    $registroExcluidoCrianca = deletar("id",$id,"tb_crianca");
##################################################################################
    $registroExcluidoPai = deletar("id",$idPai,"tb_pai");
##################################################################################      
    $registroExcluidoMae = deletar("id",$idMae,"tb_mae");
################################################################################## 
  
    $mensagem = '<div class="alert alert-primary alert-dismissible fade show mt-2 ml-2 mr-2" style="margin-bottom: 0px;" role="alert">
                  <strong>Criança excluida com sucesso!</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>';

	}
   if (isset($_GET['excluirPeso']) AND $_GET['excluirPeso'] == true) {
    $id = filter_input(INPUT_GET,'id', FILTER_SANITIZE_NUMBER_INT);
    $keyID = $_GET['key'];
##################################################################################
    $registroExcluidoPesos = deletar("id",$id,"tb_peso_semana");
##################################################################################



        if($registroExcluidoPesos){
            header("Location:home&p=peso&id=".$keyID."&pag=1");
        }else{
            echo "Ocorreu um erro ao excluir o cliente";
        }  
  }
 ?>