<?php 

if (isset($_POST['cadPesoBB'])) {

 $idCrianca =  $_POST['cadPesoBB'];
 $cadSemanaPeso = filter_input(INPUT_POST, 'cadSemanaPeso', FILTER_SANITIZE_NUMBER_INT);
 $cadDataPeso = $_POST['cadDataPeso'];
 $cadPesoData = $_POST['cadCPesoData'];
 

 $attributes = [
        "idCrianca" => $idCrianca,
        "semana" => $cadSemanaPeso,
        "data" => $cadDataPeso,
        "peso" => $cadPesoData
      ];

    $cadSemanaBB = cadastrar("tb_peso_semana", $attributes);

    $mensagem = ($cadSemanaBB) ? '<div class="alert alert-primary alert-dismissible fade show ml-2 mt-2 mr-2" style="margin-bottom: 0px;" role="alert">
                  <strong>Peso semanal adicionado com sucesso!</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>' : "Ocorreu um erro ao cadastrar";
}


 ?>