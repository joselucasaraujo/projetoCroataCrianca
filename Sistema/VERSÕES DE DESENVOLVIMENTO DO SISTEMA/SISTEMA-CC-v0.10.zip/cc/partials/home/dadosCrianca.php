 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
				    Dados da Criança
		 </button>
				<div class="collapse" id="collapseCrianca">
				  <div class="card card-body">
	
					<div class="row">
						<div class="form-group col-md col-sm">
							<label for="nomeRN">Nome do RN:</label>
							<input class="form-control form-control-sm" type="text" name="nomeRN" id="nomeRNID" placeholder="Digite o nome do recém nascido">
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="dataRN">Data de Nascimento</label>
							<input class="form-control form-control-sm" type="date" name="dataRN" id="dataRNID">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="hora">Hora:</label>
							<input class="form-control form-control-sm" type="text" name="hora" id="horaID">
						</div>
						<div class="form-group col-md-2 col-sm">
							  <label for="sexoID">Sexo:</label>
							    <select class="form-control form-control-sm" name="sexo" id="sexoID">
							      <option value="m">Masculino</option>
							      <option value="f">Feminino</option>
							    </select>
						</div>
						<div class="form-group col-md-4 col-sm">
							  <label for="tipoDePartoID">Tipo de parto:</label>
							    <select class="form-control form-control-sm" name="tipoDeParto" id="tipoDePartoID">
							      <option value="Normal">Normal</option>
							      <option value="Cesariana">Cesariana</option>
							    </select>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="peso">Peso:</label>
							<input class="form-control form-control-sm" step="00.01" type="number" name="peso" id="pesoID">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="altura">Altura:</label>
							<input class="form-control form-control-sm" type="number" name="altura" id="alturaID">
						</div>
						<div class="form-group col-md-3 col-sm">
							<label for="idadeGestacional">Idade gestacional:</label>
							<input class="form-control form-control-sm" type="number" name="idadeGestacional" id="idadeGestacionalID">
						</div>
						<div class="form-group col-md-3 col-sm">
							
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="form-group col-md-8 col-sm">
							<label for="endereco">Endereço:</label>
							<input class="form-control form-control-sm" type="text" name="endereco" id="enderecoID" placeholder="Ex: Rua Antonio Saturnino, Caroba">
						</div>
						<div class="form-group col-md-4 col-sm">
							<label for="localidade">Localidade:</label>
							<input class="form-control form-control-sm" type="text" name="localidade" id="localidadeID" placeholder="Ex: Sede">
						</div>
					</div>
					</div>	

				</div>