//######################DADOS DA VACINA BCG#########################################
					//TIPO BCG
					$(function(){
		    var valorDaDiv = $(".divTipoBCGID").text();    
		    $("#tipoBCGID").val(valorDaDiv);
		});
					//APL 1 BCG
					$(function(){
		    var valorDaDiv = $(".divApl1BCGID").text();    
		    $("#apl1BCGID").val(valorDaDiv);
		});
					//APL 2 BCG
					$(function(){
		    var valorDaDiv = $(".divApl2BCGID").text();    
		    $("#apl2BCGID").val(valorDaDiv);
		});	
					//APL 3 BCG
					$(function(){
		    var valorDaDiv = $(".divApl3BCGID").text();    
		    $("#apl3BCGID").val(valorDaDiv);
		});	
					//REF 1 BCG
					$(function(){
		    var valorDaDiv = $(".divRef1BCGID").text();    
		    $("#ref1BCGID").val(valorDaDiv);
		});	
					//REF 2 BCG
					$(function(){
		    var valorDaDiv = $(".divRef2BCGID").text();    
		    $("#ref2BCGID").val(valorDaDiv);
		});	
//######################DADOS DA VACINA HEP B#########################################
					//TIPO HEP B
					$(function(){
		    var valorDaDiv = $(".divTipoHepBID").text();    
		    $("#tipoHepBID").val(valorDaDiv);
		});
					//APL 1 HEP B
					$(function(){
		    var valorDaDiv = $(".divApl1HepBID").text();    
		    $("#apl1HepBID").val(valorDaDiv);
		});
					//APL 2 HEP B
					$(function(){
		    var valorDaDiv = $(".divApl2BCGID").text();    
		    $("#apl2BCGID").val(valorDaDiv);
		});	
					//APL 3 HEP B
					$(function(){
		    var valorDaDiv = $(".divApl3BCGID").text();    
		    $("#apl3BCGID").val(valorDaDiv);
		});	
					//REF 1 HEP B
					$(function(){
		    var valorDaDiv = $(".divRef1BCGID").text();    
		    $("#ref1BCGID").val(valorDaDiv);
		});	
					//REF 2 HEP B
					$(function(){
		    var valorDaDiv = $(".divRef2BCGID").text();    
		    $("#ref2BCGID").val(valorDaDiv);
		});