 <div class="form-signin caixaLoginCima bg-rosa shadow-lg">
          <center>
            <img src="assets/img/cc.png" class="centered" width="200px" height="150px">
          </center>
        </div>
      <form class="form-signin caixaLoginBaixo bg-light shadow-lg" action="" method="POST">
        <h2 class="form-signin-heading"></h2>
        <label for="inputEmail" class="sr-only">Nome de usuário</label>
        <input type="text" id="campoLoginID" class="form-control" placeholder="Nome de usuário" name="campoLogin" autofocus>
        <input type="password" name="campoSenha" id="campoSenhaID" class="form-control" placeholder="Senha" >
        <label for="inputPassword" class="sr-only">Senha</label>
        <?php 
          if (isset($_SESSION['msg'])) {
           echo $_SESSION['msg']; 
          }
        ?>
        <div id="foo" class="alert alert-danger d-none text-center animated fadeIn
" role="alert">
          Digite suas credenciais corretamente!
        </div>
        <button class="btn btn-lg btn-rosa btn-block" name="logar" id="logarID" type="button">Entrar</button>
      </form>