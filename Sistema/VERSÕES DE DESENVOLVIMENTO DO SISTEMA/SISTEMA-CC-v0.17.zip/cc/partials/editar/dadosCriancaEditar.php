<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
	    Dados da Criança
</button>
	<?php $listarDadosCrianca = listarPorChave($chave, "tb_crianca");
	            foreach ($listarDadosCrianca as $child) : 
	            $idChild = $child->id;	
	       ?>
<div class="collapse" id="collapseCrianca">
    <div class="card card-body">

		<div class="row">
			<div class="form-group col-md col-sm">
				<label for="nomeRN">Nome do RN:</label>
				<div class="divNomeRNID" hidden><?php echo $child->nomeCrianca;?></div>
				<input class="form-control form-control-sm" type="text" name="nomeRNEdit" id="nomeRNID" placeholder="Digite o nome do recém nascido">
			</div>
		</div>
		<hr>
		<?php $dataNasc = $child->dataNascCrianca;
			$dataNascTratada = date("Y-m-d", strtotime($dataNasc));
		 ?>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="dataRN">Data de Nascimento</label>
				<div class="divDataRNID" hidden><?php 	
				echo $dataNascTratada;
				?></div>
				<input class="form-control form-control-sm" type="date" name="dataRNEdit" id="dataRNID">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="hora">Hora:</label>
				<div class="divHoraID" hidden><?php echo $child->horaNascCrianca;?></div>
				<input class="form-control form-control-sm" type="text" name="horaEdit" id="horaID">
			</div>
			<div class="form-group col-md-2 col-sm">
				  <label for="sexoID">Sexo:</label>
				  <div class="divSexoID" hidden><?php echo $child->sexoCrianca;?></div>
				    <select class="form-control form-control-sm" name="sexoEdit" id="sexoID">
				      <option value="m">Masculino</option>
				      <option value="f">Feminino</option>
				    </select>
			</div>
			<div class="form-group col-md-4 col-sm">
				  <label for="tipoDePartoID">Tipo de parto:</label>
				  <div class="divTipoDePartoID" hidden><?php echo $child->partoCrianca;?></div>
				    <select class="form-control form-control-sm" name="tipoDePartoEdit" id="tipoDePartoID" value="">
				      <option value="Normal">Normal</option>
				      <option value="Cesariana">Cesariana</option>
				    </select>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="peso">Peso:</label>
				<div class="divPesoID" hidden><?php echo $child->pesoCrianca;?></div>
				<input class="form-control form-control-sm" step="00.01" type="number" name="pesoEdit" id="pesoID">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="altura">Altura:</label>
				<div class="divAlturaID" hidden><?php echo $child->alturaCrianca;?></div>
				<input class="form-control form-control-sm" type="number" name="alturaEdit" id="alturaID">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="idadeGestacional">Idade gestacional:</label>
				<div class="divIdadeGestacionalID" hidden><?php echo $child->idadeGestacional;?></div>
				<input class="form-control form-control-sm" type="number" name="idadeGestacionalEdit" id="idadeGestacionalID">
			</div>
			<div class="form-group col-md-3 col-sm">
				
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-8 col-sm">
				<label for="endereco">Endereço:</label>
				<div class="divEnderecoID" hidden><?php echo $child->endereco;?></div>
				<input class="form-control form-control-sm" type="text" name="enderecoEdit" id="enderecoID" placeholder="Ex: Rua Antonio Saturnino, Caroba">
			</div>
			<div class="form-group col-md-4 col-sm">
				<label for="localidade">Localidade:</label>
				<div class="divLocalidadeID" hidden><?php echo $child->localidade;?></div>
				<input class="form-control form-control-sm" type="text" name="localidadeEdit" id="localidadeID" placeholder="Ex: Sede" value="">
			</div>
		</div>
	</div>
	<?php 
		$idMae = $child->idMae;
		$idPai = $child->idPai;
		endforeach; 
	?>
</div>