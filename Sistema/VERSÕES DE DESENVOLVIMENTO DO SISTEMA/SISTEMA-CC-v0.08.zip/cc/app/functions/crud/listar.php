	<?php 
  function listar($tabela){

  	$pdo = conectar();

    $listar = $pdo->query("SELECT * FROM $tabela");
    $listar->execute();
    return $listar->fetchAll(PDO::FETCH_OBJ);
  }

//Listar por ID
function listarPorId($id, $tabela){

	$pdo = conectar();

	$listar = $pdo->query("SELECT * FROM $tabela WHERE id = $id");
	$listar->execute();
	return $listar->fetchAll(PDO::FETCH_OBJ);
}

function listarPorNomeIdadeRenda($nome, $idade, $renda, $tabela){

  $pdo = conectar();

  $listar = $pdo->query("SELECT * FROM $tabela WHERE (nome_pai = '".$nome."') AND (idade = '".$idade."') AND (renda = '".$renda."')");
  $listar->execute();
  return $listar->fetchAll(PDO::FETCH_OBJ);
}
function listarIDPessoa($tabela){

    $pdo = conectar();

    $listar = $pdo->query("SELECT * FROM $tabela");
    $pdo->beginTransaction();
    $listar->execute();
    $pdo->commit();
    $listar->fetchAll(PDO::FETCH_OBJ);
    return $pdo->lastInsertId();
  }

 ?>
 