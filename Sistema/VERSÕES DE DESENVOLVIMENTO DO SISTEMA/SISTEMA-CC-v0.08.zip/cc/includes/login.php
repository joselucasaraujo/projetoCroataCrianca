 <div class="container">
     <div class="animated bounceInDown">
       <?php include'partials/login/caixaLogin.php'; ?>
     </div>
    </div> <!-- /container -->