<?php 
 $conexao = conectar();
 

if (isset($_POST['cadCriancaEdit'])) {

##DADOS DA MAE##############################################################################################################################
   $idChild = $_POST['btnId'];
   $nomeMaeEdit = filter_input(INPUT_POST, 'nomeMaeEdit', FILTER_SANITIZE_STRING); //texto
   $idadeMaeEdit = filter_input(INPUT_POST, 'idadeMaeEdit', FILTER_SANITIZE_NUMBER_INT); //numero inteiro
   $profissaoMaeEdit = filter_input(INPUT_POST, 'profissaoMaeEdit' , FILTER_SANITIZE_STRING);
   $consultaPreNatalEdit = filter_input(INPUT_POST, 'consultaPreNatalEdit', FILTER_SANITIZE_NUMBER_INT);
   $filhosVivoEdit = filter_input(INPUT_POST, 'filhosVivoEdit', FILTER_SANITIZE_NUMBER_INT);
   $filhosMortoEdit = filter_input(INPUT_POST, 'filhosMortoEdit', FILTER_SANITIZE_NUMBER_INT);
   $filhosAbortoEdit = filter_input(INPUT_POST, 'filhosAbortoEdit', FILTER_SANITIZE_NUMBER_INT);
   $municipioPreNatalEdit = filter_input(INPUT_POST, 'municipioPreNatalEdit', FILTER_SANITIZE_STRING);

##DADOS DO PAI##############################################################################################################################

   $nomePaiEdit = filter_input(INPUT_POST, 'nomePaiEdit', FILTER_SANITIZE_STRING);
   $idadePaiEdit = filter_input(INPUT_POST, 'idadePaiEdit', FILTER_SANITIZE_NUMBER_INT);
   $profissaoPaiEdit = filter_input(INPUT_POST, 'profissaoPaiEdit', FILTER_SANITIZE_STRING);
   $numeroMembrosFamiliaEdit = filter_input(INPUT_POST, 'numeroMembrosFamiliaEdit', FILTER_SANITIZE_NUMBER_INT);
   $rendaFamiliarEdit = $_POST['rendaFamiliarEdit']; //DOUBLE TEM Q SER NORMAL PRA PEGAR DOUBLE
   $acsEdit = filter_input(INPUT_POST, 'acsEdit', FILTER_SANITIZE_STRING);
   $obsEdit = filter_input(INPUT_POST, 'obsEdit', FILTER_SANITIZE_STRING);


##DADOS DA CRIANÇA##############################################################################################################################

   $nomeRNEdit = filter_input(INPUT_POST, 'nomeRNEdit', FILTER_SANITIZE_STRING);
   $dataRNEdit = inverteData($_POST['dataRNEdit']); //data 
   $horaEdit = $_POST['horaEdit'];
   $sexoEdit = $_POST['sexoEdit'];
   $tipoDePartoEdit = filter_input(INPUT_POST, 'tipoDePartoEdit', FILTER_SANITIZE_STRING);
   $pesoEdit = $_POST['pesoEdit'];
   $alturaEdit = $_POST['alturaEdit'];
   $idadeGestacionalEdit = filter_input(INPUT_POST, 'idadeGestacionalEdit', FILTER_SANITIZE_NUMBER_INT);
   $enderecoEdit = filter_input(INPUT_POST, 'enderecoEdit', FILTER_SANITIZE_STRING);
   $localidadeEdit = filter_input(INPUT_POST, 'localidadeEdit', FILTER_SANITIZE_STRING);

##VACINAS ################################################################################################################################


  ##BCG
  $tipoBCGEdit = filter_input(INPUT_POST, 'tipoBCGEdit', FILTER_SANITIZE_STRING);
  $apl1BCGEdit = inverteData($_POST['apl1BCGEdit']);
  $apl2BCGEdit = inverteData($_POST['apl2BCGEdit']);
  $apl3BCGEdit = inverteData($_POST['apl3BCGEdit']);
  $ref1BCGEdit = inverteData($_POST['ref1BCGEdit']);
  $ref2BCGEdit = inverteData($_POST['ref2BCGEdit']);

  ##HepB
  $tipoHepBEdit = filter_input(INPUT_POST, 'tipoHepBEdit', FILTER_SANITIZE_STRING);
  $apl1HepBEdit = inverteData($_POST['apl1HepBEdit']);
  $apl2HepBEdit = inverteData($_POST['apl2HepBEdit']);
  $apl3HepBEdit = inverteData($_POST['apl3HepBEdit']);
  $ref1HepBEdit = inverteData($_POST['ref1HepBEdit']);
  $ref2HepBEdit = inverteData($_POST['ref2HepBEdit']);

  ##Penta
  $tipoPentaEdit = filter_input(INPUT_POST, 'tipoPentaEdit', FILTER_SANITIZE_STRING);
  $apl1PentaEdit = inverteData($_POST['apl1PentaEdit']);
  $apl2PentaEdit = inverteData($_POST['apl2PentaEdit']);
  $apl3PentaEdit = inverteData($_POST['apl3PentaEdit']);
  $ref1PentaEdit = inverteData($_POST['ref1PentaEdit']);
  $ref2PentaEdit = inverteData($_POST['ref2PentaEdit']);

  ##Pneumo 10
  $tipoPneumo10Edit = filter_input(INPUT_POST, 'tipoPneumo10Edit', FILTER_SANITIZE_STRING);
  $apl1Pneumo10Edit = inverteData($_POST['apl1Pneumo10Edit']);
  $apl2Pneumo10Edit = inverteData($_POST['apl2Pneumo10Edit']);
  $apl3Pneumo10Edit = inverteData($_POST['apl3Pneumo10Edit']);
  $ref1Pneumo10Edit = inverteData($_POST['ref1Pneumo10Edit']);
  $ref2Pneumo10Edit = inverteData($_POST['ref2Pneumo10Edit']);

  ##VIP
  $tipoVipEdit = filter_input(INPUT_POST, 'TipoVipEdit', FILTER_SANITIZE_STRING);
  $apl1VipEdit = inverteData($_POST['apl1VipEdit']);
  $apl2VipEdit = inverteData($_POST['apl2VipEdit']);
  $apl3VipEdit = inverteData($_POST['apl3VipEdit']);
  $ref1VipEdit = inverteData($_POST['ref1VipEdit']);
  $ref2VipEdit = inverteData($_POST['ref2VipEdit']);

  ##ROTAVIRUS
  $tipoRotavirusEdit = filter_input(INPUT_POST, 'tipoRotavirusEdit', FILTER_SANITIZE_STRING);
  $apl1RotavirusEdit = inverteData($_POST['apl1RotavirusEdit']);
  $apl2RotavirusEdit = inverteData($_POST['apl2RotavirusEdit']);
  $apl3RotavirusEdit = inverteData($_POST['apl3RotavirusEdit']);
  $ref1RotavirusEdit = inverteData($_POST['ref1RotavirusEdit']);
  $ref2RotavirusEdit = inverteData($_POST['ref2RotavirusEdit']);

  ##Meningo C
  $tipoMeningoCEdit = filter_input(INPUT_POST, 'tipoMeningoCEdit', FILTER_SANITIZE_STRING);
  $apl1MeningoCEdit = inverteData($_POST['apl1MeningoCEdit']);
  $apl2MeningoCEdit = inverteData($_POST['apl2MeningoCEdit']);
  $apl3MeningoCEdit = inverteData($_POST['apl3MeningoCEdit']);
  $ref1MeningoCEdit = inverteData($_POST['ref1MeningoCEdit']);
  $ref2MeningoCEdit = inverteData($_POST['ref2MeningoCEdit']);

  ##Tríplice viral
  $tipoTripliceViralEdit = filter_input(INPUT_POST, 'tipoTripliceViralEdit', FILTER_SANITIZE_STRING);
  $apl1TripliceViralEdit = inverteData($_POST['apl1TripliceViralEdit']);
  $apl2TripliceViralEdit = inverteData($_POST['apl2TripliceViralEdit']);
  $apl3TripliceViralEdit = inverteData($_POST['apl3TripliceViralEdit']);
  $ref1TripliceViralEdit = inverteData($_POST['ref1TripliceViralEdit']);
  $ref2TripliceViralEdit = inverteData($_POST['ref2TripliceViralEdit']);

  ##Tetra viral
  $tipoTetraViralEdit = filter_input(INPUT_POST, 'tetraViralEdit', FILTER_SANITIZE_STRING);
  $apl1TetraViralEdit = inverteData($_POST['apl1TetraViralEdit']);
  $apl2TetraViralEdit = inverteData($_POST['apl2TetraViralEdit']);
  $apl3TetraViralEdit = inverteData($_POST['apl3TetraViralEdit']);
  $ref1TetraViralEdit = inverteData($_POST['ref1TetraViralEdit']);
  $ref2TetraViralEdit = inverteData($_POST['ref2TetraViralEdit']);

  ##DTP
  $tipoDTPEdit = filter_input(INPUT_POST, 'tipoDTPEdit', FILTER_SANITIZE_STRING);
  $apl1DTPEdit = inverteData($_POST['apl1DTPEdit']);
  $apl2DTPEdit = inverteData($_POST['apl2DTPEdit']);
  $apl3DTPEdit = inverteData($_POST['apl3DTPEdit']);
  $ref1DTPEdit = inverteData($_POST['ref1DTPEdit']);
  $ref2DTPEdit = inverteData($_POST['ref2DTPEdit']);

  ##HepA
  $tipoHepAEdit = filter_input(INPUT_POST, 'tipoHepAEdit', FILTER_SANITIZE_STRING);
  $apl1HepAEdit = inverteData($_POST['apl1HepAEdit']);
  $apl2HepAEdit = inverteData($_POST['apl2HepAEdit']);
  $apl3HepAEdit = inverteData($_POST['apl3HepAEdit']);
  $ref1HepAEdit = inverteData($_POST['ref1HepAEdit']);
  $ref2HepAEdit = inverteData($_POST['ref2HepAEdit']);

  ##VOP
  $tipoVOPEdit = filter_input(INPUT_POST, 'tipoVOPEdit', FILTER_SANITIZE_STRING);
  $apl1VOPEdit = inverteData($_POST['apl1VOPEdit']);
  $apl2VOPEdit = inverteData($_POST['apl2VOPEdit']);
  $apl3VOPEdit = inverteData($_POST['apl3VOPEdit']);
  $ref1VOPEdit = inverteData($_POST['ref1VOPEdit']);
  $ref2VOPEdit = inverteData($_POST['ref2VOPEdit']);

  ##VARICELA
  $tipoVaricelaEdit = filter_input(INPUT_POST, 'tipoVaricelaEdit', FILTER_SANITIZE_STRING);
  $apl1VaricelaEdit = inverteData($_POST['apl1VaricelaEdit']);
  $apl2VaricelaEdit = inverteData($_POST['apl2VaricelaEdit']);

  ##outros
  $tipoOutrosEdit = filter_input(INPUT_POST, 'outrosEdit', FILTER_SANITIZE_STRING);
  $apl1OutrosEdit = inverteData($_POST['apl1OutrosEdit']);
  $apl2OutrosEdit = inverteData($_POST['apl2OutrosEdit']);
  $apl3OutrosEdit = inverteData($_POST['apl3OutrosEdit']);
  $ref1OutrosEdit = inverteData($_POST['ref1OutrosEdit']);
  $ref2OutrosEdit = inverteData($_POST['ref2OutrosEdit']);

##TESTES##############################################################################################################################

  $dataTestePezinhoEdit = inverteData($_POST['dataTestePezinhoEdit']);
  $resultadoTestePezinhoEdit = filter_input(INPUT_POST, 'resultadoTestePezinhoEdit', FILTER_SANITIZE_STRING);
  $dataTesteOrelhaEdit = inverteData($_POST['dataTesteOrelhaEdit']);
  $resultadoTesteOrelhaEdit = filter_input(INPUT_POST, 'resultadoTesteOrelhaEdit', FILTER_SANITIZE_STRING);
  $dataTesteLinguaEdit = inverteData($_POST['dataTesteLinguaEdit']);
  $resultadoTesteLinguaEdit = filter_input(INPUT_POST, 'resultadoTesteLinguaEdit', FILTER_SANITIZE_STRING);
  $perimetroCefalicoEdit = $_POST['perimetroCefalicoEdit'];
  $perimetroToraxicoEdit = $_POST['perimetroToraxicoEdit'];
  $apgar1Edit = $_POST['apgar1Edit'];
  $apgar5Edit = $_POST['apgar5Edit'];

##PESO##############################################################################################################################
 
  $semanaPesoEdit = filter_input(INPUT_POST, 'semanaPesoEdit', FILTER_SANITIZE_NUMBER_INT);
  $dataPesoEdit = inverteData($_POST['dataPesoEdit']);
  $pesoDataEdit= $_POST['pesoDataEdit'];

  if (empty(array_filter($_POST))) {
      $mensagem = "Todos os campos são obrigatorios";
    }elseif (empty($_POST['nomeMae'])) {
      # code...
      $mensagem = "Preencha o nome da mae";
    }else {

##KEY##############################################################################################################################

    include 'assets/files/strRandown.php'; //Script de gerar string aleatoria

    $string = randString(20); // chama a função q gera a string aleatoria

    $codificada = md5($string);// Transforma em hash



      
##PAI##############################################################################################################################

      $listarPai = listarPorId($idChild, "tb_crianca");
      foreach ($listarPai as $child) {
        $idDad = $child->idPai;
      }

      $attributes_paiEdit = [
        "nome_pai" => $nomePaiEdit,
        "idade" => $idadePaiEdit,
        "membrosFamilia" => $numeroMembrosFamiliaEdit,
        "renda" => $rendaFamiliarEdit,
        "profissao" => $profissaoPaiEdit,
        "acs" => $acsEdit,
        "obs" => $obsEdit
      ];

      $paiCadastrado = atualizar($idDad, "tb_pai", $attributes_paiEdit);
      $mensagem = ($paiCadastrado) ? "Pai cadastrado com sucesso!!" : "Ocorreu um erro ao cadastrar";
      $idPai = $paiCadastrado;
##DADOS DA MAE##############################################################################################################################

      $listarMae = listarPorId($idChild, "tb_crianca");
      foreach ($listarMae as $child) {
        $idMother = $child->idMae;
      }

      $attributes_maeEdit = [
        "nome_mae" => $nomeMaeEdit,
        "idade" => $idadeMaeEdit,
        "profissao" => $profissaoMaeEdit,
        "numConPN" => $consultaPreNatalEdit,
        "filhosV" => $filhosVivoEdit,
        "filhosM" => $filhosMortoEdit,
        "filhosA" => $filhosAbortoEdit,
        "municipioPN" => $municipioPreNatalEdit
      ];

      $maeCadastrado = atualizar($idMother, "tb_mae", $attributes_maeEdit);
      $mensagem = ($maeCadastrado) ? "Mae cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
      $idMae = $maeCadastrado;
##DADOS DA CRIANÇA##############################################################################################################################
      $attributes_babyEdit = [
        "nomeCrianca" => $nomeRNEdit,
        "partoCrianca" => $tipoDePartoEdit,
        "horaNascCrianca" => $horaEdit,
        "dataNascCrianca" => $dataRNEdit,
        "pesoCrianca" => $pesoEdit,
        "alturaCrianca" => $alturaEdit,
        "sexoCrianca" => $sexoEdit,
        "endereco" => $enderecoEdit,
        "localidade" => $localidadeEdit,
        "idPai" => $idPai,
        "idMae" => $idMae,
        "idadeGestacional" => $idadeGestacionalEdit,
        "idcrypt" => $codificada
      ];

      $babyCadastrado = atualizar($idChild, "tb_crianca", $attributes_babyEdit);
      $mensagem = ($babyCadastrado) ? "Criança cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
      $idCrianca = $babyCadastrado;
##DADOS DA VACINA BCG##############################################################################################################################

      $listarBCG = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarBCG as $BCG) {
        $idBCG = $BCG->id;
      }

      $attributes_vacinaBCGEdit = [
        "apl1" => $apl1BCGEdit,
        "apl2" => $apl2BCGEdit,
        "apl3" => $apl3BCGEdit,
        "ref1" => $ref1BCGEdit,
        "ref2" => $ref2BCGEdit,
        "tipo" => $tipoBCGEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaBCGCadastrado = atualizar($idBCG, "tb_vacinas", $attributes_vacinaBCGEdit);
      $mensagem = ($vacinaBCGCadastrado) ? "Vacina BCG cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA HepB##############################################################################################################################

      $listarHepB = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarHepB as $HepB) {
        $idHepB = $HepB->id;
      }

      $attributes_vacinaHepBEdit = [
        "apl1" => $apl1HepBEdit,
        "apl2" => $apl2HepBEdit,
        "apl3" => $apl3HepBEdit,
        "ref1" => $ref1HepBEdit,
        "ref2" => $ref2HepBEdit,
        "tipo" => $tipoHepBEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaHepBCadastrado = atualizar($idHepB, "tb_vacinas", $attributes_vacinaHepBEdit);
      $mensagem = ($vacinaHepBCadastrado) ? "Vacina HepB cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA Penta##############################################################################################################################

      $listarPenta = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarPenta as $Penta) {
        $idPenta = $Penta->id;
      }

      $attributes_vacinaPentaEdit = [
        "apl1" => $apl1PentaEdit,
        "apl2" => $apl2PentaEdit,
        "apl3" => $apl3PentaEdit,
        "ref1" => $ref1PentaEdit,
        "ref2" => $ref2PentaEdit,
        "tipo" => $tipoPentaEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaPentaCadastrado = atualizar($idPenta, "tb_vacinas", $attributes_vacinaPentaEdit);
      $mensagem = ($vacinaPentaCadastrado) ? "Vacina Penta cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA Pneumo10##############################################################################################################################

      $listarPneumo10 = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarPneumo10 as $Pneumo10) {
        $idPneumo10 = $Pneumo10->id;
      }

      $attributes_vacinaPneumo10Edit = [
        "apl1" => $apl1Pneumo10Edit,
        "apl2" => $apl2Pneumo10Edit,
        "apl3" => $apl3Pneumo10Edit,
        "ref1" => $ref1Pneumo10Edit,
        "ref2" => $ref2Pneumo10Edit,
        "tipo" => $tipoPneumo10Edit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaPneumo10Cadastrado = atualizar($idPneumo10,"tb_vacinas", $attributes_vacinaPneumo10Edit);
      $mensagem = ($vacinaPneumo10Cadastrado) ? "Vacina Pneumo10 cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";   
##DADOS DA VACINA Vip##############################################################################################################################

      $listarVip = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarVip as $Vip) {
        $idVip = $Vip->id;
      }

      $attributes_vacinaVipEdit = [
        "apl1" => $apl1VipEdit,
        "apl2" => $apl2VipEdit,
        "apl3" => $apl3VipEdit,
        "ref1" => $ref1VipEdit,
        "ref2" => $ref2VipEdit,
        "tipo" => $tipoVipEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaVipCadastrado = atualizar($idVip, "tb_vacinas", $attributes_vacinaVipEdit);
      $mensagem = ($vacinaVipCadastrado) ? "Vacina Vip cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA Rotavirus##############################################################################################################################

      $listarRotavirus = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarRotavirus as $Rotavirus) {
        $idRotavirus = $Rotavirus->id;
      }

      $attributes_vacinaRotavirusEdit = [
        "apl1" => $apl1RotavirusEdit,
        "apl2" => $apl2RotavirusEdit,
        "apl3" => $apl3RotavirusEdit,
        "ref1" => $ref1RotavirusEdit,
        "ref2" => $ref2RotavirusEdit,
        "tipo" => $tipoRotavirusEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaRotavirusCadastrado = atualizar($idRotavirus, "tb_vacinas", $attributes_vacinaRotavirusEdit);
      $mensagem = ($vacinaRotavirusCadastrado) ? "Vacina Rotavirus cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA MeningoC##############################################################################################################################

      $listarMeningoC = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarMeningoC as $MeningoC) {
        $idMeningoC = $MeningoC->id;
      }

      $attributes_vacinaMeningoCEdit = [
        "apl1" => $apl1MeningoCEdit,
        "apl2" => $apl2MeningoCEdit,
        "apl3" => $apl3MeningoCEdit,
        "ref1" => $ref1MeningoCEdit,
        "ref2" => $ref2MeningoCEdit,
        "tipo" => $tipoMeningoCEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaMeningoCCadastrado = atualizar($idMeningoC, "tb_vacinas", $attributes_vacinaMeningoCEdit);
      $mensagem = ($vacinaMeningoCCadastrado) ? "Vacina MeningoC cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";    
##DADOS DA VACINA TripliceViral##############################################################################################################################

      $listarTripliceViral = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarTripliceViral as $TripliceViral) {
        $idTripliceViral = $TripliceViral->id;
      }

      $attributes_vacinaTripliceViralEdit = [
        "apl1" => $apl1TripliceViralEdit,
        "apl2" => $apl1TripliceViralEdit,
        "apl3" => $apl3TripliceViralEdit,
        "ref1" => $ref1TripliceViralEdit,
        "ref2" => $ref2TripliceViralEdit,
        "tipo" => $tipoTripliceViralEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaTripliceViralCadastrado = atualizar($idTripliceViral, "tb_vacinas", $attributes_vacinaTripliceViralEdit);
      $mensagem = ($vacinaTripliceViralCadastrado) ? "Vacina TripliceViral cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar"; 
##DADOS DA VACINA Tetraviral##############################################################################################################################

      $listarTetraviral = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarTetraviral as $Tetraviral) {
        $idTetraviral = $Tetraviral->id;
      }

      $attributes_vacinaTetraviralEdit = [
        "apl1" => $apl1TetraViralEdit,
        "apl2" => $apl2TetraViralEdit,
        "apl3" => $apl3TetraViralEdit,
        "ref1" => $ref1TetraViralEdit,
        "ref2" => $ref2TetraViralEdit,
        "tipo" => $tipoTetraViralEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaTetraviralCadastrado = atualizar($idTetraviral, "tb_vacinas", $attributes_vacinaTetraviralEdit);
      $mensagem = ($vacinaTetraviralCadastrado) ? "Vacina Tetraviral cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA DTP##############################################################################################################################

      $listarDTP = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarDTP as $DTP) {
        $idDTP = $DTP->id;
      }

      $attributes_vacinaDTPEdit = [
        "apl1" => $apl1DTPEdit,
        "apl2" => $apl2DTPEdit,
        "apl3" => $apl3DTPEdit,
        "ref1" => $ref1DTPEdit,
        "ref2" => $ref2DTPEdit,
        "tipo" => $tipoDTPEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaDTPCadastrado = atualizar($idDTP, "tb_vacinas", $attributes_vacinaDTPEdit);
      $mensagem = ($vacinaDTPCadastrado) ? "Vacina DTP cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA HepA##############################################################################################################################

      $listarHepA = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarHepA as $HepA) {
        $idHepA = $HepA->id;
      }

      $attributes_vacinaHepAEdit = [
        "apl1" => $apl1HepAEdit,
        "apl2" => $apl2HepAEdit,
        "apl3" => $apl3HepAEdit,
        "ref1" => $ref1HepAEdit,
        "ref2" => $ref2HepAEdit,
        "tipo" => $tipoHepAEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaHepACadastrado = atualizar($idHepA, "tb_vacinas", $attributes_vacinaHepAEdit);
      $mensagem = ($vacinaHepACadastrado) ? "Vacina HepA cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA VOP##############################################################################################################################

      $listarVOP = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarVOP as $VOP) {
        $idVOP = $VOP->id;
      }

      $attributes_vacinaVOPEdit = [
        "apl1" => $apl1VOPEdit,
        "apl2" => $apl2VOPEdit,
        "apl3" => $apl3VOPEdit,
        "ref1" => $ref1VOPEdit,
        "ref2" => $ref2VOPEdit,
        "tipo" => $tipoVOPEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaVOPCadastrado = atualizar($idVOP, "tb_vacinas", $attributes_vacinaVOPEdit);
      $mensagem = ($vacinaVOPCadastrado) ? "Vacina VOP cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";         
##DADOS DA VACINA Varicela##############################################################################################################################

      $listarVaricela = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarVaricela as $Varicela) {
        $idVaricela = $Varicela->id;
      }

      $attributes_vacinaVaricelaEdit = [
        "apl1" => $apl1VaricelaEdit,
        "apl2" => $apl2VaricelaEdit,
        "tipo" => $tipoVaricelaEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaVaricelaCadastrado = atualizar($idVaricela, "tb_vacinas", $attributes_vacinaVaricelaEdit);
      $mensagem = ($vacinaVaricelaCadastrado) ? "Vacina Varicela cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DA VACINA Outros##############################################################################################################################

      $listarOutros = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarOutros as $Outros) {
        $idOutros = $Outros->id;
      }

      $attributes_vacinaOutrosEdit = [
        "apl1" => $apl1OutrosEdit,
        "apl2" => $apl2OutrosEdit,
        "apl3" => $apl3OutrosEdit,
        "ref1" => $ref1OutrosEdit,
        "ref2" => $ref2OutrosEdit,
        "tipo" => $tipoOutrosEdit,
        "idCrianca" => $babyCadastrado
      ];

      $vacinaOutrosCadastrado = atualizar($idOutros, "tb_vacinas", $attributes_vacinaOutrosEdit);
      $mensagem = ($vacinaOutrosCadastrado) ? "Vacina Outros cadastrada com sucesso!!" : "Ocorreu um erro ao cadastrar";
##DADOS DOS TESTES##############################################################################################################################

      $listarTestes = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarTestes as $Testes) {
        $idTestes = $Testes->id;
      }

      $attributes_testesEdit = [
        "tPData" => $dataTestePezinhoEdit,
        "tPResul" => $resultadoTestePezinhoEdit,
        "tOrelhaData" => $dataTesteOrelhaEdit,
        "tOrelhaResul" => $resultadoTesteOrelhaEdit,
        "tLinguaData" => $dataTesteLinguaEdit,
        "tLinguaResul" => $resultadoTesteLinguaEdit,
        "perCefalicoCrianca" => $perimetroCefalicoEdit,
        "perToraxico" => $perimetroToraxicoEdit,
        "apgar1Crianca" => $apgar1Edit,
        "apgar5Crianca" => $apgar5Edit,
        "idCrianca" => $babyCadastrado
      ];

      $testesCadastrado = atualizar($idTestes, "tb_testes", $attributes_testesEdit);
      $mensagem = ($testesCadastrado) ? "Testes cadastrados com sucesso!!" : "Ocorreu um erro ao cadastrar"; 
##DADOS DO PESO POR SEMANA##############################################################################################################################

      $listarPesoSemana = listarPorIdCrianca($idChild, "tb_vacinas");
      foreach ($listarPesoSemana as $PesoSemana) {
        $idPesoSemana = $PesoSemana->id;
      }

      $attributes_pesoSemanaEdit = [
        "semana" => $semanaPesoEdit,
        "data" => $dataPesoEdit,
        "peso" => $pesoDataEdit,
        "idCrianca" => $babyCadastrado
      ];

      $pesoSemanaCadastrado = atualizar($idPesoSemana, "tb_peso_semana", $attributes_pesoSemanaEdit);
      $mensagem = ($pesoSemanaCadastrado) ? "Peso cadastrado com sucesso!!" : "Ocorreu um erro ao cadastrar";
    }
}
?>