<?php
  if (isset($_GET['excluirCrianca']) AND $_GET['excluirCrianca'] == true) {
    $id = filter_input(INPUT_GET,'id', FILTER_SANITIZE_NUMBER_INT);

##################################################################################
    $registroExcluidoVacina = deletar("idCrianca",$id,"tb_vacinas");
##################################################################################
    $listarPorIdCriancaTeste = listarPorIdCrianca($id, "tb_testes");
    foreach ($listarPorIdCriancaTeste as $teste) {
    	$idTeste = $teste->id; 
    }
    $registroExcluidoTestes = deletar("id",$id,"tb_testes");
##################################################################################
    $listarPorIdCriancaPesoSemana = listarPorIdCrianca($id, "tb_peso_semana");
    foreach ($listarPorIdCriancaPesoSemana as $peso) {
    	$idVacina = $peso->id; 
    }
    $registroExcluidoPesos = deletar("id",$id,"tb_peso_semana");
##################################################################################
    $listarPorIdCriancaPai = listarPorId($id, "tb_crianca");
    foreach ($listarPorIdCriancaPai as $pai) {
    	$idPai = $pai->idPai; 
    }
    $listarPorIdCriancaMae = listarPorId($id, "tb_crianca");
    foreach ($listarPorIdCriancaMae as $mae) {
    	$idMae = $mae->idMae; 
    }
    $registroExcluidoCrianca = deletar("id",$id,"tb_crianca");
##################################################################################
    $registroExcluidoPai = deletar("id",$idPai,"tb_pai");
##################################################################################      
    $registroExcluidoMae = deletar("id",$idMae,"tb_mae");
##################################################################################   


		if($registroExcluidoCrianca
			&& $registroExcluidoPai
			&& $registroExcluidoMae
			&& $registroExcluidoVacina
			&& $registroExcluidoTestes
			&& $registroExcluidoPesos){
			header("Location:home&p=listar&pag=1");
		}else{
			echo "Ocorreu um erro ao excluir o cliente";
		}  
  }
 ?>