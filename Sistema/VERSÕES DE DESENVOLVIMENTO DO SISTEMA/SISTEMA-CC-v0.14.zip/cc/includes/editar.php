<?php $chave = trim(strip_tags($_GET['id'])); //remove espaçoes e tags
      $chave = str_replace("\"", "",$chave); //remove aspas
      $chave = str_replace("\'", "",$chave); //remove aspas 
?>
<form action="" method="POST">			
<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
	    Dados da Criança
</button>
	<?php $listarDadosCrianca = listarPorChave($chave, "tb_crianca");
	            foreach ($listarDadosCrianca as $child) : 	


	            	$idCrinca = $child->id;
	       ?>
<div class="collapse" id="collapseCrianca">
    <div class="card card-body">

		<div class="row">
			<div class="form-group col-md col-sm">
				<label for="nomeRN">Nome do RN:</label>
				<input class="form-control form-control-sm" type="text" name="nomeRNEdit" id="nomeRNID" placeholder="Digite o nome do recém nascido" value="<?php echo $child->nomeCrianca;?>">
			</div>
		</div>
		<hr>
		<?php $datanasc = $child->dataNascCrianca; 
			 ?>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="dataRN">Data de Nascimento</label>
				<input class="form-control form-control-sm" type="date" name="dataRNEdit" id="dataRNID" value="<?php 	
				echo $datanasc;
				?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="hora">Hora:</label>
				<input class="form-control form-control-sm" type="text" name="horaEdit" id="horaID" value="<?php echo $child->horaNascCrianca;?>">
			</div>
			<div class="form-group col-md-2 col-sm">
				  <label for="sexoID">Sexo:</label>
				  <div class="divSexoID" hidden><?php echo $child->sexoCrianca;?></div>
				    <select class="form-control form-control-sm" name="sexoEdit" id="sexoID">
				      <option value="m">Masculino</option>
				      <option value="f">Feminino</option>
				    </select>
			</div>
			<div class="form-group col-md-4 col-sm">
				  <label for="tipoDePartoID">Tipo de parto:</label>
				  <div class="divTipoDePartoID" hidden><?php echo $child->partoCrianca;?></div>
				    <select class="form-control form-control-sm" name="tipoDePartoEdit" id="tipoDePartoID">
				      <option value="Normal">Normal</option>
				      <option value="Cesariana">Cesariana</option>
				    </select>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="peso">Peso:</label>
				<input class="form-control form-control-sm" step="00.01" type="number" name="pesoEdit" id="pesoID" value="<?php echo $child->pesoCrianca;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="altura">Altura:</label>
				<input class="form-control form-control-sm" type="number" name="alturaEdit" id="alturaID" value="<?php echo $child->alturaCrianca;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="idadeGestacional">Idade gestacional:</label>
				<input class="form-control form-control-sm" type="number" name="idadeGestacionalEdit" id="idadeGestacionalID" value="<?php echo $child->idadeGestacional;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-8 col-sm">
				<label for="endereco">Endereço:</label>
				<input class="form-control form-control-sm" type="text" name="enderecoEdit" id="enderecoID" placeholder="Ex: Rua Antonio Saturnino, Caroba" value="<?php echo $child->endereco;?>">
			</div>
			<div class="form-group col-md-4 col-sm">
				<label for="localidade">Localidade:</label>
				<input class="form-control form-control-sm" type="text" name="localidadeEdit" id="localidadeID" placeholder="Ex: Sede" value="<?php echo $child->localidade;?>">
			</div>
		</div>
	</div>	
	<?php 
		$idMae = $child->idMae;
		$idPai = $child->idPai;
		endforeach; 
	?>
</div>

<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseMae" aria-expanded="true" aria-controls="collapseMae">
    Dados da Mãe
</button>
	<?php $listarDadosMae = listarPorId($idMae, "tb_mae");
            foreach ($listarDadosMae as $mother) : 	
    ?>
	<div class="collapse" id="collapseMae">
	    <div class="card card-body">
		    <div class="row">
				<div class="form-group col-md col-sm">	
					<label for="nomeMae">Nome da Mãe:</label>
					<input class="form-control form-control-sm" type="text" name="nomeMaeEdit" id="nomeMaeID" placeholder="Digite o nome da mãe" value="<?php echo $mother->nome_mae;?>">
				</div>
			</div>
	<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="idadeMae">Idade:</label>
					<input class="form-control form-control-sm" type="number" name="idadeMaeEdit" id="idadeMaeID" placeholder="Digite a idade da mãe" value="<?php echo $mother->idade;?>">
				</div>
				<div class="form-group col-md-6 col-sm">
					<label for="profissaoMae">Profissão:</label>
					<input class="form-control form-control-sm" type="text" name="profissaoMaeEdit" id="profissaoMaeID" placeholder="Digite a profissão da mãe" value="<?php echo $mother->profissao;?>">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="form-group col-md-3 col-sm">
					<label for="consultaPreNatal">Nº de consultas de pré-natal:</label>
					<input class="form-control form-control-sm" type="number" name="consultaPreNatalEdit" id="consultaPreNatalID" value="<?php echo $mother->numConPN;?>">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosVivo">Filhos Nascidos Vivos:</label>
					<input class="form-control form-control-sm" type="number"  name="filhosVivoEdit" id="filhosVivoID" size="5px" value="<?php echo $mother->filhosV;?>">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosMorto">Mortos:</label>
					<input class="form-control form-control-sm" type="number" name="filhosMortoEdit" id="filhosMortoID" value="<?php echo $mother->filhosM;?>">
				</div>
				<div class="form-group col-md-3">
					<label for="filhosAborto">Aborto:</label>
					<input class="form-control form-control-sm" type="number" name="filhosAbortoEdit" id="filhosAborto" value="<?php echo $mother->filhosA;?>">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="form-group col-md col-sm">	
					<label for="municipioPreNatal">Município de realização do pré-natal:</label>
					<input class="form-control form-control-sm" type="text" name="municipioPreNatalEdit" id="municipioPreNatalID" placeholder="Realizou pré-natal em qual município?" value="<?php echo $mother->municipioPN;?>">
				</div> 
			</div>
		</div>
	</div>	
<?php endforeach; ?>
<button class="btn-azulbb text-light  btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePai" aria-expanded="false" aria-controls="collapsePai">
		    Dados do Pai
 </button>
 <?php $listarDadosPai = listarPorId($idPai, "tb_pai");
            foreach ($listarDadosPai as $dad) : 	
    ?>
	<div class="collapse" id="collapsePai">
	  <div class="card card-body">
	  	
	  		<div class="row">
					<div class="form-group form-group col-md col-sm">	
						<label for="nomePai">Nome do Pai:</label>
						<input class="form-control form-control-sm" type="text" name="nomePaiEdit" id="nomePaiID" placeholder="Digite o nome do pai" value="<?php echo $dad->nome_pai;?>">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-3 col-sm">
						<label for="idadePai">Idade:</label>
						<input class="form-control form-control-sm" type="number" name="idadePaiEdit" id="idadePaiID" placeholder="Digite a idade do pai" value="<?php echo $dad->idade;?>">
					</div>
					<div class="form-group col-md-6 col-sm">
						<label for="profissaoPai">Profissão:</label>
						<input class="form-control form-control-sm" type="text" name="profissaoPaiEdit" id="profissaoPaiID" placeholder="Digite a profissão do pai" value="<?php echo $dad->profissao;?>">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-4 col-sm">
						<label for="numeroMembrosFamilia">Nº de membros da família:</label>
						<input class="form-control form-control-sm" type="number" name="numeroMembrosFamiliaEdit" id="numeroMembrosFamiliaID" value="<?php echo $dad->membrosFamilia;?>">
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="rendaFamiliar">Renda Familiar:</label>
						<input class="form-control form-control-sm" step="00.01" type="number" name="rendaFamiliarEdit" id="rendaFamiliarID" value="<?php echo $dad->renda;?>">
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="acs">ACS:</label>
						<input class="form-control form-control-sm" type="text" name="acsEdit" id="acsID" placeholder="Digite o nome do Agente Comunitário de Saúde" value="<?php echo $dad->acs;?>">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md col-sm">
						<label>Observações:</label>
						<input type="textarea" class="form-control form-control-sm" id="obsID" name="obsEdit" value="<?php echo $dad->obs;?>">	
					</div>
				</div>
    
	  </div>
	 </div> 
	
<?php endforeach; ?>
			 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseVac" aria-expanded="false" aria-controls="collapseVac">
				    Vacinas
			 </button>




				<div class="collapse" id="collapseVac">
				  <div class="card card-body">
				  	<!-- VAC01 -->
				  <?php 
	$listarDadosVacinaBCG = listarPorIdCriancaTipoVacina($idCrinca, "BCG", "tb_vacinas");
	foreach ($listarDadosVacinaBCG as $vac) : 	
?>
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="tipoVac">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" id="tipoVacID" placeholder="" name="tipoBCGEdit" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="apl1">Aplicação 01:</label>
									<input class="form-control form-control-sm" value="<?php echo $vac->apl1; ?>" type="date" id="apl1BCGID"  placeholder="" name="apl1BCGEdit">
						
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="apl2">Aplicação 02:</label>
									<input class="form-control form-control-sm" value="<?php echo $vac->apl2; ?>" type="date" name="apl2BCGEdit" id="apl2BCGID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="apl3">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3BCGEdit" id="apl3BCGID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="ref1">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1BCGEdit" id="ref1BCGID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="ref2">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2BCGEdit" id="ref2BCGID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
				  			<?php endforeach; ?>
					

									  <?php 
	$listarDadosVacinaHepB = listarPorIdCriancaTipoVacina($idCrinca, "HepB", "tb_vacinas");
	foreach ($listarDadosVacinaHepB as $vac) : 	
?>
										  	<!-- VAC02 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoHepBEdit" id="tipoHepBID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1HepBEdit" id="apl1HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2HepBEdit" id="apl2HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3HepBEdit" id="apl3HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1HepBEdit" id="ref1HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2HepBEdit" id="ref2HepBID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
	<?php endforeach; ?>
										  <?php 
	$listarDadosVacinaPena = listarPorIdCriancaTipoVacina($idCrinca, "Penta", "tb_vacinas");
	foreach ($listarDadosVacinaPena as $vac) : 	
?>


										  	<!-- VAC03 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b> </label>
									<input class="form-control form-control-sm" type="text" value="<?php echo $vac->tipo; ?>" name="tipoPentaEdit" id="tipoPentaID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1PentaEdit" id="apl1PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2PentaEdit" id="apl2PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>"  name="apl3PentaEdit" id="apl3PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1PentaEdit" id="ref1PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2PentaEdit" id="ref2PentaID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>


										  <?php 
	$listarDadosVacinaPneumo = listarPorIdCriancaTipoVacina($idCrinca, "Pneumo 10", "tb_vacinas");
	foreach ($listarDadosVacinaPneumo as $vac) : 	
?>


										  	<!-- VAC04 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoPneumo10Edit" id="tipoPneumo10ID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1Pneumo10Edit" id="apl1Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2Pneumo10Edit" id="apl2Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3Pneumo10Edit" id="apl3Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1Pneumo10Edit" id="ref1Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2 ?>" name="ref2Pneumo10Edit" id="ref2Pneumo10ID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>

										  <?php 
	$listarDadosVacinaVIP = listarPorIdCriancaTipoVacina($idCrinca, "VIP", "tb_vacinas");
	foreach ($listarDadosVacinaVIP as $vac) : 	
?>
										  	<!-- VAC05 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoVipEdit" id="TipoVipID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1VipEdit" id="apl1VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2VipEdit" id="apl2VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3VipEdit" value="<?php echo $vac->apl3; ?>" id="apl3VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1VipEdit" id="ref1VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2VipEdit" id="ref2VipID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>

										  <?php 
	$listarDadosVacinaRota = listarPorIdCriancaTipoVacina($idCrinca, "Rotavírus", "tb_vacinas");
	foreach ($listarDadosVacinaRota as $vac) : 	
?>
										  	<!-- VAC06 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoRotavirusEdit" id="tipoRotavirusID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1RotavirusEdit" id="apl1RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2RotavirusEdit" id="apl2RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3RotavirusEdit" id="apl3RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1RotavirusEdit" id="ref1RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2RotavirusEdit" id="ref2RotavirusID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
				<?php endforeach; ?>	

														  <?php 
	$listarDadosVacinaMeningo = listarPorIdCriancaTipoVacina($idCrinca, "Meningo C", "tb_vacinas");
	foreach ($listarDadosVacinaMeningo as $vac) : 	
?>
												  	<!-- VAC07 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoMeningoCEdit" id="tipoMeningoCID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1MeningoCEdit" id="apl1MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl2MeningoCEdit" id="apl2MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl3MeningoCEdit" id="apl3MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="ref1MeningoCEdit" id="ref1MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="ref2MeningoCEdit" id="ref2MeningoCID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>

														  <?php 
	$listarDadosVacinaViral = listarPorIdCriancaTipoVacina($idCrinca, "Tríplice viral", "tb_vacinas");
	foreach ($listarDadosVacinaViral as $vac) : 	
?>
																  	<!-- VAC08 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoTripliceViralEdit" id="tipoTripliceViralID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1TripliceViralEdit" id="apl1TripliceViral" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2TripliceViralEdit" id="apl2TripliceViral" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3TripliceViralEdit" id="apl3TripliceViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1TripliceViralEdit" id="ref1TripliceViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2TripliceViralEdit" id="ref2TripliceViralID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
								<?php endforeach; ?>

															  <?php 
	$listarDadosVacinaTetra = listarPorIdCriancaTipoVacina($idCrinca, "Tetra viral", "tb_vacinas");
	foreach ($listarDadosVacinaTetra as $vac) : 	
?>
																  	<!-- VAC09 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoTetraViralEdit" id="tetraViralID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1TetraViralEdit" id="apl1TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2TetraViralEdit" id="apl2TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3TetraViralEdit" id="apl3TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1TetraViralEdit" id="ref1TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2TetraViralEdit" id="ref2TetraViralID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>

															  <?php 
	$listarDadosVacinaDTP = listarPorIdCriancaTipoVacina($idCrinca, "DTP", "tb_vacinas");
	foreach ($listarDadosVacinaDTP as $vac) : 	
?>
																  	<!-- VAC10 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoDTPEdit" id="tipoDTPID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1DTPEdit" id="apl1DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2DTPEdit" id="apl2DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3DTPEdit" id="apl3DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1DTPEdit" id="ref1DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2DTPEdit" id="ref2DTPID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>
															  <?php 
	$listarDadosVacinaHepA = listarPorIdCriancaTipoVacina($idCrinca, "Hep A", "tb_vacinas");
	foreach ($listarDadosVacinaHepA as $vac) : 	
?>
																  	<!-- VAC11 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoHepAEdit" id="tipoHepAID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1HepAEdit" id="apl1HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2HepAEdit" id="apl2HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3HepAEdit" id="apl3HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1HepAEdit" id="ref1HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2HepAEdit" id="ref2HepAID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
<?php endforeach; ?>
															  <?php 
	$listarDadosVacinaVOP = listarPorIdCriancaTipoVacina($idCrinca, "VOP", "tb_vacinas");
	foreach ($listarDadosVacinaVOP as $vac) : 	
?>
																  	<!-- VAC12 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoVOPEdit" id="tipoVOPID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1VOPEdit" id="apl1VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2VOPEdit" id="apl2VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3VOPEdit" id="apl3VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1VOPEdit" id="ref1VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2VOPEdit" id="ref2VOPID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

<hr>
<?php endforeach; ?>

															  <?php 
	$listarDadosVaricela = listarPorIdCriancaTipoVacina($idCrinca, "Varicela", "tb_vacinas");
	foreach ($listarDadosVaricela as $vac) : 	
?>

				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoVaricelaEdit" id="tipoVaricelaID" placeholder="" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1VaricelaEdit" id="apl1VaricelaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2VaricelaEdit" id="apl2VaricelaID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
								<hr>
							<?php endforeach; ?>
																						  <?php 
	$listarDadosOutros = listarPorIdCriancaTipoVacina($idCrinca, "Outro", "tb_vacinas");
	foreach ($listarDadosOutros as $vac) : 	
?>
																  	<!-- VAC12 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo:</label>
									<input class="form-control form-control-sm" value="<?php echo $vac->tipo; ?>" type="text" name="tipoOutrosEdit" id="outrosID" placeholder="Outros">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl1; ?>" name="apl1OutrosEdit" id="apl1OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl2; ?>" name="apl2OutrosEdit" id="apl2OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->apl3; ?>" name="apl3OutrosEdit" id="apl3OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref1; ?>" name="ref1OutrosEdit" id="ref1OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" value="<?php echo $vac->ref2; ?>" name="ref2OutrosEdit" id="ref2OutrosID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->	
					<?php endforeach; ?>
																											  	<!-- VAC13 -->
				  </div>

					</div> 
	 <button class="btn-azulbb text-light btn-block  border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseTeste" aria-expanded="false" aria-controls="collapseTeste">
					    Testes
				 </button>



				<div class="collapse" id="collapseTeste">
				  <div class="card card-body">
<?php $pegaTestes = listarPorIdCrianca($idCrinca, "tb_testes");
	foreach ($pegaTestes as $key):
	
 ?>

				  			<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="dataTestePezinho">Data teste do Pézinho:</label>
									<input class="form-control form-control-sm" value="<?php echo $key->tPData; ?>" type="date" id="dataTestePezinhoID" placeholder="" name="dataTestePezinhoEdit">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTestePezinho">Resultado teste do Pézinho:</label>
									<input class="form-control form-control-sm" type="text" id="resultadoTestePezinhoID" placeholder="" value="<?php echo $key->tPResul; ?>" name="resultadoTestePezinhoEdit">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="dataTesteOrelha">Data teste da Orelha:</label>
									<input class="form-control form-control-sm" type="date" id="dataTesteOrelhaID" value="<?php echo $key->tOrelhaData; ?>" placeholder=""
									name="dataTesteOrelhaEdit">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTesteOrelha">Resultado teste da Orelha:</label>
									<input class="form-control form-control-sm" type="text" id="resultadoTesteOrelhaID" placeholder="" name="resultadoTesteOrelhaEdit" value="<?php echo $key->tOrelhaResul; ?>">
								</div>
							</div>
<hr>
							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="dataTesteLingua">Data teste da Lingua:</label>
									<input class="form-control form-control-sm" type="date" id="dataTesteLinguaID" placeholder="" 
									name="dataTesteLinguaEdit" value="<?php echo $key->tLinguaData; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="resultadoTesteLingua">Resultado teste da Lingua:</label>
									<input class="form-control form-control-sm" type="text" id="resultadoTesteLinguaID" placeholder="" name="resultadoTesteLinguaEdit" value="<?php echo $key->tLinguaResul; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="perimetroCefalico">Perímetro cefálico:</label>
									<input class="form-control form-control-sm" type="number" step="00.01" id="perimetroCefalicoID" placeholder="" name="perimetroCefalicoEdit" value="<?php echo $key->perCefalicoCrianca; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="perimetroToraxico">Perímetro toraxico:</label>
									<input class="form-control form-control-sm" type="number" step="00.01" name="perimetroToraxicoEdit" id="perimetroToraxico" placeholder="" value="<?php echo $key->perToraxico; ?>">
								</div>
							</div>
<hr>
							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="apgar1">Apgar 1º:</label>
									<input class="form-control form-control-sm" type="number" name="apgar1Edit" id="apgar1ID" placeholder="" value="<?php echo $key->apgar1Crianca; ?>">
								</div>

								<div class="form-group col-md-3 col-sm">
									<label for="apgar5">Apgar 5º:</label>
									<input class="form-control form-control-sm" type="number" name="apgar5Edit" id="apgar5ID" placeholder="" value="<?php echo $key->apgar5Crianca; ?>">
								</div>
							</div>
						<?php endforeach; ?>
				  </div>
				 </div>
				<button name="attCriancaEdit" value="<?php echo $idCrinca; ?>" class=" btn-success btn-block border border-success" type="submit">Atualizar</button>



</form>