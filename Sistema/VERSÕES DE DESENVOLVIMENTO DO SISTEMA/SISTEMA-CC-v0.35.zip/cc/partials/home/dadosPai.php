	 <button class="btn-azulbb text-light  btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePai" aria-expanded="false" aria-controls="collapsePai">
				    Dados do Pai
		 </button>
				<div class="collapse" id="collapsePai">
				  <div class="card card-body">
				  	
				  		<div class="row">
								<div class="form-group form-group col-md col-sm">	
									<label for="nomePai">Nome do Pai: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" type="text" id="nomePaiID" placeholder="Digite o nome do pai" name="nomePai" required>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="form-group col-md-3 col-sm">
									<label for="idadePai">Idade: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" type="number" id="idadePaiID" placeholder="Digite a idade do pai" name="idadePai" required>
								</div>
								<div class="form-group col-md-6 col-sm">
									<label for="profissaoPai">Profissão: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" type="text" id="profissaoPaiID" placeholder="Digite a profissão do pai" name="profissaoPai" required>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="form-group col-md-4 col-sm">
									<label for="numeroMembrosFamilia">Nº de membros da família: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" type="number" name="numeroMembrosFamilia" id="numeroMembrosFamiliaID" name="numeroMembrosFamilia" required>
								</div>
								<div class="form-group col-md-4 col-sm">
									<label for="rendaFamiliar">Renda Familiar:</label>
									<input class="form-control form-control-sm" step="00.01" type="number" id="rendaFamiliarID" name="rendaFamiliar">
								</div>
								
							</div>
							<hr>
							<div class="row">
								<div class="form-group col-md col-sm">
									<label>Observações:</label>
									<textarea class="form-control form-control-sm" id="obsID" rows="4" cols="50"  name="obs"></textarea>	
								</div>
							</div>

				  </div>
				 </div> 