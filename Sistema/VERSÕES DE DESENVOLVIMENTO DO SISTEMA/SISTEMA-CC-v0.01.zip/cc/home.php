<?php
 require 'config.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<?php 
			include("partials/header.php");
		 ?>
	</head>
	<body class="backHome">
		

		<!-- CONTEUDO -->
			<div id="conteudo"><?php alterarPaginaHome(); ?></div>

		<!-- Links -->
		<?php 
			include("partials/scripts.php");
		 ?>
	</body>
</html>
				<!--<?php/// echo (isset($mensagem)) ? $mensagem : ""; ?>-->
