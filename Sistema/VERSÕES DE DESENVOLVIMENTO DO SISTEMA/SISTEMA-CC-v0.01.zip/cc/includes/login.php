 <div class="container">
     <div class="animated bounceInDown">
        <div class="form-signin caixaLoginCima bg-rosa shadow-lg">
          <center>
            <img src="assets/img/cc.png" class="centered" width="200px" height="150px">
          </center>
        </div>
      <form class="form-signin caixaLoginBaixo bg-light shadow-lg" action="" method="POST">
        <h2 class="form-signin-heading"></h2>
        <label for="inputEmail" class="sr-only">Nome de usuário</label>
        <input type="text" id="inputEmail" class="form-control" placeholder="Nome de usuário" name="campoLogin" required autofocus>
        <label for="inputPassword" class="sr-only">Senha</label>
        <input type="password" name="campoSenha" id="inputPassword" class="form-control" placeholder="Senha" required>
        <div class="checkbox">
          <label>
            <input type="checkbox" value="lembrar-me"> Lembrar me
          </label>
        </div>
        <button class="btn btn-lg btn-rosa btn-block" name="logar" type="submit">Entrar</button>
      </form>
     </div>
    </div> <!-- /container -->