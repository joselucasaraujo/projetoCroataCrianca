<?php
ob_start();
session_start();
  if(!isset($_SESSION["login"])){
    header('Location: login');
  }
require 'config.php'; ?>
<!DOCTYPE html>
<html ng-app="">
	<head>
		<?php 
			include("partials/header.php");
		 ?>
	</head>

  <body class="backHome">
     <div class="container">
      <!-- CARD -->
      <div class="card-deck pt-md-4 pt-4 animated bounceInDown rounded teste">
        <div class="card mb-5 shadow-lg rounded">
          <!-- PARTE DE CIMA DO CARD -->
          <div class="card-header bg-rosa rounded">
            <!-- NAVBAR -->
            <nav class="navbar navbar-expand-md navbar-dark rounded navbar-fixed"> 
              <a class="navbar-brand" href="home"><img src="assets/img/cc.png" class="centered" width="100px" height="60px"></a>
              <button class="navbar-toggler"type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                   <li class="nav-item">
                    <hr class="bg-light">
                  </li>
                  <li class="nav-item active">
                    <a class="nav-link" href="home"><img height="30px" src="assets/img/icones/home.png"> Página inicial<span class="sr-only">(atual)</span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="home&p=cadastrar"><img height="30px" src="assets/img/icones/add.png"> Criança</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link " href="home&p=listar&pag=1"><img height="30px" class="" src="assets/img/icones/listar.png"> Listar</a>
                  </li>
                 
                </ul>
                
                <form class="form-inline mt-2 mt-md-0" name="enter" method="POST" action="home&p=listar&pag=" enctype="multipart/form-data" >
                   <input size="35%" type="text" class="form-control mr-sm-2" name="chave" placeholder="Pesquisar">
                  <button class="btn btn-azulbb text-light my-3 my-sm-0" type="submit" name="enter"><img src="assets/img/icones/search.png" height="20px"> Pesquisar</button>
                 <button class="btn btn-rosa text-light my-3 my-sm-0 ml-2" value="1" name="sair" type="submit"><img height="30px" class="" src="assets/img/icones/sair.png"> Sair</button>
                </form>
                 
              </div>
            </nav> <!-- FECHA NAVBAR -->
          </div>
          
    <!-- CONTEUDO -->
                    <?php echo (isset($mensagem)) ? $mensagem : ""; ?>               
                  
                  <?php 
                    $id = 20;    

                             
                   ?>                 

              <div id="conteudo"><?php alterarPaginaHome(); ?></div>

                  <div class="card-footer bg-rosa text-light rounded">
                  &copy; Todos os direitos reservados
              </div>
          </div>  
        </div><!-- FECHA O CARD -->
    </div>  
    <!-- Links -->  
    <?php 
      include("partials/scripts.php");
      include("partials/home/modals.php");
     ?>


  </body>
</html>
