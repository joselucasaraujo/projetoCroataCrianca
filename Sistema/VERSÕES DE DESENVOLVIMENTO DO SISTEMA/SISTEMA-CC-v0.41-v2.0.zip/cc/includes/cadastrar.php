<form action="" method="POST" name="myForm">

		<div class="row">
			<div class="col-md">
  
  <!-- ############################# DADOS DA MÃE ############################# -->
	<?php include'partials/home/dadosMae.php'; ?>
		
		<!-- ############################# DADOS DO PAI ############################# -->
		
	<?php include'partials/home/dadosPai.php'; ?>
		
		<!-- ############################# DADOS DA CRIANÇA ###################################### -->
	
	<?php include'partials/home/dadosCrianca.php'; ?>
		<!-- ############################# VACINAS ####################################### -->
	<?php include'partials/home/vacinas.php'; ?>

		<!-- ############################# TESTES ####################################### -->

	<?php include'partials/home/testes.php'; ?>


						<button name="cadCrianca" class=" btn-success btn-block border border-success" id="cadCriancaID" type="submit">Cadastrar</button>
						<button type="reset" class=" btn-primary text-light btn-block border border-primary" style="margin-top: 0px;">Limpar campos</button>
		
</form>

