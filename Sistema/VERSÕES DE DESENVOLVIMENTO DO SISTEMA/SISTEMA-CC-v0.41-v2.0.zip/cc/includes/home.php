<?php 

$internet = 0;

 if (!$sock = @fsockopen('www.google.com.br', 80, $num, $error, 5)) $internet = 1; else $internet = 2; 

 if ($internet == 2) {
   
 }else{
  echo '
<div class="alert alert-primary alert-dismissible fade show" style="margin-bottom: 0px;" role="alert">
                  <strong>Gráficos indisponíveis, por favor conecte-se a internet.</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>';

 }

//grafico por sexo
$cont_feminino = 0;
$cont_masculino = 0;

//grafico por localidade
$cont_croata = 0;
$cont_betania = 0;
$cont_barra = 0;
$cont_lagoa = 0;
$cont_saoRoque = 0;
$cont_santaTereza = 0;
$cont_vistaAlegre = 0;
$cont_reparticao = 0;

	$pegaDados = listar("tb_crianca");
foreach ($pegaDados as $key):

	if ($key->sexoCrianca == 'feminino') {
		$cont_feminino++;
	}else if ($key->sexoCrianca == 'masculino') {
		$cont_masculino++;
	}


	if ($key->localidade == 'Croatá') {
		$cont_croata++;
	}else if ($key->localidade == 'Betânia') {
    $cont_betania++;
  }else if ($key->localidade == 'Barra do sotero') {
    $cont_barra++;
  }elseif ($key->localidade == 'Lagoa da cruz') {
    $cont_lagoa++;
  }elseif ($key->localidade == 'São roque') {
    $cont_saoRoque++;
  }elseif ($key->localidade == 'Santa tereza') {
    $cont_santaTereza++;
  }else if ($key->localidade == 'Vista alegre') {
    $cont_vistaAlegre++;
  }else if ($key->localidade == 'Repartição') {
    $cont_reparticao++;
  }


endforeach;
 ?>

<script type="text/javascript" src="assets/js/loader.js"></script>
<script type="text/javascript">
	
	    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Sexo', 'Quantidade'],
          ['Feminino',     <?php echo $cont_feminino; ?>],
          ['Masculino',      <?php echo $cont_masculino; ?>],
        ]);

        var options = {
          title: 'Percentual de crianças por sexo'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
</script>


    <script type="text/javascript">
      //carrega o pacote dos gráficos    
      google.charts.load('current', {'packages':['corechart']});
      
      //define a função para criar o gráfico
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Crianças', 'Crianças'],
          ['Croatá',     <?php echo $cont_croata; ?>],
          ['Betânia',     <?php echo $cont_betania; ?>],
          ['Barra do sotero',      <?php echo $cont_barra; ?>],
          ['Lagoa da cruz',  <?php echo $cont_lagoa; ?>],
          ['São roque', <?php echo $cont_saoRoque; ?>],
          ['Santa tereza', <?php echo $cont_santaTereza; ?>],
          ['Vista alegre', <?php echo $cont_vistaAlegre; ?>],
          ['Repartição', <?php echo $cont_reparticao; ?>]
        ]);
        // criar a variavel options para definir as opções do gráfico
        var options = {
          title: 'Gráfico de crianças por localidade'
        };
        //aloca o tipo de gráfico na div GraficoColunas
    var chart = new google.visualization.ColumnChart(document.getElementById('GraficoColunas'));

        chart.draw(data, options);
      }
      
      //carrega o grafico na página
      google.charts.setOnLoadCallback(drawChart);
      
    </script>

<div class="">
		<div id="GraficoColunas" style="height: 300px; width: 55%; float: left;"></div>
	<div id="piechart" style="width: 45%; height: 300px; float: right;"></div>

</div>
