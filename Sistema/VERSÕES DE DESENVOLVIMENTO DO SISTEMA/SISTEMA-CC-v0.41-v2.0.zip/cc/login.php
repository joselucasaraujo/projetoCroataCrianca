<?php
ob_start();
session_start();
	if(isset($_SESSION["login"])){
    header('Location: home');
 }
require 'config.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<?php 
			include("partials/header.php");
		 ?>
	</head>
	<body class="backLogin">
		
			<div id="conteudo"><?php alterarPaginaLogin(); ?></div>

		<!-- Links -->
		<?php 
			include("partials/scripts.php");
		 ?>
	</body>
</html>
				<!--<?php/// echo (isset($mensagem)) ? $mensagem : ""; ?>-->
