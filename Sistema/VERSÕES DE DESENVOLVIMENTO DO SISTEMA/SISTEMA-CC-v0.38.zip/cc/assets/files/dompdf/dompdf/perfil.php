<?php

	$id = $_GET['id'];
	//referenciar o DomPDF com namespace

	include('../../../../config.php');
	$html = '<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; margin-top: 1000px; "><center>VISITA E PESO DO ACS</center></div>
';
	$html .= '<table style="width:100%;">';
	$html .= '<thead>';
	$html .= '<tr>';
	$html .= '<td><center><b>Semanas</b></center></td>';
	$html .= '<td><center><b>Data</b></center></td>';
	$html .= '<td><center><b>Peso</b></center></td>';
	$html .= '</tr>';
	$html .= '</thead>';


 					$select = "SELECT * FROM tb_peso_semana WHERE idCrianca=:id ORDER BY semana ASC";
                              
                              try{
                                  $result = $conexao->prepare($select);
                                  $result->bindParam(':id', $id, PDO::PARAM_STR);
                                  $result->execute();
                                
                                 while ($show=$result->fetch(PDO::FETCH_ASSOC)) {
									$html .= '<tbody>';
                                 	$html .= '<tr><td style="border-bottom: 1pt solid black;"><center>'.$show['semana'].'º semana'.'</center></td>';
                                 	$html .= '<td style="border-bottom: 1pt solid black;"><center>'.inverteData($show['data']).'</center></td>';
                                 	$html .= '<td style="border-bottom: 1pt solid black;"><center>'.$show['peso'].' Kg'.'</center></td></tr>'; 
                                 	$html .= '</tbody>'; 

                                 }

                              }catch(PDOException $e){
                                  echo $e;
                              }

	$html .= '</table>';
   


	//include autoloader
	require_once('dompdf_config.inc.php');
	//Criando a Instancia
	$dompdf = new DOMPDF();
	$listarDadosCrianca = listarPorId($id, 'tb_crianca');
	foreach ($listarDadosCrianca as $crianco) {
		$idPapy = $crianco->idPai;
		$idMamy = $crianco->idMae;
		$nomeChild = $crianco->nomeCrianca;
		$acs = $crianco->acs;
		$dataNascimento = $crianco->dataNascCrianca;
		$horaNascimento = $crianco->horaNascCrianca;
		$sexoCrianca = $crianco->sexoCrianca;
		$partoCrianca = $crianco->partoCrianca;
		$pesoCrianca = $crianco->pesoCrianca;
		$alturaCrianca = $crianco->alturaCrianca;
		$idadeGestacional = $crianco->idadeGestacional;
		$enderecoCrianca = $crianco->endereco;
		$localidadeCrianca = $crianco->localidade;
		$cartaoSUS = $crianco->cartaoSUS;
	}

	$listarDadosMae = listarPorId($idMamy, 'tb_mae');
	foreach ($listarDadosMae as $mamy) {
		$nomeMae = $mamy->nome_mae;
		$idadeMae = $mamy->idade;
		$profissaoMae = $mamy->profissao;
		$numConsulPN = $mamy->numConPN;
		$filhosVivo = $mamy->filhosV;
		$filhosMorto = $mamy->filhosM;
		$filhosAborto = $mamy->filhosA;
		$municipioPreNatal = $mamy->municipioPN;
	}

	$listarDadosPai = listarPorId($idPapy, 'tb_pai');
	foreach ($listarDadosPai as $papy) {
		$nomePai = $papy->nome_pai;
		$idadePai = $papy->idade;
		$profissaoPai = $papy->profissao;
		$numMembrosFamilia = $papy->membrosFamilia;
		$rendaFamiliar = $papy->renda;
		$observacao = $papy->obs;
	}

	$listarDadosTestes = listarPorIdCrianca($id, 'tb_testes');
	foreach ($listarDadosTestes as $teste) {
		$tPData = $teste->tPData;
		$tPResul = $teste->tPResul;
		$tOrelhaData = $teste->tOrelhaData;
		$tOrelhaResul = $teste->tOrelhaResul;
		$tLinguaData = $teste->tLinguaData;
		$tLinguaResul = $teste->tLinguaResul;
		$pCCrianca = $teste->perCefalicoCrianca;
		$pTCrianca = $teste->perToraxico;
		$apgar1 = $teste->apgar1Crianca;
		$apgar5 = $teste->apgar5Crianca;
	}

	$listarDadosVacinaBCG = listarPorIdCriancaTipoVacina($id, "BCG", "tb_vacinas");
	foreach ($listarDadosVacinaBCG as $vac){
		$tipoBCG = $vac->tipo;
		$apl1BCG = inverteData($vac->apl1);
		$apl2BCG = inverteData($vac->apl2);
	  	$apl3BCG = inverteData($vac->apl3);
	  	$ref1BCG = inverteData($vac->ref1);
	  	$ref2BCG = inverteData($vac->ref2);
	}
	$listarDadosVacinaHepB = listarPorIdCriancaTipoVacina($id, "HepB", "tb_vacinas");
	foreach ($listarDadosVacinaHepB as $vac){
		$tipoHepB = $vac->tipo;
		$apl1HepB = inverteData($vac->apl1);
		$apl2HepB = inverteData($vac->apl2);
	  	$apl3HepB = inverteData($vac->apl3);
	  	$ref1HepB = inverteData($vac->ref1);
	  	$ref2HepB = inverteData($vac->ref2);
	}

	$listarDadosVacinaPena = listarPorIdCriancaTipoVacina($id, "Penta", "tb_vacinas");
	foreach ($listarDadosVacinaPena as $vac){
		$tipoPenta = $vac->tipo;
		$apl1Penta = inverteData($vac->apl1);
		$apl2Penta = inverteData($vac->apl2);
	  	$apl3Penta = inverteData($vac->apl3);
	  	$ref1Penta = inverteData($vac->ref1);
	  	$ref2Penta = inverteData($vac->ref2);
	}

	$listarDadosVacinaPena = listarPorIdCriancaTipoVacina($id, "Pneumo 10", "tb_vacinas");
	foreach ($listarDadosVacinaPena as $vac){
		$tipoPneumo10 = $vac->tipo;
		$apl1Pneumo10 = inverteData($vac->apl1);
		$apl2Pneumo10 = inverteData($vac->apl2);
	  	$apl3Pneumo10 = inverteData($vac->apl3);
	  	$ref1Pneumo10 = inverteData($vac->ref1);
	  	$ref2Pneumo10 = inverteData($vac->ref2);
	}

	$listarDadosVacinaVIP = listarPorIdCriancaTipoVacina($id, "VIP", "tb_vacinas");
	foreach ($listarDadosVacinaVIP as $vac){
		$tipoVip = $vac->tipo;
		$apl1Vip = inverteData($vac->apl1);
		$apl2Vip = inverteData($vac->apl2);
	  	$apl3Vip = inverteData($vac->apl3);
	  	$ref1Vip = inverteData($vac->ref1);
	  	$ref2Vip = inverteData($vac->ref2);
	}
	$listarDadosVacinaRota = listarPorIdCriancaTipoVacina($id, "Rotavírus", "tb_vacinas");
	foreach ($listarDadosVacinaRota as $vac){
		$tipoRotavirus = $vac->tipo;
		$apl1Rotavirus = inverteData($vac->apl1);
		$apl2Rotavirus = inverteData($vac->apl2);
	  	$apl3Rotavirus = inverteData($vac->apl3);
	  	$ref1Rotavirus = inverteData($vac->ref1);
	  	$ref2Rotavirus = inverteData($vac->ref2);
	}
	$listarDadosVacinaMeningo = listarPorIdCriancaTipoVacina($id, "Meningo C", "tb_vacinas");
	foreach ($listarDadosVacinaMeningo as $vac){
		$tipoMeningoC = $vac->tipo;
		$apl1MeningoC = inverteData($vac->apl1);
		$apl2MeningoC = inverteData($vac->apl2);
	  	$apl3MeningoC = inverteData($vac->apl3);
	  	$ref1MeningoC = inverteData($vac->ref1);
	  	$ref2MeningoC = inverteData($vac->ref2);
	}
	$listarDadosVacinaViral = listarPorIdCriancaTipoVacina($id, "Tríplice viral", "tb_vacinas");
	foreach ($listarDadosVacinaViral as $vac){
		$tipoTripliceViral = $vac->tipo;
		$apl1TripliceViral = inverteData($vac->apl1);
		$apl2TripliceViral = inverteData($vac->apl2);
	  	$apl3TripliceViral = inverteData($vac->apl3);
	  	$ref1TripliceViral = inverteData($vac->ref1);
	  	$ref2TripliceViral = inverteData($vac->ref2);
	}
	$listarDadosVacinaTetra = listarPorIdCriancaTipoVacina($id, "Tetra viral", "tb_vacinas");
	foreach ($listarDadosVacinaTetra as $vac){
		$tipoTetraViral = $vac->tipo;
		$apl1TetraViral = inverteData($vac->apl1);
		$apl2TetraViral = inverteData($vac->apl2);
	  	$apl3TetraViral = inverteData($vac->apl3);
	  	$ref1TetraViral = inverteData($vac->ref1);
	  	$ref2TetraViral = inverteData($vac->ref2);
	}
	$listarDadosVacinaDTP = listarPorIdCriancaTipoVacina($id, "DTP", "tb_vacinas");
	foreach ($listarDadosVacinaDTP as $vac){
		$tipoDTP = $vac->tipo;
		$apl1DTP = inverteData($vac->apl1);
		$apl2DTP = inverteData($vac->apl2);
	  	$apl3DTP = inverteData($vac->apl3);
	  	$ref1DTP = inverteData($vac->ref1);
	  	$ref2DTP = inverteData($vac->ref2);
	}
	$listarDadosVacinaHepA = listarPorIdCriancaTipoVacina($id, "Hep A", "tb_vacinas");
	foreach ($listarDadosVacinaHepA as $vac){
		$tipoHepA = $vac->tipo;
		$apl1HepA = inverteData($vac->apl1);
		$apl2HepA = inverteData($vac->apl2);
	  	$apl3HepA = inverteData($vac->apl3);
	  	$ref1HepA = inverteData($vac->ref1);
	  	$ref2HepA = inverteData($vac->ref2);
	}
	$listarDadosVacinaVOP = listarPorIdCriancaTipoVacina($id, "VOP", "tb_vacinas");
	foreach ($listarDadosVacinaVOP as $vac){
		$tipoVOP = $vac->tipo;
		$apl1VOP = inverteData($vac->apl1);
		$apl2VOP = inverteData($vac->apl2);
	  	$apl3VOP = inverteData($vac->apl3);
	  	$ref1VOP = inverteData($vac->ref1);
	  	$ref2VOP = inverteData($vac->ref2);
	}
	$listarDadosVaricela = listarPorIdCriancaTipoVacina($id, "Varicela", "tb_vacinas");
	foreach ($listarDadosVaricela as $vac){
		$tipoVaricela = $vac->tipo;
		$apl1Varicela = inverteData($vac->apl1);
		$apl2Varicela = inverteData($vac->apl2);
	  	$apl3Varicela = inverteData($vac->apl3);
	  	$ref1Varicela = inverteData($vac->ref1);
	  	$ref2Varicela = inverteData($vac->ref2);
	}

	  $dataNascimentoInvertida = inverteData($dataNascimento);
	  $tPDataInvertida = inverteData($tPData);
	  $tOrelhaDataInvertida = inverteData($tOrelhaData);
	  $tLinguaDataInvertida = inverteData($tLinguaData);



	
			$cabecalho = '
			<table style="margin-top: -20px; padding: 10px 10px 10px 10px; width: 850px;">
				<tr>
					<td>
						<img width="100px" src="../../../img/cc.png">
					</td>
					<td style="">
						<p style="text-align: center; font-size: 12px;">
							ESTADO DO CEARÁ<br>
							GOVERNO MUNICIPAL DE CROATÁ<br>
							SECRETARIA MUNICIPAL DE SAÚDE<br>
							"CUIDANDO BEM DE VOCÊ"
						</p>						
					</td>
					<td>
						<img style="margin-left: 4rem;" width="170px" src="../../../img/logo.png">
					</td>
				</tr>
			<center><b style="margin-bottom: 20px;">"PROGRAMA CROATÁ CRIANÇA"</b></center>
			</table>
			
			';

			$dadosPais = '
			<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DOS PAIS</center></div>
				<br>
				<table>
					<tr>
						<td>
							<b>Nome da mãe:</b> <u>'.$nomeMae.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Idade:</b> <u>'.$idadeMae.'</u>
						</td>
						<td>
							<b style="margin-left:120px;">Profissão:</b> <u>'.$profissaoMae.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Nº de consultas de pré-natal:</b> <u>'.$numConsulPN.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Filhos nascidos vivos:</b> <u>'.$filhosVivo.'</u>
						</td>
						<td>
							<b style="margin-left:30px;">Mortos:</b> <u>'.$filhosMorto.'</u>
						</td>
						<td>
							<b style="margin-left:30px;">Aborto:</b> <u>'.$filhosAborto.'</u>
						</td>
					</tr>
				</table>
				<hr>
				<table>
					<tr>
						<td>
							<b>Nome da Pai:</b> <u>'.$nomePai.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Idade:</b> <u>'.$idadePai.'</u>
						</td>
						<td>
							<b style="margin-left:120px;">Profissão:</b> <u>'.$profissaoPai.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Renda Familiar:</b> <u>R$ '.$rendaFamiliar.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Nº de membros da familia:</b> <u>'.$numMembrosFamilia.'</u>
						</td>
						<td>
							<b style="margin-left:120px;">ACS:</b> <u>'.$acs.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Realizou pré-natal em qual município:</b> <u>'.$municipioPreNatal.'</u>
						</td>
					</tr>
				</table>
				<hr>
				<table>
					<tr>
						<td>
							<b>Observações:</b> <u>'.$observacao.'</u>
						</td>
					</tr>
				</table>
			';

			$dadosCrianca = '
				<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DO RECÉM-NASCIDO</center></div>
				<br>
				<table>
					<tr>
						<td>
							<b>Nome do RN:</b> <u>'.$nomeChild.'</u>
						</td>
						<td>
							<b>Data de Nascimento:</b> <u>'.$dataNascimentoInvertida.'</u>
						</td>
						<td>
							<b>Hora:</b> <u>'.$horaNascimento.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Idade Gestacional:</b> <u>'.$idadeGestacional.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Sexo:</b> <u>'.$sexoCrianca.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Tipo de Parto:</b> <u>'.$partoCrianca.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Peso:</b> <u>'.$pesoCrianca.' g</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Estatura:</b> <u>'.$alturaCrianca.' cm</u>
						</td>
					</tr>
				</table>

			';

			$dadosTestes = '
				<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px; "><center>DADOS DOS TESTES</center></div>
				<br>	
				<table>
					<tr>
						<td>
							<b>Teste do Pezinho:</b> <u>'.$tPDataInvertida.'</u>
						</td>
						<td>
							<b>Resultado:</b> <u>'.$tPResul.'</u>
						</td>
						<td>
							<b>Teste da Orelhinha:</b> <u>'.$tOrelhaDataInvertida.'</u>
						</td>
						<td>
							<b>Resultado:</b> <u>'.$tOrelhaResul.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Teste da Linguinha:</b> <u>'.$tLinguaDataInvertida.'</u>
						</td>
						<td>
							<b>Resultado:</b> <u>'.$tLinguaResul.'</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>PC:</b> <u>'.$pCCrianca.' cm</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>PC:</b> <u>'.$pCCrianca.' cm</u>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<b>Apgar 1º:</b> <u>'.$apgar1.'</u>
						</td>
						<td>
							<b>Apgar 5º:</b> <u>'.$apgar5.'</u>
						</td>
					</tr>
				</table>
				';

				$dadosVacinas = '
				<br>
				<br>
				<div style="background-color: #b5b6b7; border-style: solid; border-width: 1px;"><center>CALENDÁRIO VACINAL</center></div>
				<br>	
				<br>
				<table border="1px" style="width:100%;">
					<tr>
						<td>
							<center><b>Tipo</b></center>
						</td>
						<td>
							<center><b>Aplicação 1</b></center>
						</td>
						<td>
							<center><b>Aplicação 2</b></center>
						</td>
						<td>
							<center><b>Aplicação 3</b></center>
						</td>
						<td>
							<center><b>Reforço 1</b></center>
						</td>
						<td>
							<center><b>Reforço 2</b></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoBCG.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1BCG.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2BCG.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3BCG.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1BCG.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2BCG.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><center><b>'.$tipoHepB.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1HepB.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2HepB.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3HepB.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1HepB.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2HepB.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoPenta.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1Penta.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2Penta.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3Penta.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1Penta.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2Penta.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoPneumo10.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1Pneumo10.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2Pneumo10.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3Pneumo10.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1Pneumo10.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2Pneumo10.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoVip.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1Vip.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2Vip.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3Vip.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1Vip.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2Vip.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoRotavirus.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1Rotavirus.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2Rotavirus.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3Rotavirus.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1Rotavirus.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2Rotavirus.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoMeningoC.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1MeningoC.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2MeningoC.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3MeningoC.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1MeningoC.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2MeningoC.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoTripliceViral.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1TripliceViral.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2TripliceViral.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3TripliceViral.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1TripliceViral.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2TripliceViral.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoTetraViral.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1TetraViral.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2TetraViral.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3TetraViral.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1TetraViral.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2TetraViral.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoDTP.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1DTP.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2DTP.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3DTP.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1DTP.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2DTP.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoHepA.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1HepA.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2HepA.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3HepA.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1HepA.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2HepA.'</p></center>
						</td>
					<tr>
						<td>
							<center><b>'.$tipoVOP.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1VOP.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2VOP.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3VOP.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1VOP.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2VOP.'</p></center>
						</td>
					</tr>
					<tr>
						<td>
							<center><b>'.$tipoVaricela.'</b></center>
						</td>
						<td>
							<center><p>'.$apl1Varicela.'</p></center>
						</td>
						<td>
							<center><p>'.$apl2Varicela.'</p></center>
						</td>
						<td>
							<center><p>'.$apl3Varicela.'</p></center>
						</td>
						<td>
							<center><p>'.$ref1Varicela.'</p></center>
						</td>
						<td>
							<center><p>'.$ref2Varicela.'</p></center>
						</td>
					</tr>
				</table>
				';

			$dompdf->load_html($cabecalho.$dadosPais.$dadosCrianca.$dadosTestes.$dadosVacinas.$html);


	//Renderizar o html
	$dompdf->render();

	//Exibibir a página
	$dompdf->stream(
		"perfil.pdf", 
		array(
			"Attachment" => false //Para realizar o download somente alterar para true
		)
	);
	
?>