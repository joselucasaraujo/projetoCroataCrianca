
				 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseMae" aria-expanded="true" aria-controls="collapseMae">
				    Dados da Mãe
				  </button>
				<div class="collapse" id="collapseMae">
				  <div class="card card-body">
				    <div class="row">
						<div class="form-group col-md col-sm">	
							<label for="nomeMae">Nome da Mãe:</label>
							<input class="form-control form-control-sm" type="text" name="nomeMae" id="nomeMaeID" placeholder="Digite o nome da mãe">
						</div>
					</div>

					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="idadeMae">Idade:</label>
							<input class="form-control form-control-sm" type="number" name="idadeMae" id="idadeMaeID" placeholder="Digite a idade da mãe">
						</div>
						<div class="form-group col-md-6 col-sm">
							<label for="profissaoMae">Profissão:</label>
							<input class="form-control form-control-sm" type="text" name="profissaoMae" id="profissaoMaeID placeholder="Digite a profissão da mãe">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-3 col-sm">
							<label for="consultaPreNatal">Nº de consultas de pré-natal:</label>
							<input class="form-control form-control-sm" type="number" name="consultaPreNatal" id="consultaPreNatalID">
						</div>
						<div class="form-group col-md-3">
							<label for="filhosVivo">Filhos Nascidos Vivos:</label>
							<input class="form-control form-control-sm" type="number"  name="filhosVivo" id="filhosVivoID" size="5px">
						</div>
						<div class="form-group col-md-3">
							<label for="filhosMorto">Mortos:</label>
							<input class="form-control form-control-sm" type="number" name="filhosMorto" id="filhosMortoID">
						</div>
						<div class="form-group col-md-3">
							<label for="filhosAborto">Aborto:</label>
							<input class="form-control form-control-sm" type="number" name="filhosAborto" id="filhosAborto">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md col-sm">	
							<label for="municipioPreNatal">Município de realização do pré-natal:</label>
							<input class="form-control form-control-sm" type="text" name="municipioPreNatal" id="municipioPreNatalID" placeholder="Realizou pré-natal em qual município?">
						</div> 
					</div>
				</div>
		</div>	
	</div>
</div>