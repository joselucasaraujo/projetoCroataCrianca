    
        <div id="listarCadastros">
              <div class="p-3 table-responsive">
          <table class="table table-hover table-sm bg-cinzaClaro text-center">
              <thead class="bg-rosa text-white">
                  <tr>
                      <th>Nome completo</th>
                      <th>Data de nascimento</th>
                      <th>Localidade</th>
                      <th>Mais informações</th>
                      <th>Excluir</th>
                  </tr> 
              </thead>
              <tbody>
              <?php
              $pdo1 = conectar();

                $pag = $_GET['pag'];
                if ($pag > 1) {
                  $pag = $pag; 
                }else{
                  $pag = 1;
                }

                $quantidade = 5;
                $inicio = (($pag * $quantidade) - $quantidade);

                
                if (empty($_POST['chave'])) {
                  $chave = '';
                }else{
                  $chave = $_POST['chave'];
                }
                
                $sql = $pdo1->query("SELECT * FROM tb_crianca WHERE nomeCrianca LIKE '%$chave%' LIMIT $inicio, $quantidade");
                $conta = $sql->rowCount();

                if ($conta == "0") {
                  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong>Nenhum registro encontrado!</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>';
                }else{
                  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong>'.$conta.' resultado(s)</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>';

      

            while ($show=$sql->fetch(PDO::FETCH_ASSOC)) {

              ?>

                  <tr>
                      <td><?php echo $show['nomeCrianca']?></td>
                      <td><?php echo $show['dataNascCrianca']?></td>
                      <td><?php echo $show['localidade']?></td>
                    <!--  <td><?php  /*
                      $listarPai = listarPorId($show['idPai'], "tb_pai");
                    foreach ($listarPai as $papai) {
                      echo $papai->nome_pai;
                    }
                      ?>
                      </td>
                      <td><?php 
                        $listarMae = listarPorId($show['idMae'], "tb_mae");
                    foreach ($listarMae as $mamae) {
                      echo $mamae->nome_mae;
                    }
                      */ ?></td>-->
                      <td class="text-center">
                        <a class="btn btn-outline-rosa btn-sm " href="home&p=editar&id=<?php echo $show['idcrypt']; ?>"><img src="assets/img/icones/bb.png" width="20px"></a>
                      </td>
                      <td class="text-center">
                         <a class="btn btn-outline-rosa btn-sm " href="usuarios&p=lista&excluir=true&id=<?php echo $show['id']; ?>&pag=1"><img src="assets/img/del.png" width="20px"></a>
                      </td>

                  </tr>
                  
                  <?php  
                   }
                } 

                $sql_2 = $pdo1->query("SELECT * FROM tb_crianca WHERE nomeCrianca LIKE '%$chave%'");
                $conta2 = $sql_2->rowCount(); 

                $paginas = ceil($conta2/$quantidade);
                $link = 2;
                ?>
              </tbody>
          </table>
           <a class='btn btn-azulbb text-white' href="home&p=listar&pag=1">Primeira</a>
           <?php 
          for($i = $pag - $link;$i <=-1;$i++){
            if ($i<=0) {
              # code...
            }else{
                echo"<a class='btn btn-azulbb text-white' href='home&p=listar&pag=".$i."'>".$i."</a>";
            }
          }
      ?>
      <a class='btn btn-azulbb text-white' ><?php echo "$pag"; ?></a>
      <?php
          for($i = $pag + 1;$i <= $pag + $link;$i++){
            if ($i > $paginas) {
              # code...
            }else{
              echo"<a class='btn btn-azulbb text-white' href='home&p=listar&pag=".$i."'>".$i."</a>"; 
            }
          }
         ?>
        <a class='btn btn-azulbb text-white' href="home&p=listar&pag=<?php echo $paginas; ?>">Última</a>
          </div>
        </div>
       