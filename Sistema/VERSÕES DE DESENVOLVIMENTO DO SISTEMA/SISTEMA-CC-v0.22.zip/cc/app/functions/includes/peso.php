<?php 

if (isset($_POST['cadPesoBB'])) {

 $idCrianca =  $_POST['cadPesoBB'];
 $cadSemanaPeso = filter_input(INPUT_POST, 'cadSemanaPeso', FILTER_SANITIZE_NUMBER_INT);
 $cadDataPeso = $_POST['cadDataPeso'];
 $cadPesoData = $_POST['cadCPesoData'];
 

 $attributes = [
        "idCrianca" => $idCrianca,
        "semana" => $cadSemanaPeso,
        "data" => $cadDataPeso,
        "peso" => $cadPesoData
      ];

    $cadSemanaBB = cadastrar("tb_peso_semana", $attributes);
}


 ?>