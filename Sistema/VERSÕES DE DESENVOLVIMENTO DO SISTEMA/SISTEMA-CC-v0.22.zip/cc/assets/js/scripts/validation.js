console.log("validacao asdasdlinkado");

$(document).ready(function(){

//valida e mostra o error da pagina de login
    $('#logarID').click(function(){//veirifica se todos os campos estao preenchidos



        if (($('#campoLoginID').val() == "") && ($('#campoSenhaID').val() == "")) {//VERIFICA LOGIN

                
               // $('#inputLogin').addClass("is-valid");

                $('#campoSenhaID').addClass("border-rosa");
                $('#campoLoginID').addClass("border-rosa");
                $('#foo').addClass("d-block");

                $('#campoLoginID').focus();

                 
        botao.html('Aguarde Carregando...');
        }else if ($('#campoLoginID').val() == ""){//VEREIFICA SENHA
            
                $('#campoLoginID').addClass("border-danger");
                $('#campoLoginID').focus();

        }else if ($('#campoSenhaID').val() == ""){ 

                $('#campoSenhaID').addClass("border-danger");
                $('#campoSenhaID').focus();
        }else{

                $('#logarID').get(0).type = 'submit';
        }
    })


     $('#cadCriancaID').click(function(){//veirifica se todos os campos estao preenchidos


//validação mae
       


        if ($('#nomeMaeID').val() == ""){//VEREIFICA SENHA
            
                $('#nomeMaeID').addClass("border-danger");

                $('#nomeMaeID').focus();

        }else if ($('#idadeMaeID').val() == ""){//VEREIFICA SENHA
            
                $('#idadeMaeID').addClass("border-danger");

                $('#idadeMaeID').focus();

        }else if ($('#profissaoMaeID').val() == ""){//VEREIFICA SENHA
            
                $('#profissaoMaeID').addClass("border-danger");

                $('#profissaoMaeID').focus();

        }else if ($('#consultaPreNatalID').val() == ""){//VEREIFICA SENHA
            
                $('#consultaPreNatalID').addClass("border-danger");
                $('#consultaPreNatalID').focus();

        }else if ($('#filhosVivoID').val() == ""){//VEREIFICA SENHA
            
                $('#filhosVivoID').addClass("border-danger");
                $('#filhosVivoID').focus();

        }else if ($('#filhosMortoID').val() == ""){//VEREIFICA SENHA
            
                $('#filhosMortoID').addClass("border-danger");
                $('#filhosMortoID').focus();

        }else if ($('#filhosAbortoID').val() == ""){//VEREIFICA SENHA
            
                $('#filhosAbortoID').addClass("border-danger");
                $('#filhosAbortoID').focus();

        }else if ($('#municipioPreNatalID').val() == ""){//VEREIFICA SENHA
            
                $('#municipioPreNatalID').addClass("border-danger");
                $('#municipioPreNatalID').focus();

        }


        //validação PAI


        if ($('#nomePaiID').val() == ""){//VEREIFICA SENHA
            
                $('#nomePaiID').addClass("border-danger");

                $('#nomePaiID').focus();

        }else if ($('#idadePaiID').val() == ""){//VEREIFICA SENHA
            
                $('#idadePaiID').addClass("border-danger");

                $('#idadePaiID').focus();

        }else if ($('#profissaoPaiID').val() == ""){//VEREIFICA SENHA
            
                $('#profissaoPaiID').addClass("border-danger");

                $('#profissaoPaiID').focus();

        }else if ($('#numeroMembrosFamiliaID').val() == ""){//VEREIFICA SENHA
            
                $('#numeroMembrosFamiliaID').addClass("border-danger");
                $('#numeroMembrosFamiliaID').focus();

        }else if ($('#acsID').val() == ""){//VEREIFICA SENHA
            
                $('#acsID').addClass("border-danger");
                $('#acsID').focus();

        }

      //validação RN


        if ($('#nomeRNID').val() == ""){//VEREIFICA SENHA
            
                $('#nomeRNID').addClass("border-danger");

                $('#nomeRNID').focus();

        }else if ($('#dataRNID').val() == ""){//VEREIFICA SENHA
            
                $('#dataRNID').addClass("border-danger");

                $('#dataRNID').focus();

        }else if ($('#sexoID').val() == ""){//VEREIFICA SENHA
            
                $('#sexoID').addClass("border-danger");

                $('#sexoID').focus();

        }else if ($('#tipoDePartoID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoDePartoID').addClass("border-danger");
                $('#tipoDePartoID').focus();

        }else if ($('#idadeGestacionalID').val() == ""){//VEREIFICA SENHA
            
                $('#idadeGestacionalID').addClass("border-danger");
                $('#idadeGestacionalID').focus();

        }else if ($('#localidadeID').val() == ""){//VEREIFICA SENHA
            
                $('#localidadeID').addClass("border-danger");
                $('#localidadeID').focus();

        }

              //validação VACINAS


        if ($('#tipoVacID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoVacID').addClass("border-danger");

                $('#tipoVacID').focus();

        }else if ($('#tipoHepBID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoHepBID').addClass("border-danger");

                $('#tipoHepBID').focus();

        }else if ($('#tipoPneumo10ID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoPneumo10ID').addClass("border-danger");

                $('#tipoPneumo10ID').focus();

        }else if ($('#TipoVipID').val() == ""){//VEREIFICA SENHA
            
                $('#TipoVipID').addClass("border-danger");
                $('#TipoVipID').focus();

        }else if ($('#tipoRotavirusID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoRotavirusID').addClass("border-danger");
                $('#tipoRotavirusID').focus();

        }else if ($('#tipoMeningoCID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoMeningoCID').addClass("border-danger");
                $('#tipoMeningoCID').focus();

        }else if ($('#tipoTripliceViralID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoTripliceViralID').addClass("border-danger");
                $('#tipoTripliceViralID').focus();

        }else if ($('#tetraViralID').val() == ""){//VEREIFICA SENHA
            
                $('#tetraViralID').addClass("border-danger");
                $('#tetraViralID').focus();

        }else if ($('#tipoDTPID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoDTPID').addClass("border-danger");
                $('#tipoDTPID').focus();

        }else if ($('#tipoHepAID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoHepAID').addClass("border-danger");
                $('#tipoHepAID').focus();

        }else if ($('#tipoVOPID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoVOPID').addClass("border-danger");
                $('#tipoVOPID').focus();

        }else if ($('#tipoVaricelaID').val() == ""){//VEREIFICA SENHA
            
                $('#tipoVaricelaID').addClass("border-danger");
                $('#tipoVaricelaID').focus();

        }

    })
});
