<button class="btn-azulbb text-light btn-block  border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePeso" aria-expanded="false" aria-controls="collapsePeso">
				    Peso / Semana
		 </button>
				<div class="collapse" id="collapsePeso">
				  <div class="card card-body">
				  	
				  		<div class="row">
							<div class="form-group form-group col-md-4 col-sm">	
								<label for="semanaID">Semana: <b class="text-danger">*</b></label>
								<input class="form-control form-control-sm" type="number" id="semanaPesoID" placeholder="Digite o número da semana" name="semanaPeso" required>
							</div>
							<div class="form-group form-group col-md-4 col-sm">	
								<label for="dataPesoID">Data: <b class="text-danger">*</b></label>
								<input class="form-control form-control-sm" type="date" id="dataPesoID" name="dataPeso" required>
							</div>
							<div class="form-group form-group col-md-4 col-sm">	
								<label for="pesoDataID">Peso: <b class="text-danger">*</b></label>
								<input class="form-control form-control-sm" type="number" step="00.01" id="pesoDataID" placeholder="Digite o peso registrado"  name="pesoData" required>
							</div>
						</div>
						

				  </div>
				 </div> 