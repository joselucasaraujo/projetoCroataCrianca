
			 <button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseVac" aria-expanded="false" aria-controls="collapseVac">
				    Vacinas
			 </button>

				<div class="collapse" id="collapseVac">
				  <div class="card card-body">
				  	<!-- VAC01 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="tipoVac">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="BCG" type="text" id="tipoVacID" placeholder="" name="tipoBCG" required>
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="apl1">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" id="apl1BCGID" placeholder="" name="apl1BCG">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="apl2">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2BCG" id="apl2BCGID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="apl3">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3BCG" id="apl3BCGID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="ref1">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1BCG" id="ref1BCGID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="ref2">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2BCG" id="ref2BCGID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
										  	<!-- VAC02 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="HepB" type="text" name="tipoHepB" id="tipoHepBID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1HepB" id="apl1HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2HepB" id="apl2HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3HepB" id="apl3HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1HepB" id="ref1HepBID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2HepB" id="ref2HepBID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
										  	<!-- VAC03 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b> </label>
									<input class="form-control form-control-sm" value="Penta" type="text" name="tipoPenta" id="tipoPentaID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1Penta" id="apl1PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2Penta" id="apl2PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3Penta" id="apl3PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1Penta" id="ref1PentaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2Penta" id="ref2PentaID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
										  	<!-- VAC04 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Pneumo 10" type="text" name="tipoPneumo10" id="tipoPneumo10ID" placeholder="" >
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1Pneumo10" id="apl1Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2Pneumo10" id="apl2Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3Pneumo10" id="apl3Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1Pneumo10" id="ref1Pneumo10ID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2Pneumo10" id="ref2Pneumo10ID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
										  	<!-- VAC05 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="VIP" type="text" name="TipoVip" id="TipoVipID" placeholder="" >
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1Vip" id="apl1VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2Vip" id="apl2VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3Vip" id="apl3VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1Vip" id="ref1VipID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2Vip" id="ref2VipID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
										  	<!-- VAC06 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Rotavírus" type="text" name="tipoRotavirus" id="tipoRotavirusID" placeholder="" >
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1Rotavirus" id="apl1RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2Rotavirus" id="apl2RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3Rotavirus" id="apl3RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1Rotavirus" id="ref1RotavirusID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2Rotavirus" id="ref2RotavirusID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
																  	<!-- VAC07 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Meningo C" type="text" name="tipoMeningoC" id="tipoMeningoCID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1MeningoC" id="apl1MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2MeningoC" id="apl2MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3MeningoC" id="apl3MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1MeningoC" id="ref1MeningoCID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2MeningoC" id="ref2MeningoCID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
																  	<!-- VAC08 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Tríplice viral" type="text" name="tipoTripliceViral" id="tipoTripliceViralID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1TripliceViral" id="apl1TripliceViral" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2TripliceViral" id="apl2TripliceViral" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3TripliceViral" id="apl3TripliceViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1TripliceViral" id="ref1TripliceViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2TripliceViral" id="ref2TripliceViralID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
																  	<!-- VAC09 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Tetra viral" type="text" name="tetraViral" id="tetraViralID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1TetraViral" id="apl1TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2TetraViral" id="apl2TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3TetraViral" id="apl3TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1TetraViral" id="ref1TetraViralID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2TetraViral" id="ref2TetraViralID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
																  	<!-- VAC10 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="DTP" type="text" name="tipoDTP" id="tipoDTPID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1DTP" id="apl1DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2DTP" id="apl2DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3DTP" id="apl3DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1DTP" id="ref1DTPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2DTP" id="ref2DTPID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
																  	<!-- VAC11 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Hep A" type="text" name="tipoHepA" id="tipoHepAID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1HepA" id="apl1HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2HepA" id="apl2HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3HepA" id="apl3HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1HepA" id="ref1HepAID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2HepA" id="ref2HepAID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
<hr>
																  	<!-- VAC12 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="VOP" type="text" name="tipoVOP" id="tipoVOPID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1VOP" id="apl1VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2VOP" id="apl2VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3VOP" id="apl3VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1VOP" id="ref1VOPID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2VOP" id="ref2VOPID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->

<hr>

				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="Varicela" type="text" name="tipoVaricela" id="tipoVaricelaID" placeholder="">
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1Varicela" id="apl1VaricelaID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2Varicela" id="apl2VaricelaID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->
								<hr>
																  	<!-- VAC12 -->
				  		<div class="row">
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Tipo: <b class="text-danger">*</b></label>
									<input class="form-control form-control-sm" value="" type="text" name="outros" id="outrosID" placeholder="Outros" >
								</div>
								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 01:</label>
									<input class="form-control form-control-sm" type="date" name="apl1Outros" id="apl1OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 02:</label>
									<input class="form-control form-control-sm" type="date" name="apl2Outros" id="apl2OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Aplicação 03:</label>
									<input class="form-control form-control-sm" type="date" name="apl3Outros" id="apl3OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Reforço 01:</label>
									<input class="form-control form-control-sm" type="date" name="ref1Outros" id="ref1OutrosID" placeholder="">
								</div>

								<div class="form-group form-group col-md-2 col-sm">	
									<label for="">Refoço 02:</label>
									<input class="form-control form-control-sm" type="date" name="ref2Outros" id="ref2OutrosID" placeholder="">
								</div>

						</div><!-- fECHA O ROW  -->																						  	<!-- VAC13 -->
				  </div>
				</div> 