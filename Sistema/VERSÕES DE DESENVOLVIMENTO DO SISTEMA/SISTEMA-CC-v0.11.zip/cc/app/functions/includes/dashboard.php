<?php 
	if (isset($_POST['sair'])) {
		session_destroy();
		session_unset();
		header("Location: home");
	}
 ?>