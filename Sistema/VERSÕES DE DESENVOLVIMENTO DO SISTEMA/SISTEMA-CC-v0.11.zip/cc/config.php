<?php
	require 'app/functions/conexao/conexao.php';
	require 'app/functions/crud/cadastrar.php';
	require 'app/functions/crud/atualizar.php';
	require 'app/functions/crud/listar.php';
	require 'app/functions/crud/deletar.php';
	require 'app/functions/includes/paginas.php';
	require 'app/functions/includes/deletar.php';
	require 'app/functions/includes/listar.php';
	require 'app/functions/includes/login.php';
	require 'app/functions/includes/cadastrar.php';
	require 'app/functions/includes/home.php';
	require 'app/functions/includes/editar.php';

	//funçoes
 function inverteData($data){
    if(count(explode("/",$data)) > 1){
        return implode("-",array_reverse(explode("/",$data)));
    }elseif(count(explode("-",$data)) > 1){
        return implode("/",array_reverse(explode("-",$data)));
    }
}
?>