<?php 

	    $idChave = trim(strip_tags($_GET['id'])); //remove espaçoes e tags
      $idChave = str_replace("\"", "",$idChave); //remove aspas
      $idChave = str_replace('\'', "",$idChave); //remove aspas 


       $listarDadosCrianca = listarPorChave($idChave, "tb_crianca");
	            foreach ($listarDadosCrianca as $child) : 	
	            $idCrinca = $child->id;
	            $nomeCrianca = $child->nomeCrianca;
	     endforeach;


 ?>

<?php 



  if ($child->sexoCrianca == 'Masculino') {
    echo '<div class="bg-azulbb text-white shadow-lg">
  <form class="form-inline mt-2 mt-md-0 p-2 ml-2" name="enterData" method="POST" action="home&p=peso&id='.$idChave.'&pag=1" enctype="multipart/form-data">
                  <img src="assets/img/child2.png" height="40px"><h5 class="ml-3" style="margin-top: 15px;">'.$nomeCrianca.'</h5>
                  <input size="35%" type="date" class="form-control mr-sm-2 col-md-2 col-10" style="margin-left: 28rem;" name="chaveData" placeholder="Data">
                  <button class="btn btn-rosa text-light my-3 my-sm-0 col-2 col-md-1" type="submit" name="enterData"><img src="assets/img/icones/search.png" height="20px"></button>
    </form>
</div>
';
  }elseif ($child->sexoCrianca == 'Feminino') {
        echo '<div class="bg-femi text-white shadow-lg">
  <form class="form-inline mt-2 mt-md-0 p-2 ml-2" name="enterData" method="POST" action="home&p=peso&id='.$idChave.'&pag=1" enctype="multipart/form-data">
                  <img src="assets/img/child2.png" height="40px"><h5 class="ml-3" style="margin-top: 15px;">'.$nomeCrianca.'</h5>
                  <input size="35%" type="date" class="form-control mr-sm-2 col-md-2 col-10" style="margin-left: 28rem;" name="chaveData" placeholder="Data">
                  <button class="btn btn-rosa text-light my-3 my-sm-0 col-2 col-md-1" type="submit" name="enterData"><img src="assets/img/icones/search.png" height="20px"></button>
    </form>
</div>
';
  }else{
        echo '<div class="bg-primary text-white shadow-lg">
  <form class="form-inline mt-2 mt-md-0 p-2 ml-2" name="enterData" method="POST" action="home&p=peso&id='.$idChave.'&pag=1" enctype="multipart/form-data">
                  <img src="assets/img/child2.png" height="40px"><h5 class="ml-3" style="margin-top: 15px;">'.$nomeCrianca.'</h5>
                  <input size="35%" type="date" class="form-control mr-sm-2 col-md-2 col-10" style="margin-left: 28rem;" name="chaveData" placeholder="Data">
                  <button class="btn btn-rosa text-light my-3 my-sm-0 col-2 col-md-1" type="submit" name="enterData"><img src="assets/img/icones/search.png" height="20px"></button>
    </form>
</div>
';
  }

 ?>
 
        <div id="listarCadastros shadow-lg ">
              <div class="p-3 table-responsive">
          <table style="padding: 0px 0px 0px 0px;" class="table table-hover table-sm bg-cinzaClaro text-center shadow-lg">
              <thead class="bg-rosa text-white shadow-lg">
                  <tr class="shadow-lg">
                      <th class="shadow-lg">Peso</th>
                      <th class="shadow-lg">Semana</th>
                      <th class="shadow-lg">Data</th>
                      <th class="shadow-lg">Excluir</th>
                  </tr> 
              </thead>
              <tbody>
              <?php
              $pdo1 = conectar();

                $pag = $_GET['pag'];
                if ($pag > 1) {
                  $pag = $pag; 
                }else{
                  $pag = 1;
                }

                $quantidade = 5;
                $inicio = (($pag * $quantidade) - $quantidade);

                
                if (empty($_POST['chaveData'])) {
                  $chave = '';
                }else{
                  $chave = $_POST['chaveData'];
                }
                
                $sql = $pdo1->query("SELECT * FROM tb_peso_semana WHERE data LIKE '%$chave%' AND idCrianca = $idCrinca ORDER BY semana ASC LIMIT $inicio, $quantidade ");
                $conta = $sql->rowCount();

                if ($conta == "0") {
                  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong>Nenhum registro encontrado!</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>';
                }else{
                  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong>'.$conta.' resultado(s)</strong><button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>';

      

            while ($show=$sql->fetch(PDO::FETCH_ASSOC)) {

              ?>

                  <tr class="shadow-lg">
                     
                      <td><?php echo $show['peso']?> Kg</td>
                      <td class="text-center">
                       <?php echo $show['semana']?>º Semana
                      </td>
                      <td class="text-center">
                        <?php
                         
                         echo inverteData($show['data']);
                         ?>
                      </td>
                      <td class="text-center" style="padding: 0px 0px 0px 0px;">
                  
                       <a class="btn btn-rosa btn-sm btn-block shadow-lg" style=" border-bottom-left-radius: 80px; border-top-left-radius: 40px;" href="home&p=peso&excluirPeso=true&id=<?php echo $show['id']; ?>&pag=1&key=<?php echo $idChave ?>"><img src="assets/img/del.png" width="20px"></a> 
                        <!--   <a class="btn btn-outline-rosa btn-sm " data-toggle="modal" data-target=".modalPeso"><img src="assets/img/del.png" width="20px"></a>-->


                      </td>

                  
                  <?php  
                   }
                } 

                $sql_2 = $pdo1->query("SELECT * FROM tb_peso_semana WHERE data LIKE '%$chave%'");
                $conta2 = $sql_2->rowCount(); 

                $paginas = ceil($conta2/$quantidade);
                $link = 2;
                ?>
              </tbody>
          </table>
           <a class='btn btn-rosa shadow-md text-white' href="home&p=peso&id=<?php echo $idChave ?>&pag=1">Primeira</a>
           <?php 
          for($i = $pag - $link;$i <=-1;$i++){
            if ($i<=0) {
              # code...
            }else{
                echo"<a class='btn btn-rosa shadow-md text-white' style='margin-right: 1px;' href='home&p=peso&id=".$idChave."&pag=".$i."'>".$i."</a>";
            }
          }
      ?>
      <a class='btn btn-rosa shadow-md text-white' ><?php echo "$pag"; ?></a>
      <?php
          for($i = $pag + 1;$i <= $pag + $link;$i++){
            if ($i > $paginas) {
              # code...
            }else{
              echo"<a class='btn btn-rosa shadow-md text-white ' href='home&p=peso&id=".$idChave."&pag=".$i."'>".$i."</a>"; 
            }
          }
         ?>
        <a class='btn btn-rosa shadow-md text-white' href="home&p=peso&id=<?php echo $idChave; ?>&pag=<?php echo $paginas;?>">Última</a>
          </div>
        </div>
        <?php include 'partials/peso/cadPeso.php'; ?>