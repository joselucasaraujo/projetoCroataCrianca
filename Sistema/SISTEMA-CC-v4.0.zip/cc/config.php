<?php
	require 'app/functions/conexao/conexao.php';
	require 'app/functions/crud/cadastrar.php';
	require 'app/functions/crud/atualizar.php';
	require 'app/functions/crud/listar.php';
	require 'app/functions/crud/deletar.php';
	require 'app/functions/includes/paginas.php';
	require 'app/functions/includes/deletar.php';
	require 'app/functions/includes/listar.php';
	require 'app/functions/includes/login.php';
	require 'app/functions/includes/cadastrar.php';
	require 'app/functions/includes/home.php';
	require 'app/functions/includes/editar.php';
	require 'app/functions/includes/peso.php';

	//funçoes
 function inverteData($data){
    if(count(explode("/",$data)) > 1){
        return implode("-",array_reverse(explode("/",$data)));
    }elseif(count(explode("-",$data)) > 1){
        return implode("/",array_reverse(explode("-",$data)));
    }
}

//função usada para calcular a idade com base na data de nascimento

function calculo_idade($data) {
    //Data atual
    $dia = date('d');
    $mes = date('m');
    $ano = date('Y');
    //Data do aniversário
    $nascimento = explode('-', $data);
    $dianasc = ($nascimento[2]);
    $mesnasc = ($nascimento[1]);
    $anonasc = ($nascimento[0]);
    // se for formato do banco, use esse código em vez do de cima!
    //Calculando sua idade
    $idade = $ano - $anonasc; // simples, ano- nascimento!
    if ($mes < $mesnasc) // se o mes é menor, só subtrair da idade
    {
        $idade--;
        return $idade;
    }
    elseif ($mes == $mesnasc && $dia <= $dianasc) // se esta no mes do aniversario mas não passou ou chegou a data, subtrai da idade
    {
        $idade--;
        return $idade;
    }
    else // ja fez aniversario no ano, tudo certo!
    {
        return $idade;
    }
}
?>