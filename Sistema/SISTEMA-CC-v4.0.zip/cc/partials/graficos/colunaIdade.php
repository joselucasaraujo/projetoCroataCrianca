
    <script type="text/javascript">
      //carrega o pacote dos gráficos    
      google.charts.load('current', {'packages':['corechart']});
      
      //define a função para criar o gráfico
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Crianças', 'Crianças'],
          ['0 a 1 ano',     <?php echo $cont_0a1ano; ?>],
          ['1 a 2 anos',      <?php echo $cont_1a2ano; ?>],
          ['2 a 3 anos',     <?php echo $cont_2a3ano; ?>],
        ]);
        // criar a variavel options para definir as opções do gráfico
        var options = {
          title: 'Gráfico de crianças por idade'
        };
        //aloca o tipo de gráfico na div GraficoColunas
    var chart = new google.visualization.ColumnChart(document.getElementById('GraficoColunasIdade'));

        chart.draw(data, options);
      }
      
      //carrega o grafico na página
      google.charts.setOnLoadCallback(drawChart);
      
    </script>