<button class="btn-azulbb text-light btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapseCrianca" aria-expanded="false" aria-controls="collapseCrianca">
	    Dados da Criança
</button>
	<?php $listarDadosCrianca = listarPorChave($chave, "tb_crianca");
	            foreach ($listarDadosCrianca as $child) : 	


	            	$idCrinca = $child->id;
	       ?>
<div class="collapse" id="collapseCrianca">
    <div class="card card-body bg-cinzaClaro">

		<div class="row">
			<div class="form-group col-md-6 col-sm-6">
				<label for="nomeRN">Nome do RN: <b class="text-danger">*</b></label>
				<input class="form-control form-control-sm shadow-lg" type="text" name="nomeRNEdit" id="nomeRNIDEdit" placeholder="Digite o nome do recém nascido" value="<?php echo $child->nomeCrianca;?>" required>
			</div>
				<div class="form-group col-md-6 col-sm-6">
						<label for="acs">ACS: <b class="text-danger">*</b></label>
						<input class="form-control form-control-sm shadow-lg" type="text" name="acsEdit" id="acsIDEdit" placeholder="Digite o nome do Agente Comunitário de Saúde" value="<?php echo $child->acs;?>" required>
					</div>
		</div>
		<hr>
		<?php $datanasc = $child->dataNascCrianca; 
			 ?>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="dataRN">Data de Nascimento: <b class="text-danger">*</b></label>
				<input class="form-control form-control-sm shadow-lg" type="date" name="dataRNEdit" id="dataRNIDEdit" value="<?php 	
				echo $datanasc;
				?>" required>
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="hora">Hora:</label>
				<input class="form-control form-control-sm shadow-lg" type="text" name="horaEdit" id="horaIDEdit" value="<?php echo $child->horaNascCrianca;?>" >
			</div>
			<div class="form-group col-md-2 col-sm">
				  <label for="sexoID">Sexo: <b class="text-danger">*</b></label>
				  <div class="divSexoID" hidden><?php echo $child->sexoCrianca;?></div>
				    <select class="form-control form-control-sm shadow-lg" name="sexoEdit" id="sexoIDEdit" required> 
				      <option value="Masculino">Masculino</option>
				      <option value="Feminino">Feminino</option>
				    </select>
			</div>
			<div class="form-group col-md-4 col-sm">
				  <label for="tipoDePartoID">Tipo de parto: <b class="text-danger">*</b></label>
				  <div class="divTipoDePartoID" hidden><?php echo $child->partoCrianca;?></div>
				    <select class="form-control form-control-sm shadow-lg" name="tipoDePartoEdit" id="tipoDePartoIDEdit" required>
				      <option value="Normal">Normal</option>
				      <option value="Cesariana">Cesariana</option>
				    </select>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-3 col-sm">
				<label for="peso">Peso:</label>
				<input class="form-control form-control-sm shadow-lg" step="00.01" type="number" name="pesoEdit" id="pesoIDEdit" value="<?php echo $child->pesoCrianca;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="altura">Altura:</label>
				<input class="form-control form-control-sm shadow-lg" type="number" name="alturaEdit" id="alturaIDEdit" value="<?php echo $child->alturaCrianca;?>">
			</div>
			<div class="form-group col-md-3 col-sm">
				<label for="idadeGestacional">Idade gestacional: <b class="text-danger">*</b></label>
				<input class="form-control form-control-sm shadow-lg" type="number" name="idadeGestacionalEdit" id="idadeGestacionalIDEdit" value="<?php echo $child->idadeGestacional;?>" required>
			</div>
			<div class="form-group col-md-3 col-sm">
				
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="form-group col-md-4 col-sm">
				<label for="endereco">Endereço:</label>
				<input class="form-control form-control-sm shadow-lg" type="text" name="enderecoEdit" id="enderecoIDEdit" placeholder="Ex: Rua Antonio Saturnino, Caroba" value="<?php echo $child->endereco;?>">
			</div>
			<div class="form-group col-md-4 col-sm">
					<label for="localidadeID">Localidade: <b class="text-danger">*</b></label>
						<div class="divLocalidadeID" hidden><?php echo $child->localidade;?></div>
							 <select class="form-control form-control-sm shadow-lg" name="localidadeEdit" id="localidadeIDEdit" required>
							      <option value="">Selecione</option>
							      <option value="Croatá">Croatá (sede)</option>
							      <option value="Betânia">Betânia</option>
							      <option value="Barra do sotero">Barra do Sotero</option>
							      <option value="Lagoa da cruz">Lagoa da Cruz</option>
							      <option value="São roque">São Roque</option>
							      <option value="Vista alegre">Vista Alegre</option>
							      <option value="Santa tereza">Santa Tereza</option>
							      <option value="Repartição">Repartição</option>
							  </select>
			</div>
			<div class="form-group col-md-4 col-sm">
					<label for="cartaoSUS">Cartão do SUS: </label>
					<input class="form-control form-control-sm shadow-lg" type="text" id="cartaoSUSEditID" maxlength="15" value="<?php echo $child->cartaoSUS; ?>" placeholder="" name="cartaoSUSEdit">
			</div>
		</div>
	</div>	
	<?php 
		$idMae = $child->idMae;
		$idPai = $child->idPai;
		endforeach; 
	?>
</div>