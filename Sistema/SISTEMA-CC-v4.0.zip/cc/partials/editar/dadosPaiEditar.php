

<button class="btn-azulbb text-light  btn-block border border-azulbb" type="button" data-toggle="collapse" data-target="#collapsePai" aria-expanded="false" aria-controls="collapsePai">
		    Dados do Pai
 </button>
 <?php $listarDadosPai = listarPorId($idPai, "tb_pai");
            foreach ($listarDadosPai as $dad) : 	
    ?>
	<div class="collapse" id="collapsePai">
	  <div class="card card-body bg-cinzaClaro">
	  	
	  		<div class="row">
					<div class="form-group form-group col-md col-sm">	
						<label for="nomePai">Nome do Pai: <b class="text-danger">*</b></label>
						<input class="form-control form-control-sm shadow-lg" type="text" name="nomePaiEdit" id="nomePaiIDEdit" placeholder="Digite o nome do pai" value="<?php echo $dad->nome_pai;?>" required>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-3 col-sm">
						<label for="idadePai">Idade: <b class="text-danger">*</b></label>
						<input class="form-control form-control-sm shadow-lg" type="number" name="idadePaiEdit" id="idadePaiIDEdit" placeholder="Digite a idade do pai" value="<?php echo $dad->idade;?>" required>
					</div>
					<div class="form-group col-md-6 col-sm">
						<label for="profissaoPai">Profissão: <b class="text-danger">*</b></label>
						<input class="form-control form-control-sm shadow-lg" type="text" name="profissaoPaiEdit" id="profissaoPaiIDEdit" placeholder="Digite a profissão do pai" value="<?php echo $dad->profissao;?>" required>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md-4 col-sm">
						<label for="numeroMembrosFamilia">Nº de membros da família: <b class="text-danger">*</b></label>
						<input class="form-control form-control-sm shadow-lg" type="number" name="numeroMembrosFamiliaEdit" id="numeroMembrosFamiliaIDEdit" value="<?php echo $dad->membrosFamilia;?>" required>
					</div>
					<div class="form-group col-md-4 col-sm">
						<label for="rendaFamiliar">Renda Familiar:</label>
						<input class="form-control form-control-sm shadow-lg" step="00.01" type="number" name="rendaFamiliarEdit" id="rendaFamiliarIDEdit" value="<?php echo $dad->renda;?>">
					</div>
				
				</div>
				<hr>
				<div class="row">
					<div class="form-group col-md col-sm">
						<label>Observações:</label>
						<input type="textarea" class="form-control form-control-sm shadow-lg" id="obsIDEdit" name="obsEdit" value="<?php echo $dad->obs;?>">	
					</div>
				</div>
    
	  </div>
	 </div> 
	
<?php endforeach; ?>